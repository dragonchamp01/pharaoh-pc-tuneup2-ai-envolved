#pragma once
#include <vector>
#include <string>
#include <map>

namespace pctune_up::ai {

struct SearchResult {
    std::string title;
    std::string url;
    std::string snippet;
    double relevance;
};

class WebSearchAI {
private:
    std::map<std::string, std::vector<SearchResult>> cache;
    int maxResults = 10;

    std::string fetchPage(const std::string& url);
    std::vector<SearchResult> parseResults(const std::string& html, const std::string& query);

public:
    WebSearchAI();

    std::vector<SearchResult> search(const std::string& query, int maxResults = 10);
    std::vector<SearchResult> searchQuantumPCSpecs();
    std::vector<SearchResult> searchBIOSOptimization(const std::string& motherboard);
    std::vector<SearchResult> searchCPUInstructions(const std::string& cpuModel);
    std::vector<SearchResult> searchQuantumInterrupts();
    std::vector<SearchResult> searchManual(const std::string& product);
    
    std::string extractKeyInfo(const std::vector<SearchResult>& results);
    void clearCache() { cache.clear(); }
};

} // namespace pctune_up::ai