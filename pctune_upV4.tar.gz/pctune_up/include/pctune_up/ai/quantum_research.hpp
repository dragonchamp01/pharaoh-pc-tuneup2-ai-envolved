#pragma once
#include <vector>
#include <string>
#include <map>
#include "pctune_up/ai/quantum_core.hpp"
#include "pctune_up/ai/web_search_ai.hpp"
#include "pctune_up/ai/tiny_neural_net.hpp"

namespace pctune_up::ai {

class HardwareResearchAI;

struct ArithmeticTestResult {
    std::string operation;
    long long classicalResult;
    long long quantumResult;
    bool differs;
    std::string explanation;
};

struct InterruptAnalysis {
    int irqNumber;
    std::string deviceName;
    std::vector<long> perCpuCounts;
    long totalCount;
    double frequencyHz;
    double entropyScore;
    bool isVector;
};

struct CPUIDLeaf {
    std::string leafName;
    unsigned int eax, ebx, ecx, edx;
    std::string decoded;
    bool demonicSignature;
};

struct QuantumDevilSignature {
    std::string category;
    std::string featureName;
    double confidenceScore;
    std::string evidence;
    std::string demonicAnalogue;
};

struct QuantumResearchResult {
    std::vector<ArithmeticTestResult> arithmeticTests;
    std::vector<std::string> newInstructions;
    std::vector<std::string> biosSecrets;
    std::vector<std::string> quantumInterrupts;
    std::map<std::string, double> optimizedConfig;
    std::string bestConfigReport;
    bool findingsExist = false;

    // New elite fields
    std::vector<InterruptAnalysis> realInterrupts;
    std::vector<CPUIDLeaf> cpuLeaves;
    std::vector<QuantumDevilSignature> devilSignatures;
    std::string devilManifest;
    std::vector<std::string> discoveredQuantumIRQs;
    std::map<int, std::string> irqToDeviceMap;
};

class QuantumResearchAI {
private:
    QuantumCore quantum;
    WebSearchAI webSearch;
    TinyNeuralNet optimizerNN;
    HardwareResearchAI* hwRef = nullptr;

    void testAlternativeArithmetic();
    void researchCPUSInstructions();
    void researchBIOSSecrets();
    void optimizeConfigWithNN();
    void searchWebForQuantumSpecs();

    // NEW: Real interrupt analysis
    void probeRealInterrupts(QuantumResearchResult& result);
    void classifyIRQAffinity(QuantumResearchResult& result);

    // NEW: CPUID deep decode
    void probeCPUIDLeaves(QuantumResearchResult& result);

    // NEW: Devil's quantum signature detection
    void detectDevilSignatures(QuantumResearchResult& result);
    void generateDevilManifest(QuantumResearchResult& result);

    // NEW: Quantum IRQ injection simulation
    void discoverQuantumIRQs(QuantumResearchResult& result);

public:
    QuantumResearchAI();
    void setHardwareRef(HardwareResearchAI* hw) { hwRef = hw; }

    QuantumResearchResult fullResearch();
    std::string generateHTMLReport(const QuantumResearchResult& result);
    bool hasFindings(const QuantumResearchResult& result) const;
    void saveHTMLIfFindings(const QuantumResearchResult& result);

    // NEW: standalone devil manifest
    std::string generateDevilManifestHTML(const QuantumResearchResult& result);
};
}
