#pragma once

namespace pctune_up::core {

struct Config {
    bool dryRun       = false;
    bool dangerous    = false;
    bool doctorMode   = false;
    bool applyDoctor  = false;
    bool autoPilot    = false;
    bool researchMode = false;
    bool gpuMode      = false;
    bool netMode      = false;
    bool benchmarkMode = false;
    bool interactive  = false;
    bool dashboard    = false;
    bool daemonMode   = false;
    bool intelligenceMode = false;
    bool adminMode    = false;
    bool sysdMode     = false;
    bool secMode      = false;
    bool pkgMode      = false;
    bool auditMode    = false;
    bool bootMode     = false;
    bool cronMode     = false;
    bool gamingMode   = false;
    bool serverWebMode = false;
    bool serverDBMode  = false;
    bool quantumMode  = false;
    bool quantumBoost = false;
    bool compareMode  = false;
    bool htmlReport   = false;
    bool autoMaintain = false;
    bool lightDemon   = false;
    bool devilAI      = false;
    bool devilManifest = false;
    int  cycleInt     = 300;
    int  hbInt        = 60;
    bool color        = true;
};

extern Config cfg;

} // namespace pctune_up::core
