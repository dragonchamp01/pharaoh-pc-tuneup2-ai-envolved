#pragma once

namespace pctune_up::admin {

void optimizeSystemd();
void optimizeSecurity();
void updatePackages();
void auditSystem();
void optimizeBoot();
void manageCron();

} // namespace pctune_up::admin
