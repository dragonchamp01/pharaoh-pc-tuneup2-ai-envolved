#include "pctune_up/ui/console.hpp"
#include "pctune_up/core/colors.hpp"
#include "pctune_up/core/utils.hpp"
#include <iostream>
#include <sstream>
#include <algorithm>
#include <iomanip>

using namespace pctune_up::core;

namespace pctune_up::ui {

std::string InteractiveConsole::analyze(const std::string& query, const ai::HardwareResearchAI& hw, ai::IntelligenceCore& brain, ai::BossBattleManager& bbm) {
    std::string q = query;
    std::transform(q.begin(), q.end(), q.begin(), ::tolower);

    if (q.find("manifest") != std::string::npos && qResearch) {
        auto result = qResearch->fullResearch();
        return "MANIFEST:\n" + result.devilManifest;
    }
    if (q.find("quantum") != std::string::npos && qResearch) {
        auto result = qResearch->fullResearch();
        double avgConf = 0;
        for (const auto& s : result.devilSignatures) avgConf += s.confidenceScore;
        if (!result.devilSignatures.empty()) avgConf /= result.devilSignatures.size();
        double totalEntropy = 0;
        for (const auto& irq : result.realInterrupts) totalEntropy += irq.entropyScore;
        bool certified = avgConf > 0.5;
        std::ostringstream oss;
        oss << "QUANTUM RESEARCH:\n";
        oss << "  Signatures found: " << result.devilSignatures.size() << "\n";
        oss << "  Interrupts analyzed: " << result.realInterrupts.size() << "\n";
        oss << "  Avg entropy: " << std::fixed << std::setprecision(2)
            << (result.realInterrupts.empty() ? 0 : totalEntropy / result.realInterrupts.size()) << "\n";
        oss << "  CPUID leaves: " << result.cpuLeaves.size() << "\n";
        oss << "  Avg confidence: " << (int)(avgConf * 100) << "%\n";
        if (certified) oss << "  >> DEVIL PC CERTIFIED <<\n";
        if (quantum) {
            oss << "  Quantum coherence: " << quantum->getCoherence() << "\n";
            oss << "  Quantum states: " << quantum->getNumStates() << "\n";
        }
        return oss.str();
    }
    if (q.find("neural") != std::string::npos || q.find("brain") != std::string::npos || q.find("network") != std::string::npos) {
        std::ostringstream oss;
        oss << "NEURAL NETWORK TOPOLOGY:\n";
        oss << "  Structure: 6 -> 6 -> 6 (666 Demonic)\n";
        oss << "  Experience buffer: " << brain.getReplaySize() << " memories\n";
        oss << "  Knowledge graph: " << brain.getGraphSize() << " nodes\n";
        oss << "  Training cycles: " << brain.getTrainingCycles() << "\n";
        oss << "  Insights generated: " << brain.getInsightCount() << "\n";
        return oss.str();
    }
    if (q.find("bandit") != std::string::npos || q.find("ucb") != std::string::npos) {
        return "UCB1 BANDIT STATUS:\n" + brain.getBanditReport();
    }
    if (q.find("report") != std::string::npos) {
        if (q.find("devil") != std::string::npos) return brain.getDevilAIReport();
        if (q.find("light") != std::string::npos) return brain.getLightDemonReport();
        std::ostringstream oss;
        oss << "SYSTEM REPORT:\n";
        oss << "  " << brain.getDevilAIReport() << "\n";
        oss << "  " << brain.getLightDemonReport() << "\n";
        oss << "  " << brain.getBanditReport() << "\n";
        return oss.str();
    }

    return brain.analyzeQuery(query, hw, bbm);
}

void InteractiveConsole::start(const ai::HardwareResearchAI& hw, ai::IntelligenceCore& brain, ai::BossBattleManager& bbm) {
    consoleRunning = true;
    consoleThread = std::thread([this, &hw, &brain, &bbm]() {
        std::string line;
        std::cout << col("\n[AI CONSOLE v3]", C_CYAN) << " Type 'help' for commands, 'quit' to exit.\n";
        while (consoleRunning) {
            std::cout << col("> ", C_MAGENTA); std::cout.flush();
            if (!std::getline(std::cin, line)) { consoleRunning = false; break; }
            if (line.empty()) continue;
            std::string resp = analyze(line, hw, brain, bbm);
            if (resp == "__EXIT__") {
                std::cout << col("[AI] Leaving the console.\n", C_GREEN);
                consoleRunning = false; break;
            }
            std::cout << col("[AI] ", C_GREEN) << resp << std::endl;
        }
    });
}

void InteractiveConsole::stop() {
    consoleRunning = false;
    if (consoleThread.joinable()) consoleThread.join();
}

} // namespace pctune_up::ui
