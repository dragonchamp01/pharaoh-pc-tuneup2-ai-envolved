#include "pctune_up/ai/visualization.hpp"
#include "pctune_up/core/database.hpp"
#include "pctune_up/core/utils.hpp"
#include <sstream>
#include <map>

using namespace pctune_up::core;

namespace pctune_up::ai {

std::string VisualizationEngine::generateMermaidGraph() {
    if (!db) return "graph TD\n  DB[No Database Connection]";
    
    std::ostringstream m;
    m << "graph TD\n";
    m << "  classDef default fill:#1a1a2e,stroke:#ff4444,color:#e0e0ff\n";
    
    sqlite3_stmt* s;
    const char* sql = "SELECT source, target, relation, strength FROM knowledge_graph ORDER BY strength DESC LIMIT 20;";
    
    if (sqlite3_prepare_v2(db, sql, -1, &s, nullptr) == SQLITE_OK) {
        while (sqlite3_step(s) == SQLITE_ROW) {
            std::string src = (const char*)sqlite3_column_text(s, 0);
            std::string tgt = (const char*)sqlite3_column_text(s, 1);
            std::string rel = (const char*)sqlite3_column_text(s, 2);
            double str = sqlite3_column_double(s, 3);
            
            // Sanitize IDs (no spaces for mermaid node IDs)
            auto clean = [](std::string x) { 
                for (char& c : x) if (c == ' ' || c == '-' || c == '.') c = '_'; 
                return x; 
            };
            
            std::string srcId = clean(src);
            std::string tgtId = clean(tgt);
            
            m << "  " << srcId << "[\"" << src << "\"] -- \"" << rel << " (" << (int)(str*100) << "%)\" --> " << tgtId << "[\"" << tgt << "\"]\n";
        }
        sqlite3_finalize(s);
    } else {
        m << "  Error[Knowledge Graph Empty or Locked]\n";
    }
    
    return m.str();
}

std::string VisualizationEngine::getMachinePersonality(const HardwareResearchAI& hw) {
    std::string model = hw.cpuModel();
    int cores = hw.cores();
    
    if (model.find("Intel") != std::string::npos) {
        if (cores >= 8) return "The Great Architect — Meticulous, calculating, and authoritative. Every instruction is a decree.";
        return "The Efficient Bureaucrat — Optimized for stability and order. Preferring standard protocols.";
    } else if (model.find("AMD") != std::string::npos) {
        if (cores >= 12) return "The Desert Warlord — Brutally powerful, multi-threaded fury. Seizing performance by force.";
        return "The Ancient Mystic — Channeling pyramid frequencies. Unpredictable but capable of bursts of power.";
    }
    
    return "The Ghost in the Machine — An unknown entity with flickering instructions and shadowed origins.";
}

} // namespace pctune_up::ai
