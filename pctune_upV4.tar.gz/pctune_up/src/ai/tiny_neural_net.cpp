#include "pctune_up/ai/tiny_neural_net.hpp"
#include "pctune_up/core/colors.hpp"
#include "pctune_up/core/utils.hpp"
#include <iostream>
#include <fstream>
#include <sstream>
#include <cmath>
#include <random>
#include <algorithm>

using namespace pctune_up::core;

namespace pctune_up::ai {

TinyNeuralNet::TinyNeuralNet(const std::vector<int>& topo) : topology(topo), rng(std::random_device{}()) {
    for (size_t i = 1; i < topology.size(); i++) {
        layers.emplace_back(topology[i], topology[i-1]);
    }
}

std::vector<double> TinyNeuralNet::predict(const std::vector<double>& inputs) {
    std::vector<double> current = inputs;
    for (auto& layer : layers) {
        current = layer.forward(current);
    }
    return current;
}

void TinyNeuralNet::train(const std::vector<double>& inputs, const std::vector<double>& targets) {
    auto outputs = predict(inputs);
    if (outputs.size() != targets.size()) return;
    
    std::vector<std::vector<double>> layerOutputs;
    std::vector<double> current = inputs;
    for (auto& layer : layers) {
        current = layer.forward(current);
        layerOutputs.push_back(current);
    }
    
    for (int l = (int)layers.size() - 1; l >= 0; l--) {
        for (size_t n = 0; n < layers[l].neurons.size(); n++) {
            auto& neuron = layers[l].neurons[n];
            double error = 0;
            if (l == (int)layers.size() - 1) {
                error = targets[n] - neuron.output;
            } else {
                for (size_t k = 0; k < layers[l+1].neurons.size(); k++) {
                    error += layers[l+1].neurons[k].weights[n] * layers[l+1].neurons[k].delta;
                }
            }
            neuron.delta = error * neuron.output * (1 - neuron.output);
        }
    }
    
    for (size_t l = 0; l < layers.size(); l++) {
        const std::vector<double>& prevOutputs = (l == 0) ? inputs : layerOutputs[l-1];
        for (auto& neuron : layers[l].neurons) {
            for (size_t i = 0; i < neuron.weights.size(); i++) {
                neuron.weights[i] += learningRate * neuron.delta * prevOutputs[i];
            }
            neuron.bias += learningRate * neuron.delta;
        }
    }
}

void TinyNeuralNet::trainBatch(const std::vector<std::vector<double>>& inputs, 
                               const std::vector<std::vector<double>>& targets, int epochs) {
    for (int e = 0; e < epochs; e++) {
        for (size_t i = 0; i < inputs.size(); i++) {
            train(inputs[i], targets[i]);
        }
    }
}

void TinyNeuralNet::save(const std::string& path) {
    std::ofstream f(path);
    if (!f) return;
    f << topology.size() << "\n";
    for (int t : topology) f << t << " ";
    f << "\n";
    for (auto& layer : layers) {
        for (auto& n : layer.neurons) {
            f << n.bias << " ";
            for (double w : n.weights) f << w << " ";
            f << "\n";
        }
    }
}

void TinyNeuralNet::load(const std::string& path) {
    std::ifstream f(path);
    if (!f) return;
    size_t layersCount; f >> layersCount;
    topology.resize(layersCount);
    for (size_t i = 0; i < layersCount; i++) f >> topology[i];
    layers.clear();
    for (size_t i = 1; i < topology.size(); i++) {
        layers.emplace_back(topology[i], topology[i-1]);
        for (auto& n : layers.back().neurons) {
            f >> n.bias;
            for (double& w : n.weights) f >> w;
        }
    }
}

std::string TinyNeuralNet::getTopologyString() const {
    std::ostringstream ss;
    ss << "Topology: ";
    for (size_t i = 0; i < topology.size(); i++) {
        ss << topology[i];
        if (i < topology.size() - 1) ss << " -> ";
    }
    return ss.str();
}

std::vector<double> ConfigOptimizerNN::encodeConfig(const std::map<std::string, double>& config) {
    std::vector<double> features;
    // 6 features matching {6,6,6} topology
    static const std::vector<std::string> keys = {
        "swappiness", "vfs_cache_pressure", "dirty_ratio",
        "dirty_background_ratio", "hugepages", "zram_size"
    };
    for (const auto& k : keys) {
        auto it = config.find(k);
        features.push_back(it != config.end() ? it->second : 0.0);
    }
    return features;
}

std::map<std::string, double> ConfigOptimizerNN::decodeOutput(const std::vector<double>& output) {
    std::map<std::string, double> config;
    static const std::vector<std::string> keys = {
        "swappiness", "vfs_cache_pressure", "dirty_ratio",
        "dirty_background_ratio", "hugepages", "zram_size"
    };
    for (size_t i = 0; i < keys.size() && i < output.size(); i++) {
        config[keys[i]] = output[i];
    }
    return config;
}

ConfigOptimizerNN::ConfigOptimizerNN() : net({6, 6, 6}) {
    initializeWithDefaults();
}

void ConfigOptimizerNN::initializeWithDefaults() {
    // 6-feature inputs for {6,6,6} topology
    std::vector<std::vector<double>> inputs = {
        {60, 200, 30, 10, 0, 3},    // current
        {10, 50, 15, 5, 1024, 4},   // gaming
        {60, 200, 15, 5, 2048, 4},  // server
    };
    std::vector<std::vector<double>> targets = {
        {60, 200, 30, 10, 0, 3},
        {10, 50, 15, 5, 1024, 4},
        {60, 200, 15, 5, 2048, 4},
    };
    net.trainBatch(inputs, targets, 100);
    trained = true;
}

std::map<std::string, double> ConfigOptimizerNN::optimize(const std::map<std::string, double>& currentConfig, 
                                                           const std::map<std::string, double>& performance) {
    auto input = encodeConfig(currentConfig);
    auto output = net.predict(input);
    return decodeOutput(output);
}

void ConfigOptimizerNN::learnFromResult(const std::map<std::string, double>& config, 
                                        const std::map<std::string, double>& beforePerf,
                                        const std::map<std::string, double>& afterPerf) {
    double improvement = 0;
    for (auto& p : afterPerf) {
        auto it = beforePerf.find(p.first);
        if (it != beforePerf.end() && it->second > 0) {
            improvement += (p.second - it->second) / it->second;
        }
    }
    if (improvement > 0) {
        auto input = encodeConfig(config);
        auto target = encodeConfig(config);
        for (auto& t : target) t *= 1.0 + improvement * 0.1;
        net.train(input, target);
    }
}

} // namespace pctune_up::ai