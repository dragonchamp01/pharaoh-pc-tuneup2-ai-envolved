#include "pctune_up/optimizers/disk.hpp"
#include "pctune_up/core/config.hpp"
#include "pctune_up/core/colors.hpp"
#include "pctune_up/core/utils.hpp"
#include <iostream>

using namespace pctune_up::core;

namespace pctune_up::optimizers {

void optimizeDisk() {
    std::cout << "\n=== " << col("Disk Optimization", C_BLUE) << " ===" << std::endl;

    runCmd("df -h /", "Disk usage before");

    // Package caches
    runCmd("apt-get clean -y 2>/dev/null", "Cleaning apt cache");
    runCmd("apt-get autoclean -y 2>/dev/null", "Cleaning old packages");
    runCmd("apt-get autoremove -y 2>/dev/null", "Removing orphan packages");

    // Flatpak
    runCmd("flatpak uninstall --unused -y 2>/dev/null",
           "Cleaning unused flatpak runtimes");

    // Snap
    runCmd("snap list 2>/dev/null | awk 'NR>1 {print $1}' | xargs -r snap remove --revision 2>/dev/null",
           "Cleaning old snap revisions");

    // Docker
    runCmd("docker system prune -f 2>/dev/null", "Pruning docker system");

    // Logs
    runCmd("journalctl --vacuum-time=3d 2>/dev/null",
           "Vacuuming journal (keep 3 days)");
    runCmd("find /var/log -type f \\( -name '*.log' -o -name '*.gz' \\) -exec truncate -s 0 {} \\; 2>/dev/null",
           "Truncating old log files");

    // Trim
    runCmd("fstrim -av 2>/dev/null", "Running fstrim on SSDs");

    // Dirty writeback tuning
    runCmd("sysctl vm.dirty_writeback_centisecs=1000 >/dev/null 2>&1",
           "Setting dirty writeback interval");
    runCmd("sysctl vm.dirty_expire_centisecs=500 >/dev/null 2>&1",
           "Setting dirty expire interval");

    // Remount noatime if dangerous
    if (cfg.dangerous) {
        std::string mounts = captureCmd("mount | grep ' / ' | grep -v noatime 2>/dev/null");
        if (!mounts.empty()) {
            runCmd("mount -o remount,noatime,nodiratime / 2>/dev/null",
                   "[DANGER] Remounting root with noatime");
        }
    }

    runCmd("df -h /", "Disk usage after");
}

} // namespace pctune_up::optimizers
