#include <iostream>
#include <csignal>
#include <thread>
#include <fstream>
#include <ctime>
#include <iomanip>
#include "pctune_up/core/config.hpp"
#include "pctune_up/core/colors.hpp"
#include "pctune_up/core/utils.hpp"
#include "pctune_up/core/database.hpp"
#include "pctune_up/core/signals.hpp"
#include "pctune_up/optimizers/cpu.hpp"
#include "pctune_up/optimizers/ram.hpp"
#include "pctune_up/optimizers/disk.hpp"
#include "pctune_up/optimizers/network.hpp"
#include "pctune_up/optimizers/gpu.hpp"
#include "pctune_up/optimizers/system.hpp"
#include "pctune_up/optimizers/profiles.hpp"
#include "pctune_up/ai/occult_research.hpp"
#include "pctune_up/ai/hardware_research.hpp"
#include "pctune_up/ai/intelligence_core.hpp"
#include "pctune_up/ai/hardware_comparator.hpp"
#include "pctune_up/ai/boss_battles.hpp"
#include "pctune_up/ai/quantum_core.hpp"
#include "pctune_up/ai/quantum_research.hpp"
#include "pctune_up/ai/web_search_ai.hpp"
#include "pctune_up/ai/tiny_neural_net.hpp"
#include "pctune_up/diagnostic/doctor.hpp"
#include "pctune_up/diagnostic/benchmark.hpp"
#include "pctune_up/admin/tasks.hpp"
#include "pctune_up/ui/console.hpp"
#include "pctune_up/ui/dashboard.hpp"
#include "pctune_up/ui/reports.hpp"

using namespace pctune_up::core;
using namespace pctune_up::optimizers;
using namespace pctune_up::ai;
using namespace pctune_up::diagnostic;
using namespace pctune_up::admin;
using namespace pctune_up::ui;

void printUsage(const char* name) {
    std::cout << "Usage: " << name << " [options]" << std::endl;
    std::cout << "  --help           Show this help" << std::endl;
    std::cout << "  --dry-run        Show what would be done" << std::endl;
    std::cout << "  --doctor         Run DOCTOR analysis" << std::endl;
    std::cout << "  --doctor-apply   Apply doctor prescriptions" << std::endl;
    std::cout << "  --interactive    Interactive AI console" << std::endl;
    std::cout << "  --research       One-shot hardware research" << std::endl;
    std::cout << "  --intelligence   Show AI insights" << std::endl;
    std::cout << "  --benchmark      Run benchmarks" << std::endl;
    std::cout << "  --gaming         Enable Gaming Mode (performance & process cleanup)" << std::endl;
    std::cout << "  --server-web     Enable Server Profile: Web (network focus)" << std::endl;
    std::cout << "  --server-db      Enable Server Profile: DB (disk/ram focus)" << std::endl;
    std::cout << "  --all-admin      Run all admin tasks" << std::endl;
    std::cout << "  --html-report    Generate HTML report in reports/ folder" << std::endl;
    std::cout << "  --auto-maintain  Run auto-maintenance tasks in loop" << std::endl;
    std::cout << "  --interval N     Set cycle interval" << std::endl;
    std::cout << "  --quantum        Enable Quantum Research Mode" << std::endl;
    std::cout << "  --quantum-boost  Enable Hellfire Quantum Boost" << std::endl;
    std::cout << "  --light-demon    Enable Light Demon benevolent AI" << std::endl;
    std::cout << "  --devil-ai       Enable Devil AI aggressive optimization" << std::endl;
    std::cout << "  --devil-manifest Print Quantum Devil PC proof manifest" << std::endl;
    std::cout << "  --no-color       Disable colored output" << std::endl;
}

bool parseFlags(int argc, char** argv) {
    for (int i = 1; i < argc; i++) {
        std::string a = argv[i];
        if (a == "--help") { printUsage(argv[0]); return false; }
        else if (a == "--dry-run") cfg.dryRun = true;
        else if (a == "--dangerous") cfg.dangerous = true;
        else if (a == "--doctor") cfg.doctorMode = true;
        else if (a == "--doctor-apply") { cfg.doctorMode = true; cfg.applyDoctor = true; }
        else if (a == "--research") cfg.researchMode = true;
        else if (a == "--interactive") cfg.interactive = true;
        else if (a == "--intelligence") cfg.intelligenceMode = true;
        else if (a == "--benchmark") cfg.benchmarkMode = true;
        else if (a == "--gaming") cfg.gamingMode = true;
        else if (a == "--server-web") cfg.serverWebMode = true;
        else if (a == "--server-db") cfg.serverDBMode = true;
        else if (a == "--all-admin") cfg.adminMode = true;
        else if (a == "--html-report") cfg.htmlReport = true;
        else if (a == "--auto-maintain") cfg.autoMaintain = true;
        else if (a == "--interval") {
            if (i + 1 < argc) {
                try { cfg.cycleInt = std::stoi(argv[++i]); }
                catch(...) { std::cerr << "Invalid interval." << std::endl; }
            }
        }
        else if (a == "--quantum") cfg.quantumMode = true;
        else if (a == "--quantum-boost") { cfg.quantumMode = true; cfg.quantumBoost = true; }
        else if (a == "--light-demon") cfg.lightDemon = true;
        else if (a == "--devil-ai") cfg.devilAI = true;
        else if (a == "--devil-manifest") cfg.devilManifest = true;
        else if (a == "--no-color") cfg.color = false;
    }
    return true;
}

int main(int argc, char** argv) {
    if (!parseFlags(argc, argv)) return 0;
    if (!isRoot()) { std::cout << col("[!] Run as root.", C_RED) << std::endl; return 1; }

    std::signal(SIGINT, handleSignal);
    std::signal(SIGTERM, handleSignal);

    initDatabase();
    OccultResearchAI ai;
    DoctorPCCleanup doctor;
    HardwareResearchAI hwAI;
    BenchmarkEngine bench;
    IntelligenceCore brain;
    InteractiveConsole console;
    ProfileManager profiles;
    BossBattleManager bbm;
    QuantumCore quantum;
    QuantumResearchAI qResearch;

    hwAI.fullResearch();

    // Load previous neural weights if available
    brain.loadNeuralWeights();

    if (cfg.lightDemon) {
        brain.enableLightDemon(true);
        std::cout << col("[MAIN]", C_CYAN) << " Light Demon mode activated. Benevolent optimization engaged." << std::endl;
    }
    if (cfg.devilAI) {
        brain.enableDevilAI(true);
        std::cout << col("[MAIN]", C_RED) << " Devil AI mode activated. Aggressive optimization at your own risk." << std::endl;
    }

    if (cfg.devilManifest) {
        qResearch.setHardwareRef(&hwAI);
        auto result = qResearch.fullResearch();
        std::cout << result.devilManifest << std::endl;
        if (!cfg.quantumMode && !cfg.interactive && !cfg.benchmarkMode && !cfg.doctorMode
            && !cfg.gamingMode && !cfg.serverWebMode && !cfg.serverDBMode && !cfg.adminMode) {
            closeDatabase();
            return 0;
        }
    }

    if (cfg.quantumMode) {
        qResearch.setHardwareRef(&hwAI);
        auto result = qResearch.fullResearch();
        qResearch.saveHTMLIfFindings(result);

        // Print the Devil Manifest
        std::cout << result.devilManifest << std::endl;

        if (cfg.quantumBoost) {
            quantum.reset(8);
            quantum.applyQuantumBoost();
        }

        if (!cfg.interactive && !cfg.benchmarkMode && !cfg.doctorMode
            && !cfg.gamingMode && !cfg.serverWebMode && !cfg.serverDBMode && !cfg.adminMode) {
            closeDatabase();
            return 0;
        }
    }

    if (cfg.researchMode) {
        hwAI.fullResearch();
        hwAI.printExtensiveReport();
        hwAI.saveMarkdownReport();
        closeDatabase();
        return 0;
    }

    if (cfg.interactive) {
        console.setQuantumRefs(&qResearch, &quantum);
        console.start(hwAI, brain, bbm);
        while (running && console.running())
            std::this_thread::sleep_for(std::chrono::milliseconds(200));
        console.stop();
        closeDatabase();
        return 0;
    }

    if (cfg.adminMode) {
        optimizeSystemd(); optimizeSecurity(); updatePackages();
        auditSystem(); optimizeBoot(); manageCron();
        closeDatabase();
        return 0;
    }

    if (cfg.benchmarkMode) bench.runBefore();

    int cycle = 1;

    if (cfg.gamingMode) profiles.applyGamingProfile();
    if (cfg.serverWebMode) profiles.applyServerWebProfile();
    if (cfg.serverDBMode) profiles.applyServerDBProfile();

    while (running) {
        std::cout << col(">>> Cycle ", C_CYAN) << cycle << col(" @ ", C_CYAN) << ts() << std::endl;

        brain.runCycle();
        bbm.harvestSouls();
        ai.doResearchCycle(cycle);

        if (cfg.quantumMode) {
            if (cycle % 5 == 0) {
                auto result = qResearch.fullResearch();
                qResearch.saveHTMLIfFindings(result);
            }
            if (cfg.quantumBoost) {
                quantum.applyQuantumBoost();
            }
        }

        if (!cfg.gamingMode && !cfg.serverWebMode && !cfg.serverDBMode) {
            auto recommendations = brain.decideAction(brain.getDetectedPatterns());
            if (recommendations.empty()) {
                optimizeCPU(); optimizeRAM(); optimizeDisk(); optimizeSystem();
            } else {
                std::cout << col(">>> AI RECOMMENDS: ", C_MAGENTA);
                for (size_t i = 0; i < recommendations.size(); ++i)
                    std::cout << recommendations[i] << (i == recommendations.size() - 1 ? "" : ", ");
                std::cout << std::endl;

                for (const auto& rec : recommendations) {
                    std::cout << col("  [AI] Executing: ", C_GREEN) << rec << " optimization..." << std::endl;
                    if (rec == "CPU") optimizeCPU();
                    else if (rec == "RAM") optimizeRAM();
                    else if (rec == "DISK") optimizeDisk();
                    else if (rec == "GPU") optimizeGPU();
                    else if (rec == "NETWORK") optimizeNetwork();
                }
            }
        } else if (cfg.gamingMode) {
            profiles.applyGamingProfile();
        } else if (cfg.serverWebMode) {
            profiles.applyServerWebProfile();
        } else if (cfg.serverDBMode) {
            profiles.applyServerDBProfile();
        }

        if (cfg.doctorMode || cfg.autoMaintain) {
            doctor.runDiagnosis();
            if (cfg.applyDoctor || cfg.autoMaintain) doctor.applyPrescriptions();
            else doctor.printReport();
        }

        if (cfg.htmlReport) {
            std::string insightsStr;
            for (auto& in : brain.getInsights()) insightsStr += in + "\n";
            std::string html = generateHTMLReport(hwAI, doctor.getFullReport(),
                bench.cpuBefore, bench.memBefore, bench.diskBefore,
                cycle, doctor.getHealthScore(), insightsStr);
            saveHTMLReport(html);
        }

        int elapsed = 0;
        while (elapsed < cfg.cycleInt && running) {
            std::this_thread::sleep_for(std::chrono::seconds(10));
            elapsed += 10;
        }
        cycle++;
    }

    if (cfg.benchmarkMode) {
        bench.runAfter();
        bench.printComparison();
        bench.learn(brain);
    }

    brain.saveNeuralWeights();
    closeDatabase();
    std::cout << col("\n[OK] Shutdown complete. Neural weights preserved.", C_GREEN) << std::endl;
    return 0;
}
