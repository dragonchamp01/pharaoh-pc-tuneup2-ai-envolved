#pragma once

namespace pctune_up::optimizers {

void optimizeCPU();

} // namespace pctune_up::optimizers
