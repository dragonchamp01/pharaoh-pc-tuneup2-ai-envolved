#pragma once
#include <vector>
#include <string>
#include <random>

namespace pctune_up::ai {

class HardwareResearchAI {
private:
    struct CPUFeatures {
        std::string modelName, vendor, arch;
        int cores = 0, threads = 0;
        double maxFreqMHz = 0;
        std::vector<std::string> flags;
        std::string cacheInfo, topology, microcode, stepping;
    };
    struct MemInfo {
        long totalKB = 0, availKB = 0, freeKB = 0;
        long swapTotalKB = 0, swapFreeKB = 0;
    };
    struct DiskInfo {
        std::string device, size, smartStatus; bool isSSD = false;
    };
    struct DeepProbe {
        std::string msrRaw, cpuidRaw, acpiTables, interrupts, ioPorts;
        std::string netDevices, kernelMods, procTree, memMap;
    };

    CPUFeatures cpu; MemInfo mem;
    std::vector<DiskInfo> disks;
    std::vector<std::string> pciDevices;
    std::string dmiBios, dmiBoard, dmiSystem, systemUUID;
    std::string thermalZone;
    std::vector<std::string> generatedOpcodes, occultAnalysis;
    DeepProbe deep;
    std::mt19937 rng;
    int upgradeRound = 0;
    std::vector<std::string> grimoire;
    std::vector<std::string> rituals;

    // ---- PROBES ----
    void probeCPU();
    void probeMemory();
    void probePCI();
    void probeStorage();
    void probeDMI();
    void probeThermal();

    // ---- DEEP PROBES ----
    void probeMSR();
    void probeCPUID();
    void probeACPI();
    void probeInterrupts();
    void probeIOPorts();
    void probeNetwork();
    void probeKernelModules();
    void probeProcessTree();
    void probeMemMap();

    // ---- OPCODES ----
    void generateOpcodes();

    // ---- RITUAL & GRIMOIRE ----
    void generateRituals();
    void upgradeGrimoire();
    void generateOccultAnalysis();

    std::string sanitizeForFilename(const std::string& s);

public:
    HardwareResearchAI();

    void fullResearch();
    void printSmallReport();
    void printExtensiveReport();
    std::string generateMarkdownReport();
    void saveMarkdownReport();

    int flagCount() const { return (int)cpu.flags.size(); }
    int opcodeCount() const { return (int)generatedOpcodes.size(); }
    int getUpgradeRound() const { return upgradeRound; }
    std::string cpuModel() const { return cpu.modelName; }
    int cores() const { return cpu.cores; }
    int threads() const { return cpu.threads; }
};

} // namespace pctune_up::ai
