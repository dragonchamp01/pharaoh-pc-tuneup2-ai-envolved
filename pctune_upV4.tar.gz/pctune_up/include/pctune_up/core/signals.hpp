#pragma once
#include <atomic>

namespace pctune_up::core {

extern std::atomic<bool> running;

void handleSignal(int sig);

} // namespace pctune_up::core
