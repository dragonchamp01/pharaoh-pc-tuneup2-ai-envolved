#pragma once

namespace pctune_up::optimizers {

void optimizeDisk();

} // namespace pctune_up::optimizers
