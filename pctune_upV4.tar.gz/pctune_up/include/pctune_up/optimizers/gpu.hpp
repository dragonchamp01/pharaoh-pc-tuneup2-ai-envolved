#pragma once

namespace pctune_up::optimizers {

void probeGPU();
void optimizeGPU();

} // namespace pctune_up::optimizers
