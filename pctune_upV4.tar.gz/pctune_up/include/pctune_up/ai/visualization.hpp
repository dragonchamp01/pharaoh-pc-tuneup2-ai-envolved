#pragma once
#include <string>
#include <vector>
#include "pctune_up/ai/hardware_research.hpp"

namespace pctune_up::ai {

class VisualizationEngine {
public:
    std::string generateMermaidGraph();
    std::string getMachinePersonality(const HardwareResearchAI& hw);
};

} // namespace pctune_up::ai
