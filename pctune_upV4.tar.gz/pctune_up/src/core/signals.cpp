#include "pctune_up/core/signals.hpp"
#include <iostream>

namespace pctune_up::core {

std::atomic<bool> running{true};

void handleSignal(int) {
    std::cout << "\n[!] Shutdown signal received. Cleaning up..." << std::endl;
    running = false;
}

} // namespace pctune_up::core
