#pragma once
#include <vector>
#include <string>
#include <deque>
#include <random>
#include <map>
#include <unordered_map>
#include <fstream>
#include <mutex>
#include "pctune_up/ai/hardware_research.hpp"
#include "pctune_up/ai/tiny_neural_net.hpp"

namespace pctune_up::ai {

class IntelligenceCore {
private:
    struct MetricHistory {
        std::deque<double> temps, loads, memPcts, swapPcts, diskPcts, netRx, netTx;
        size_t maxSamples = 300;
    };
    MetricHistory history;

    struct DetectedPattern {
        std::string name, description, recommendation;
        double confidence;
        std::string severity;
        std::vector<double> embedding;
    };
    std::vector<DetectedPattern> currentPatterns;

    TinyNeuralNet optimizerNN;
    TinyNeuralNet criticNN;
    TinyNeuralNet targetCriticNN;
    std::mt19937 rng;
    std::vector<std::string> insights;

    struct AdaptiveThreshold {
        double baselineMean = 0, baselineStd = 0;
        int sampleCount = 0;
        void update(double v);
        bool isAnomalous(double v) const;
        double currentZ(double v) const;
    };
    AdaptiveThreshold tempThresh, loadThresh, memThresh, swapThresh, diskThresh, netThresh;

    struct ProcessInfo {
        std::string name, cpu, mem;
        double cpuPct = 0, memPct = 0;
        int pid = 0;
    };
    std::vector<ProcessInfo> topProcs;

    struct Trend { double slope, intercept, r2; std::string direction; };

    // Light Demon Mode - benevolent optimization within RAM constraints
    struct LightDemonState {
        bool active = false;
        double targetRamUsagePct = 70.0;
        double currentEfficiency = 0.0;
        int optimizationCycles = 0;
        std::map<std::string, double> processScores;
        void updateEfficiency(double memPct, double swapPct, double cpuPct);
        bool shouldOptimizeProcess(const std::string& name, double memPct) const;
    };
    LightDemonState lightDemon;

    // Devil AI Mode - real aggressive optimization counterpart
    struct DevilAIState {
        bool active = false;
        double aggressionLevel = 0.0;       // 0.0 - 1.0, trained by neural net
        double targetPerformance = 95.0;    // Performance target
        int processesTerminated = 0;
        double overclockLevel = 0.0;        // 0.0 - 1.0
        double currentAggression = 0.0;
        std::map<std::string, int> hitList;

        void updateAggression(double cpuLoad, double memPct, double temp);
        bool shouldTerminateProcess(const std::string& name, double cpuPct, double memPct) const;
    };
    DevilAIState devilAI;

    // Real AI: Experience Replay Buffer
    struct Experience {
        std::vector<double> state;
        std::vector<double> action;
        double reward;
        std::vector<double> nextState;
        bool done;
        int cycle;
    };
    std::deque<Experience> replayBuffer;
    const size_t maxReplaySize = 10000;
    std::mutex replayMutex;

    // Real AI: Multi-Armed Bandit (UCB1) for optimization selection
    struct BanditArm {
        std::string name;
        int pulls = 0;
        double totalReward = 0.0;
        double ucbValue = 0.0;
        std::vector<double> contextRewards;
        std::mutex mutex;
        
        double meanReward() const { return pulls > 0 ? totalReward / pulls : 0.0; }
        void update(double reward) { 
            std::lock_guard<std::mutex> lock(mutex);
            totalReward += reward; 
            pulls++; 
        }
    };
    std::map<std::string, BanditArm> optimizationBandits;

    // Real AI: Knowledge Graph with Embeddings
    struct KnowledgeNode {
        std::string kgConcept;
        std::map<std::string, double> relations;
        std::vector<double> embedding;
        int accessCount;
        double confidence;
    };
    std::map<std::string, KnowledgeNode> knowledgeGraph;
    std::mutex kgMutex;

    // Real AI: Meta-learning state
    struct MetaState {
        double learningRate = 0.01;
        double explorationRate = 0.3;
        double discountFactor = 0.95;
        int updateFrequency = 4;
        double targetUpdateTau = 0.005;
        int cyclesSinceUpdate = 0;
    } meta;

    // Enhanced learning
    struct LearnedOptimization {
        std::string pattern;
        std::string action;
        double successRate;
        int applications;
        double avgImprovement;
        std::vector<double> stateEmbedding;
    };
    std::vector<LearnedOptimization> learnedOpts;

    void collectProcessMetrics();
    double getMetric(const std::string& cmd);
    void sampleMetrics();
    std::string autoTriage(const std::string& anomalyContext);
    Trend linearTrend(const std::deque<double>& data);
    std::vector<DetectedPattern> detectPatterns();

    // Real AI methods
    std::vector<double> encodeState();
    std::vector<double> encodeAction(const std::string& action);
    double computeReward(const std::vector<double>& beforeState, const std::vector<double>& afterState);
    void storeExperience(const Experience& exp);
    void trainFromReplay(int batchSize = 32);
    double ucbSelect(const std::vector<std::string>& actions);
    void updateBandit(const std::string& action, double reward);
    void autoCorrelate();
    void updateKnowledgeGraph(const std::string& pattern, const std::string& action, double reward);
    void metaLearn();
    std::vector<double> getPatternEmbedding(const std::string& pattern);
    double cosineSimilarity(const std::vector<double>& a, const std::vector<double>& b);

    struct CriticalPrediction {
        std::string metric;
        double currentValue, criticalThreshold;
        double estimatedSeconds;
        std::string humanReadable;
    };
    CriticalPrediction predictCritical(const std::deque<double>& data, double criticalValue, const std::string& metricName);

    void recordCorrelation(const std::string& src, const std::string& tgt, const std::string& rel, double strength);

    // Light Demon methods
    void activateLightDemon();
    void lightDemonCycle();
    std::string lightDemonAdvice();

    // Devil AI methods
    void activateDevilAI();
    void devilCycle();
    std::string devilAdvice();
    void learnFromOutcome(const std::string& pattern, const std::string& action, double improvement);

    // Enhanced NLP
    struct Entity { std::string type, value; };
    std::vector<Entity> extractEntities(const std::string& query);

public:
    IntelligenceCore();

    struct IntentResult { std::string action; double confidence; };
    IntentResult classifyIntent(const std::string& query);
    std::string analyzeQuery(const std::string& query, const HardwareResearchAI& hw, class BossBattleManager& bbm);
    void generateInsights();
    void runCycle();
    std::string consolidateKnowledge();
    std::vector<std::string> decideAction(const std::vector<DetectedPattern>& patterns);
    void learnFromBenchmark(double beforeScore, double afterScore, const std::string& component);
    std::string suggestOptimizations();
    std::vector<std::string> getInsights();
    std::vector<DetectedPattern> getDetectedPatterns() const;

    // Light Demon API
    void enableLightDemon(bool enable = true);
    bool isLightDemonActive() const { return lightDemon.active; }
    std::string getLightDemonReport();
    std::string getLightDemonAdvice() { return lightDemonAdvice(); }

    // Devil AI API
    void enableDevilAI(bool enable = true);
    bool isDevilAIActive() const { return devilAI.active; }
    std::string getDevilAIReport();
    double getDevilAggression() const { return devilAI.currentAggression; }

    // Console / monitoring API
    size_t getReplaySize() const { return replayBuffer.size(); }
    size_t getGraphSize() const { return knowledgeGraph.size(); }
    int getTrainingCycles() const { return meta.cyclesSinceUpdate; }
    size_t getInsightCount() const { return insights.size(); }
    std::string getBanditReport();

    // NN persistence
    void saveNeuralWeights(const std::string& path = "brain_weights.dat");
    void loadNeuralWeights(const std::string& path = "brain_weights.dat");
};

} // namespace pctune_up::ai