#pragma once
#include <string>

namespace pctune_up::core {

const std::string C_RED     = "\033[1;31m";
const std::string C_GREEN   = "\033[1;32m";
const std::string C_YELLOW  = "\033[1;33m";
const std::string C_BLUE    = "\033[1;34m";
const std::string C_MAGENTA = "\033[1;35m";
const std::string C_CYAN    = "\033[1;36m";
const std::string C_RESET   = "\033[0m";
const std::string C_BOLD    = "\033[1m";

} // namespace pctune_up::core
