#include "pctune_up/core/utils.hpp"
#include "pctune_up/core/config.hpp"
#include "pctune_up/core/colors.hpp"
#include <iostream>
#include <fstream>
#include <ctime>
#include <sys/stat.h>
#include <unistd.h>

namespace pctune_up::core {

std::string col(const std::string& t, const std::string& c) {
    if (!cfg.color) return t;
    return c + t + C_RESET;
}

std::string ts() {
    time_t now = time(nullptr);
    char buf[64];
    strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S", localtime(&now));
    return std::string(buf);
}

void runCmdSilent(const std::string& cmd) {
    if (cfg.dryRun) return;
    int rc = system(cmd.c_str());
    (void)rc;
}

void runCmd(const std::string& cmd, const std::string& desc) {
    std::cout << col("[", C_CYAN) << ts() << col("]", C_CYAN) << " "
              << desc << "..." << std::endl;
    if (cfg.dryRun) {
        std::cout << col("  [DRY-RUN] Would run: ", C_YELLOW) << cmd << std::endl;
        return;
    }
    int r = system(cmd.c_str());
    if (r != 0)
        std::cout << col("  [!] Returned: ", C_RED) << r << " (non-fatal)" << std::endl;
}

std::string captureCmd(const std::string& cmd) {
    std::string r;
    FILE* p = popen(cmd.c_str(), "r");
    if (!p) return "";
    char buf[256];
    while (fgets(buf, sizeof(buf), p)) r += buf;
    pclose(p);
    return r;
}

bool isRoot() { return geteuid() == 0; }
bool fileExists(const std::string& p) { struct stat st; return stat(p.c_str(), &st) == 0; }

bool writeFile(const std::string& path, const std::string& content) {
    if (cfg.dryRun) {
        std::cout << col("  [DRY-RUN] Write ", C_YELLOW) << path << ": " << content << std::endl;
        return true;
    }
    std::ofstream f(path);
    if (!f) return false;
    f << content;
    return true;
}

} // namespace pctune_up::core
