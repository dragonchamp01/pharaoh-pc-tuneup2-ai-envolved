#include "pctune_up/core/database.hpp"
#include "pctune_up/core/colors.hpp"
#include "pctune_up/core/utils.hpp"
#include <iostream>

namespace pctune_up::core {

sqlite3* db = nullptr;
const std::string DB_PATH = "/media/marco/e-learning/coding_projects/ai_projects/pctune_up/research.db";

void initDatabase() {
    std::string dir = "/media/marco/e-learning/coding_projects/ai_projects/pctune_up";
    std::string mk = "mkdir -p \"" + dir + "\"";
    (void)system(mk.c_str());

    if (sqlite3_open(DB_PATH.c_str(), &db) != SQLITE_OK) {
        std::cerr << col("[!] FAILED to open database: ", C_RED) << sqlite3_errmsg(db) << std::endl;
        return;
    }
    std::cout << col("[OK] Database: ", C_GREEN) << DB_PATH << std::endl;

    const char* sql =
        "CREATE TABLE IF NOT EXISTS research_log ("
        "  id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "  component TEXT NOT NULL,"
        "  topic TEXT NOT NULL,"
        "  finding TEXT NOT NULL,"
        "  curse_level INTEGER DEFAULT 0,"
        "  cycle INTEGER DEFAULT 0,"
        "  timestamp DATETIME DEFAULT CURRENT_TIMESTAMP"
        ");"
        "CREATE TABLE IF NOT EXISTS upgrade_progress ("
        "  id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "  component TEXT UNIQUE NOT NULL,"
        "  current_level INTEGER DEFAULT 0,"
        "  target_level INTEGER DEFAULT 100,"
        "  progress_percent REAL DEFAULT 0.0,"
        "  last_researched DATETIME DEFAULT CURRENT_TIMESTAMP"
        ");"
        "CREATE TABLE IF NOT EXISTS doctor_log ("
        "  id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "  diagnosis TEXT NOT NULL,"
        "  health_score INTEGER DEFAULT 0,"
        "  prescriptions TEXT,"
        "  timestamp DATETIME DEFAULT CURRENT_TIMESTAMP"
        ");";

    char* err = nullptr;
    if (sqlite3_exec(db, sql, nullptr, nullptr, &err) != SQLITE_OK) {
        std::cerr << col("[!] SQL: ", C_RED) << err << std::endl;
        sqlite3_free(err);
    }

    const char* init =
        "INSERT OR IGNORE INTO upgrade_progress (component,current_level,target_level,progress_percent) VALUES "
        "('CPU',0,100,0.0),('RAM',0,100,0.0),('BIOS',0,100,0.0),('DISK',0,100,0.0);";
    err = nullptr;
    if (sqlite3_exec(db, init, nullptr, nullptr, &err) != SQLITE_OK) {
        std::cerr << col("[!] SQL: ", C_RED) << err << std::endl;
        sqlite3_free(err);
    }
}

void closeDatabase() { if (db) sqlite3_close(db); }

void saveResearch(const std::string& comp, const std::string& topic, const std::string& finding, int cl, int cyc) {
    if (!db) return;
    sqlite3_stmt* s;
    const char* sql = "INSERT INTO research_log (component,topic,finding,curse_level,cycle) VALUES (?,?,?,?,?);";
    if (sqlite3_prepare_v2(db, sql, -1, &s, nullptr) != SQLITE_OK) return;
    sqlite3_bind_text(s, 1, comp.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(s, 2, topic.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(s, 3, finding.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_int(s, 4, cl);
    sqlite3_bind_int(s, 5, cyc);
    sqlite3_step(s);
    sqlite3_finalize(s);
}

void updateProgress(const std::string& comp, int add, int tgt) {
    if (!db) return;
    sqlite3_stmt* s;
    const char* sql = "UPDATE upgrade_progress SET current_level=MIN(current_level+?,target_level), progress_percent=(CAST(current_level+? AS REAL)/CAST(? AS REAL))*100.0, last_researched=CURRENT_TIMESTAMP WHERE component=?;";
    if (sqlite3_prepare_v2(db, sql, -1, &s, nullptr) != SQLITE_OK) return;
    sqlite3_bind_int(s, 1, add);
    sqlite3_bind_int(s, 2, add);
    sqlite3_bind_int(s, 3, tgt);
    sqlite3_bind_text(s, 4, comp.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_step(s);
    sqlite3_finalize(s);
}

void showResearchSummary() {
    if (!db) return;
    std::cout << "\n--- " << col("Research Database Summary", C_CYAN) << " ---" << std::endl;
    sqlite3_stmt* s;
    const char* sql = "SELECT component,current_level,target_level,ROUND(progress_percent,1) FROM upgrade_progress ORDER BY component;";
    if (sqlite3_prepare_v2(db, sql, -1, &s, nullptr) != SQLITE_OK) return;
    while (sqlite3_step(s) == SQLITE_ROW) {
        std::string c = (const char*)sqlite3_column_text(s, 0);
        int cur = sqlite3_column_int(s, 1);
        int tgt = sqlite3_column_int(s, 2);
        double pct = sqlite3_column_double(s, 3);
        std::cout << "  " << col(c, C_BOLD) << ": " << cur << "/" << tgt
                  << " (" << col(std::to_string(pct).substr(0, std::to_string(pct).find(".")+2)+"%", C_GREEN) << ")" << std::endl;
    }
    sqlite3_finalize(s);

    sqlite3_prepare_v2(db, "SELECT COUNT(*) FROM research_log;", -1, &s, nullptr);
    if (sqlite3_step(s) == SQLITE_ROW)
        std::cout << "  Total findings: " << col(std::to_string(sqlite3_column_int(s, 0)), C_MAGENTA) << std::endl;
    sqlite3_finalize(s);
}

} // namespace pctune_up::core
