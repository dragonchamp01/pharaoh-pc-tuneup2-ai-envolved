#include "pctune_up/ui/dashboard.hpp"
#include "pctune_up/core/colors.hpp"
#include "pctune_up/core/utils.hpp"
#include "pctune_up/core/signals.hpp"
#include <iostream>
#include <iomanip>
#include <sstream>
#include <thread>

using namespace pctune_up::core;

namespace pctune_up::ui {

void renderDashboard(const ai::HardwareResearchAI& hw, int cycle, time_t startTime, int gpuCount) {
    const int W = 80;
    std::string loadStr = captureCmd("cat /proc/loadavg | awk '{print $1\", \"$2\", \"$3}' 2>/dev/null");
    std::string memStr = captureCmd("free -h | grep Mem | awk '{print $3\"/\"$2}' 2>/dev/null");
    std::string cpuTemp = captureCmd("cat /sys/class/thermal/thermal_zone0/temp 2>/dev/null");
    if (!cpuTemp.empty()) { try { double t = std::stod(cpuTemp) / 1000.0; cpuTemp = std::to_string((int)t) + "C"; } catch(...){ cpuTemp="?"; } }
    std::string uptime = captureCmd("uptime -p 2>/dev/null | sed 's/up //'");

    std::ostringstream dash; dash << "\033[2J\033[H";
    dash << col("╔" + std::string(W-2, '=') + "╗\n", C_CYAN);
    dash << col("║", C_CYAN) << "  pcTune_Up v4.0 — ARCHDEVIL DASHBOARD  " << col("║\n", C_CYAN);
    dash << col("╠" + std::string(22, '=') + "╦" + std::string(22, '=') + "╦" + std::string(28, '=') + "╣\n", C_CYAN);
    dash << col("║", C_CYAN) << " CPU: " << std::left << std::setw(14) << hw.cpuModel().substr(0, 14)
         << col("║", C_CYAN) << " MEM: " << std::left << std::setw(14) << (memStr.empty() ? "?" : memStr)
         << col("║", C_CYAN) << " Cycle: " << std::left << std::setw(16) << std::to_string(cycle) << col("║\n", C_CYAN);
    dash << col("║", C_CYAN) << " Load: " << std::left << std::setw(14) << loadStr
         << col("║", C_CYAN) << " Temp: " << std::left << std::setw(14) << cpuTemp
         << col("║", C_CYAN) << " Round: " << std::left << std::setw(16) << std::to_string(hw.getUpgradeRound()) << col("║\n", C_CYAN);
    dash << col("╚" + std::string(W-2, '=') + "╝\n", C_CYAN);
    std::cout << dash.str();
}

void startDashboard(const ai::HardwareResearchAI& hw, int cycle, time_t startTime, int gpuCount) {
    while (running) {
        renderDashboard(hw, cycle, startTime, gpuCount);
        for (int i = 0; i < 20 && running; i++) std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
}

} // namespace pctune_up::ui
