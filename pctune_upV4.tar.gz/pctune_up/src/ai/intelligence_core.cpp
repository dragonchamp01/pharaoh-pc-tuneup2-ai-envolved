#include "pctune_up/ai/intelligence_core.hpp"
#include "pctune_up/ai/boss_battles.hpp"
#include "pctune_up/core/colors.hpp"
#include "pctune_up/core/utils.hpp"
#include "pctune_up/core/database.hpp"
#include <iostream>
#include <sstream>
#include <cmath>
#include <algorithm>
#include <iomanip>
#include <chrono>
#include <iomanip>
#include <map>

using namespace pctune_up::core;

namespace pctune_up::ai {

IntelligenceCore::IntelligenceCore() : optimizerNN({6, 6, 6}), criticNN({6, 6, 6}), targetCriticNN({6, 6, 6}), rng(std::chrono::steady_clock::now().time_since_epoch().count()) {
    // Initialize NN's
    // In a real scenario, we'd load weights here
    
    if (db) {
        sqlite3_exec(db, "CREATE TABLE IF NOT EXISTS intelligence_log (id INTEGER PRIMARY KEY AUTOINCREMENT, category TEXT NOT NULL, content TEXT NOT NULL, confidence REAL DEFAULT 0.5, timestamp DATETIME DEFAULT CURRENT_TIMESTAMP);", nullptr, nullptr, nullptr);
        sqlite3_exec(db, "CREATE TABLE IF NOT EXISTS knowledge_graph (id INTEGER PRIMARY KEY AUTOINCREMENT, source TEXT NOT NULL, target TEXT NOT NULL, relation TEXT NOT NULL, strength REAL DEFAULT 0.5, timestamp DATETIME DEFAULT CURRENT_TIMESTAMP, UNIQUE(source, target, relation));", nullptr, nullptr, nullptr);
    }
}

void IntelligenceCore::LightDemonState::updateEfficiency(double memPct, double swapPct, double cpuPct) {
    double memScore = (memPct < targetRamUsagePct) ? 1.0 : (targetRamUsagePct / memPct);
    double swapPenalty = (swapPct > 5.0) ? (1.0 / (1.0 + swapPct/10.0)) : 1.0;
    currentEfficiency = memScore * swapPenalty;
    optimizationCycles++;
}

bool IntelligenceCore::LightDemonState::shouldOptimizeProcess(const std::string& name, double memPct) const {
    return memPct > 10.0;
}

void IntelligenceCore::DevilAIState::updateAggression(double cpuLoad, double memPct, double temp) {
    double loadScore = std::min(1.0, cpuLoad / 4.0);
    double memScore = std::min(1.0, memPct / 100.0);
    double tempScore = std::min(1.0, temp / 90.0);
    currentAggression = (loadScore * 0.5 + memScore * 0.3 + tempScore * 0.2);
    aggressionLevel = currentAggression;
    overclockLevel = std::min(1.0, overclockLevel + currentAggression * 0.01);
}

bool IntelligenceCore::DevilAIState::shouldTerminateProcess(const std::string& name, double cpuPct, double memPct) const {
    if (!active) return false;
    double threshold = 30.0 * (1.0 - aggressionLevel);
    bool cpuHog = cpuPct > threshold;
    bool memHog = memPct > threshold * 0.8;
    bool onHitList = hitList.count(name) && hitList.at(name) > 2;
    return (cpuHog || memHog || onHitList);
}

void IntelligenceCore::AdaptiveThreshold::update(double v) {
    if (sampleCount == 0) { baselineMean = v; baselineStd = 0.5; sampleCount = 1; return; }
    sampleCount++;
    double oldMean = baselineMean;
    baselineMean = oldMean + (v - oldMean) / sampleCount;
    baselineStd = sqrt(((sampleCount - 1) * baselineStd * baselineStd + (v - oldMean) * (v - baselineMean)) / sampleCount);
    if (baselineStd < 0.1) baselineStd = 0.1;
}

bool IntelligenceCore::AdaptiveThreshold::isAnomalous(double v) const {
    if (sampleCount < 5 || baselineStd < 0.01) return false;
    return abs(v - baselineMean) / baselineStd > (sampleCount > 30 ? 2.5 : 2.0);
}

double IntelligenceCore::AdaptiveThreshold::currentZ(double v) const {
    if (baselineStd < 0.01) return 0;
    return (v - baselineMean) / baselineStd;
}

void IntelligenceCore::recordCorrelation(const std::string& src, const std::string& tgt, const std::string& rel, double strength) {
    if (!db) return;
    sqlite3_stmt* s;
    const char* sql = "INSERT INTO knowledge_graph (source, target, relation, strength) VALUES (?, ?, ?, ?) "
                      "ON CONFLICT(source, target, relation) DO UPDATE SET strength = (strength * 0.8) + (EXCLUDED.strength * 0.2), timestamp = CURRENT_TIMESTAMP;";
    if (sqlite3_prepare_v2(db, sql, -1, &s, nullptr) == SQLITE_OK) {
        sqlite3_bind_text(s, 1, src.c_str(), -1, SQLITE_TRANSIENT);
        sqlite3_bind_text(s, 2, tgt.c_str(), -1, SQLITE_TRANSIENT);
        sqlite3_bind_text(s, 3, rel.c_str(), -1, SQLITE_TRANSIENT);
        sqlite3_bind_double(s, 4, strength);
        sqlite3_step(s);
        sqlite3_finalize(s);
    }
}

void IntelligenceCore::autoCorrelate() {
    if (history.temps.size() < 5) return;
    double t = history.temps.back(), l = history.loads.back(), m = history.memPcts.back(), s = history.swapPcts.back();
    if (l > 1.5 && t > 60) recordCorrelation("CPU Load", "CPU Temp", "causes", 0.8);
    if (m > 80 && s > 10) recordCorrelation("RAM Usage", "Swap Usage", "triggers", 0.9);
    if (l > 2.0 && m > 80) recordCorrelation("High Load", "High RAM", "correlates", 0.7);
    for (auto& p : topProcs) {
        if (p.cpuPct > 40.0) recordCorrelation(p.name, "CPU Load", "dominates", 0.85);
        if (p.memPct > 20.0) recordCorrelation(p.name, "RAM Usage", "consumes", 0.80);
    }
}

void IntelligenceCore::runCycle() {
    sampleMetrics();
    autoCorrelate();
    currentPatterns = detectPatterns();
    generateInsights();
    if (lightDemon.active) {
        lightDemonCycle();
    }
    if (devilAI.active) {
        devilCycle();
    }
    metaLearn();
    trainFromReplay();
}

std::vector<IntelligenceCore::DetectedPattern> IntelligenceCore::getDetectedPatterns() const {
    return currentPatterns;
}

void IntelligenceCore::sampleMetrics() {
    std::string tempStr = captureCmd("cat /sys/class/thermal/thermal_zone0/temp 2>/dev/null");
    if (!tempStr.empty()) history.temps.push_back(std::stod(tempStr) / 1000.0);
    std::string loadStr = captureCmd("cat /proc/loadavg | awk '{print $1}' 2>/dev/null");
    if (!loadStr.empty()) history.loads.push_back(std::stod(loadStr));
    std::string memStr = captureCmd("free | grep Mem | awk '{print $3/$2*100}' 2>/dev/null");
    if (!memStr.empty()) history.memPcts.push_back(std::stod(memStr));
    std::string swapStr = captureCmd("free | grep Swap | awk '{if($2>0) print $3/$2*100; else print 0}' 2>/dev/null");
    if (!swapStr.empty()) history.swapPcts.push_back(std::stod(swapStr));
    std::string diskStr = captureCmd("df / | tail -1 | awk '{print $5}' | tr -d '%' 2>/dev/null");
    if (!diskStr.empty()) history.diskPcts.push_back(std::stod(diskStr));

    if (!history.temps.empty()) tempThresh.update(history.temps.back());
    if (!history.loads.empty()) loadThresh.update(history.loads.back());
    if (!history.memPcts.empty()) memThresh.update(history.memPcts.back());
    if (!history.swapPcts.empty()) swapThresh.update(history.swapPcts.back());
    if (!history.diskPcts.empty()) diskThresh.update(history.diskPcts.back());

    if (history.temps.size() > history.maxSamples) history.temps.pop_front();
    if (history.loads.size() > history.maxSamples) history.loads.pop_front();
    if (history.memPcts.size() > history.maxSamples) history.memPcts.pop_front();
    if (history.swapPcts.size() > history.maxSamples) history.swapPcts.pop_front();
    if (history.diskPcts.size() > history.maxSamples) history.diskPcts.pop_front();

    collectProcessMetrics();
}

void IntelligenceCore::collectProcessMetrics() {
    topProcs.clear();
    std::string raw = captureCmd("ps aux --sort=-%cpu 2>/dev/null | head -8 | tail -6");
    std::istringstream ss(raw); std::string line;
    while (getline(ss, line)) {
        std::istringstream ls(line);
        std::string user, pid, cpu, mem, vsz, rss, tty, stat, st, cmd;
        ls >> user >> pid >> cpu >> mem >> vsz >> rss >> tty >> stat >> st;
        getline(ls, cmd);
        ProcessInfo p; p.name = cmd.substr(0, 40);
        try { p.cpuPct = std::stod(cpu); p.memPct = std::stod(mem); } catch(...) { continue; }
        p.pid = std::stoi(pid);
        topProcs.push_back(p);
    }
}

void IntelligenceCore::generateInsights() {
    insights.clear();
    auto checkAdaptive = [&](AdaptiveThreshold& th, double v, const std::string& name) {
        if (!th.isAnomalous(v)) return;
        insights.push_back("ANOMALY [" + name + "]: " + std::to_string((int)v) + " (z=" + std::to_string(th.currentZ(v)) + ")");
    };
    if (!history.temps.empty()) checkAdaptive(tempThresh, history.temps.back(), "Temp");
    if (!history.memPcts.empty()) checkAdaptive(memThresh, history.memPcts.back(), "Mem");
    for (auto& p : currentPatterns) insights.push_back("PATTERN [" + p.name + "]: " + p.description);
    
    if (lightDemon.active) {
        insights.push_back("LIGHT DEMON: Optimizing for efficiency...");
        insights.push_back("LIGHT DEMON: Neural efficiency at " + std::to_string((int)(lightDemon.currentEfficiency * 100)) + "%");
    }
    if (devilAI.active) {
        insights.push_back("DEVIL AI: Aggression at " + std::to_string((int)(devilAI.aggressionLevel * 100)) + "%");
        insights.push_back("DEVIL AI: " + std::to_string(devilAI.processesTerminated) + " processes terminated");
    }
}

std::vector<IntelligenceCore::DetectedPattern> IntelligenceCore::detectPatterns() {
    std::vector<DetectedPattern> pats; if (history.temps.size() < 5) return pats;
    double t = history.temps.back(), l = history.loads.back(), m = history.memPcts.back(), s = history.swapPcts.back(), d = history.diskPcts.back();
    if (m > 80 && s > 20 && t > 60) pats.push_back({"MEMORY_PRESSURE", "High memory (" + std::to_string((int)m)+"%) + swap ("+std::to_string((int)s)+"%) + temp ("+std::to_string((int)t)+"C)", "Close heavy apps or add swap.", 0.85, "HIGH"});
    if (t > 75 && l > 2.0) pats.push_back({"THERMAL_THROTTLE_RISK", "CPU temp " + std::to_string((int)t)+"C with load " + std::to_string(l), "Check cooling.", 0.75, "CRITICAL"});
    if (d > 90) pats.push_back({"DISK_NEAR_CAPACITY", "Disk usage at " + std::to_string((int)d)+"%", "Run --doctor.", 0.90, "MEDIUM"});
    for (auto& p : topProcs) {
        if (p.cpuPct > 50.0) pats.push_back({"CPU_HOG", "Process '" + p.name + "' using " + p.cpu + "% CPU", "Kill or renice.", 0.80, "MEDIUM"});
        if (p.memPct > 25.0) pats.push_back({"MEMORY_HOG", "Process '" + p.name + "' using " + p.mem + "% memory", "Check leaks.", 0.75, "MEDIUM"});
    }
    return pats;
}

std::string IntelligenceCore::autoTriage(const std::string& anomalyContext) {
    std::ostringstream r; r << "AUTO-TRIAGE for: " << anomalyContext << "\n";
    if (anomalyContext.find("Temp") != std::string::npos) r << "  THERMAL DIAGNOSTIC: Freq=" << captureCmd("cat /proc/cpuinfo | grep -m1 'cpu MHz' | cut -d: -f2") << " Fans=" << captureCmd("sensors 2>/dev/null | grep -i fan | head -2");
    if (anomalyContext.find("Memory") != std::string::npos) r << "  MEMORY DIAGNOSTIC: Top=" << captureCmd("ps aux --sort=-%mem | head -3 | tail -2 | awk '{print $11\": \"$4\"%\"}'");
    return r.str();
}

IntelligenceCore::Trend IntelligenceCore::linearTrend(const std::deque<double>& data) {
    Trend t = {0, 0, 0, "stable"}; size_t n = data.size(); if (n < 3) return t;
    double sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
    for (size_t i = 0; i < n; i++) { sumX += i; sumY += data[i]; sumXY += i * data[i]; sumX2 += i * i; }
    double denom = n * sumX2 - sumX * sumX; if (std::abs(denom) < 0.001) return t;
    t.slope = (n * sumXY - sumX * sumY) / denom; t.intercept = (sumY - t.slope * sumX) / n;
    double ssTot = 0, ssRes = 0, yMean = sumY / n;
    for (size_t i = 0; i < n; i++) { double yPred = t.intercept + t.slope * i; ssTot += (data[i] - yMean) * (data[i] - yMean); ssRes += (data[i] - yPred) * (data[i] - yPred); }
    t.r2 = ssTot > 0 ? 1.0 - ssRes / ssTot : 0;
    t.direction = std::abs(t.slope) < 0.01 ? "stable" : (t.slope > 0 ? "rising" : "falling");
    return t;
}

IntelligenceCore::CriticalPrediction IntelligenceCore::predictCritical(const std::deque<double>& data, double criticalValue, const std::string& metricName) {
    CriticalPrediction cp = {metricName, 0, criticalValue, -1, "Insufficient data"}; if (data.size() < 3) return cp;
    cp.currentValue = data.back(); auto tr = linearTrend(data); if (std::abs(tr.slope) < 0.001) { cp.humanReadable = metricName + " stable"; return cp; }
    double stepsToCritical = (criticalValue - tr.intercept) / tr.slope; double remainingSteps = stepsToCritical - (data.size() - 1);
    if (remainingSteps <= 0) { cp.humanReadable = metricName + " reached critical"; cp.estimatedSeconds = 0; return cp; }
    cp.estimatedSeconds = remainingSteps * history.maxSamples;
    cp.humanReadable = metricName + " will reach " + std::to_string((int)criticalValue) + " in " + std::to_string((int)(cp.estimatedSeconds/60)) + "m";
    return cp;
}

// REAL AI IMPLEMENTATIONS

std::vector<double> IntelligenceCore::encodeState() {
    std::vector<double> state;
    state.push_back(history.temps.empty() ? 0 : history.temps.back() / 100.0);
    state.push_back(history.loads.empty() ? 0 : history.loads.back() / 10.0);
    state.push_back(history.memPcts.empty() ? 0 : history.memPcts.back() / 100.0);
    state.push_back(history.swapPcts.empty() ? 0 : history.swapPcts.back() / 100.0);
    state.push_back(history.diskPcts.empty() ? 0 : history.diskPcts.back() / 100.0);
    
    // Add some context from patterns
    for(size_t i=0; i<5; ++i) {
        if(i < currentPatterns.size()) state.push_back(currentPatterns[i].confidence);
        else state.push_back(0.0);
    }
    return state;
}

std::vector<double> IntelligenceCore::encodeAction(const std::string& action) {
    std::vector<double> vec(6, 0.0);
    if (action == "CPU") vec[0] = 1.0;
    else if (action == "RAM") vec[1] = 1.0;
    else if (action == "DISK") vec[2] = 1.0;
    else if (action == "GPU") vec[3] = 1.0;
    else if (action == "NETWORK") vec[4] = 1.0;
    else if (action == "SYSTEM") vec[5] = 1.0;
    return vec;
}

double IntelligenceCore::computeReward(const std::vector<double>& before, const std::vector<double>& after) {
    double reward = 0;
    if (after[0] < before[0]) reward += (before[0] - after[0]) * 10.0; // Temp decrease
    if (after[1] < before[1]) reward += (before[1] - after[1]) * 5.0;  // Load decrease
    if (after[2] < before[2]) reward += (before[2] - after[2]) * 2.0;  // RAM decrease
    return reward;
}

void IntelligenceCore::storeExperience(const Experience& exp) {
    std::lock_guard<std::mutex> lock(replayMutex);
    if (replayBuffer.size() >= maxReplaySize) replayBuffer.pop_front();
    replayBuffer.push_back(exp);
}

void IntelligenceCore::trainFromReplay(int batchSize) {
    if ((int)replayBuffer.size() < batchSize) return;
    
    std::lock_guard<std::mutex> lock(replayMutex);
    // Sample a batch and train optimizerNN
    // For simplicity, we train on a random sample
    for(int i=0; i<batchSize; ++i) {
        int idx = std::uniform_int_distribution<int>(0, (int)replayBuffer.size()-1)(rng);
        const auto& exp = replayBuffer[idx];
        
        std::vector<double> targets = exp.action;
        // Scale targets by reward
        for(auto& t : targets) t *= exp.reward;
        
        optimizerNN.train({exp.state}, {targets});
    }
}

double IntelligenceCore::ucbSelect(const std::vector<std::string>& actions) {
    double maxUcb = -1e9;
    int bestIdx = 0;
    int totalPulls = 0;
    for (auto& a : actions) totalPulls += optimizationBandits[a].pulls;
    
    for (size_t i=0; i<actions.size(); ++i) {
        const auto& arm = optimizationBandits[actions[i]];
        double ucb = arm.meanReward() + std::sqrt(2.0 * std::log(totalPulls + 1) / (arm.pulls + 1e-6));
        if (ucb > maxUcb) { maxUcb = ucb; bestIdx = i; }
    }
    return (double)bestIdx;
}

void IntelligenceCore::updateBandit(const std::string& action, double reward) {
    optimizationBandits[action].update(reward);
}

void IntelligenceCore::updateKnowledgeGraph(const std::string& pattern, const std::string& action, double reward) {
    std::lock_guard<std::mutex> lock(kgMutex);
    KnowledgeNode& node = knowledgeGraph[pattern];
    node.kgConcept = pattern;
    node.relations[action] = (node.relations[action] * 0.9) + (reward * 0.1);
    node.accessCount++;
    node.confidence = std::min(1.0, node.confidence + 0.01);
}

void IntelligenceCore::metaLearn() {
    meta.cyclesSinceUpdate++;
    if (meta.cyclesSinceUpdate >= meta.updateFrequency) {
        // Simple meta-adaptation: if rewards are low, increase exploration
        meta.explorationRate = std::max(0.1, meta.explorationRate * 0.99);
        meta.cyclesSinceUpdate = 0;
    }
}

std::vector<double> IntelligenceCore::getPatternEmbedding(const std::string& pattern) {
    std::lock_guard<std::mutex> lock(kgMutex);
    if (knowledgeGraph.count(pattern)) return knowledgeGraph[pattern].embedding;
    
    // Generate pseudo-embedding
    std::vector<double> emb(6, 0.0);
    for(size_t i=0; i<pattern.length() && i<6; ++i) emb[i] = (double)pattern[i] / 255.0;
    return emb;
}

double IntelligenceCore::cosineSimilarity(const std::vector<double>& a, const std::vector<double>& b) {
    if (a.size() != b.size()) return 0;
    double dot = 0, normA = 0, normB = 0;
    for(size_t i=0; i<a.size(); ++i) {
        dot += a[i] * b[i]; normA += a[i]*a[i]; normB += b[i]*b[i];
    }
    return dot / (sqrt(normA) * sqrt(normB) + 1e-9);
}

void IntelligenceCore::activateDevilAI() {
    enableDevilAI(true);
}

void IntelligenceCore::enableDevilAI(bool enable) {
    devilAI.active = enable;
    if (enable) {
        std::cout << col("[DEVIL AI]", C_RED) << " Aggressive optimization mode activated. Performance at any cost." << std::endl;
    } else {
        std::cout << col("[DEVIL AI]", C_RED) << " Devil AI deactivated." << std::endl;
    }
}

void IntelligenceCore::devilCycle() {
    double currentLoad = history.loads.empty() ? 0 : history.loads.back();
    double currentMem = history.memPcts.empty() ? 0 : history.memPcts.back();
    double currentTemp = history.temps.empty() ? 0 : history.temps.back();

    std::vector<double> state = encodeState();
    std::vector<double> nnOutput = optimizerNN.predict(state);
    double nnAggression = nnOutput.empty() ? 0.5 : std::abs(nnOutput[0]);

    devilAI.updateAggression(currentLoad, currentMem, currentTemp);
    devilAI.aggressionLevel = (devilAI.aggressionLevel + nnAggression * 0.3) / 1.3;

    for (auto& p : topProcs) {
        if (devilAI.shouldTerminateProcess(p.name, p.cpuPct, p.memPct)) {
            devilAI.hitList[p.name]++;
            if (devilAI.hitList[p.name] >= 3 && p.pid > 0) {
                std::string killCmd = "kill -9 " + std::to_string(p.pid) + " 2>/dev/null";
                captureCmd(killCmd);
                devilAI.processesTerminated++;
                learnFromOutcome("PROCESS_KILL", "RAM", 2.0);
            }
        }
    }

    // Real system aggressive tuning when Devil AI is active
    if (devilAI.aggressionLevel > 0.4) {
        captureCmd("sysctl -w vm.swappiness=10 >/dev/null 2>&1");
        captureCmd("sysctl -w vm.vfs_cache_pressure=50 >/dev/null 2>&1");
        captureCmd("sysctl -w vm.dirty_ratio=40 >/dev/null 2>&1");
        captureCmd("sysctl -w vm.dirty_background_ratio=5 >/dev/null 2>&1");
        learnFromOutcome("SYSCTL_TUNE", "SYSTEM", 1.0);
    }
    if (devilAI.aggressionLevel > 0.6) {
        captureCmd("sysctl -w kernel.sched_min_granularity_ns=10000000 >/dev/null 2>&1");
        captureCmd("sysctl -w kernel.sched_wakeup_granularity_ns=15000000 >/dev/null 2>&1");
        captureCmd("sysctl -w kernel.numa_balancing=0 >/dev/null 2>&1");
        for (int cpu = 0; cpu < 128; cpu++) {
            std::string path = "/sys/devices/system/cpu/cpu" + std::to_string(cpu) + "/cpufreq/scaling_governor";
            std::string test = captureCmd("cat " + path + " 2>/dev/null");
            if (!test.empty()) captureCmd("echo performance > " + path + " 2>/dev/null");
        }
        captureCmd("sysctl -w net.core.rmem_max=134217728 >/dev/null 2>&1");
        captureCmd("sysctl -w net.core.wmem_max=134217728 >/dev/null 2>&1");
        learnFromOutcome("AGGRESSIVE_TUNE", "CPU", 2.0);
    }
    if (devilAI.aggressionLevel > 0.8) {
        captureCmd("sysctl -w kernel.sched_autogroup_enabled=0 >/dev/null 2>&1");
        captureCmd("sysctl -w kernel.random.write_wakeup_threshold=1 >/dev/null 2>&1");
        std::string schedulers = captureCmd("cat /sys/block/*/queue/scheduler 2>/dev/null | head -1");
        if (schedulers.find("[none]") == std::string::npos) {
            for (char c = 'a'; c <= 'z'; c++) {
                std::string dev = std::string(1, c);
                captureCmd("echo none > /sys/block/" + dev + "/queue/scheduler 2>/dev/null");
                captureCmd("echo 2 > /sys/block/" + dev + "/queue/nomerges 2>/dev/null");
            }
        }
        learnFromOutcome("MAX_AGGRESSION", "DISK", 3.0);
    }
}

std::string IntelligenceCore::devilAdvice() {
    if (!devilAI.active) return "Devil AI is dormant.";
    std::ostringstream oss;
    oss << "Devil AI: Aggression at " << std::to_string((int)(devilAI.aggressionLevel * 100)) << "%"
        << " | " << devilAI.processesTerminated << " processes terminated"
        << " | Overclock level: " << std::to_string((int)(devilAI.overclockLevel * 100)) << "%";
    return oss.str();
}

std::string IntelligenceCore::getBanditReport() {
    std::ostringstream oss;
    oss << "UCB1 Bandit Arms:\n";
    for (const auto& [name, arm] : optimizationBandits) {
        oss << "  " << name << ": " << arm.pulls << " pulls, avg reward "
            << std::fixed << std::setprecision(3) << arm.meanReward() << "\n";
    }
    return oss.str();
}

std::string IntelligenceCore::getDevilAIReport() {
    if (!devilAI.active) return "Devil AI is inactive.";
    std::ostringstream oss;
    oss << "DEVIL AI REPORT:\n";
    oss << "  Aggression: " << std::to_string((int)(devilAI.aggressionLevel * 100)) << "%\n";
    oss << "  Processes Terminated: " << devilAI.processesTerminated << "\n";
    oss << "  Overclock Level: " << std::to_string((int)(devilAI.overclockLevel * 100)) << "%\n";
    oss << "  Target Performance: " << devilAI.targetPerformance << "%\n";
    oss << "  Hit List: " << devilAI.hitList.size() << " entries\n";
    return oss.str();
}

void IntelligenceCore::activateLightDemon() {
    enableLightDemon(true);
}

void IntelligenceCore::enableLightDemon(bool enable) {
    lightDemon.active = enable;
    if (enable) {
        std::cout << col("[LIGHT DEMON]", C_CYAN) << " Benevolent optimization mode activated. Aiming for efficiency within 8GB RAM limit." << std::endl;
    } else {
        std::cout << col("[LIGHT DEMON]", C_CYAN) << " Benevolent mode deactivated." << std::endl;
    }
}

void IntelligenceCore::lightDemonCycle() {
    double currentMem = history.memPcts.empty() ? 0 : history.memPcts.back();
    double currentSwap = history.swapPcts.empty() ? 0 : history.swapPcts.back();
    double currentCpu = history.loads.empty() ? 0 : history.loads.back();
    
    lightDemon.updateEfficiency(currentMem, currentSwap, currentCpu);
    
    for (auto& p : topProcs) {
        if (lightDemon.shouldOptimizeProcess(p.name, p.memPct)) {
            lightDemon.processScores[p.name] += 0.1;
        }
    }
}

std::string IntelligenceCore::lightDemonAdvice() {
    if (!lightDemon.active) return "Light Demon is sleeping.";
    if (lightDemon.currentEfficiency < 0.5) return "Light Demon: Efficiency low. Need to purge non-essential processes.";
    return "Light Demon: Systems are optimally efficient for 8GB RAM environment.";
}

std::string IntelligenceCore::getLightDemonReport() {
    if (!lightDemon.active) return "Light Demon is inactive.";
    std::ostringstream oss;
    oss << "LIGHT DEMON REPORT:\n";
    oss << "  Efficiency: " << std::to_string((int)(lightDemon.currentEfficiency * 100)) << "%\n";
    oss << "  Target RAM: " << lightDemon.targetRamUsagePct << "%\n";
    oss << "  Optimization Cycles: " << lightDemon.optimizationCycles << "\n";
    return oss.str();
}

void IntelligenceCore::learnFromOutcome(const std::string& pattern, const std::string& action, double improvement) {
    // Reinforcement Learning Step
    std::vector<double> state = encodeState();
    std::vector<double> actVec = encodeAction(action);
    
    storeExperience({state, actVec, improvement, state, false, 0});
    updateBandit(action, improvement);
    updateKnowledgeGraph(pattern, action, improvement);
}

IntelligenceCore::IntentResult IntelligenceCore::classifyIntent(const std::string& query) {
    std::string q = query; std::transform(q.begin(), q.end(), q.begin(), ::tolower);
    std::map<std::string, double> scores;
    auto score = [&](const std::vector<std::string>& keywords, const std::string& intent, double w) {
        double s = 0; for (auto& k : keywords) if (q.find(k) != std::string::npos) s += w;
        if (s > 0) scores[intent] += s;
    };
    score({"cpu", "processor"}, "cpu", 1.0); score({"memory", "ram"}, "ram", 1.0); score({"disk", "drive"}, "disks", 1.0);
    score({"gpu", "graphics"}, "gpu", 1.0); score({"network", "net"}, "network", 1.0); score({"opcode", "hex"}, "opcodes", 1.0);
    score({"round", "upgrade"}, "round", 1.0); score({"ritual", "ceremony"}, "rituals", 1.0); score({"status", "health"}, "status", 1.0);
    score({"demon", "devil", "light"}, "demons", 1.0); score({"help", "command"}, "help", 1.0); score({"quit", "exit"}, "quit", 1.0);
    score({"predict", "future"}, "predict", 1.0); score({"anomaly", "strange"}, "anomalies", 1.0); score({"insight", "intelligence"}, "insights", 1.0);
    score({"triage", "diagnose"}, "triage", 1.0); score({"pattern", "detect"}, "patterns", 1.0); score({"decide", "action"}, "decisions", 1.0);
    score({"process", "hog"}, "processes", 1.0); score({"threshold", "baseline"}, "thresholds", 1.0);
    score({"battle", "fight", "demon", "exorcise", "light"}, "battle", 1.2);
    score({"manifest", "certify", "proof"}, "manifest", 1.5);
    score({"quantum", "qubit", "coherence"}, "quantum", 1.3);
    score({"bandit", "ucb", "arm"}, "bandit", 1.0);
    score({"neural", "brain", "network", "topology"}, "neural", 1.2);
    score({"report"}, "report", 0.8);
    std::string best = "unknown"; double bs = 0; for (auto& p : scores) if (p.second > bs) { bs = p.second; best = p.first; }
    return {best, bs / 5.0};
}

std::string IntelligenceCore::analyzeQuery(const std::string& query, const HardwareResearchAI& hw, BossBattleManager& bbm) {
    auto intent = classifyIntent(query);
    if (intent.action == "cpu") return "CPU: " + hw.cpuModel() + " | " + std::to_string(hw.cores()) + "C/" + std::to_string(hw.threads()) + "T";
    if (intent.action == "status") return "STATUS: Round " + std::to_string(hw.getUpgradeRound());
    if (intent.action == "predict") { generateInsights(); std::string r = "PREDICTIVE:"; for (auto& i : insights) r += "\n  - " + i; return r; }
    if (intent.action == "battle") { bbm.startInteractiveBattle(); return "Battle concluded. The spirits have been dealt with."; }
    if (intent.action == "help") return "Commands: cpu ram disks gpu network opcodes round rituals status predict anomalies insights triage patterns decisions consolidate processes thresholds battle help quit";
    if (intent.action == "quit") return "__EXIT__";
    if (intent.action == "demons") {
        if (query.find("light") != std::string::npos) return lightDemonAdvice();
        if (query.find("devil") != std::string::npos || query.find("aggression") != std::string::npos) return devilAdvice();
        return "The abyss is dark. Command the demons, invoke the Devil AI, or call upon the Light Demon.";
    }
    return "The CPU whispers, but I cannot understand \"" + query + "\"";
}

std::string IntelligenceCore::consolidateKnowledge() { return "KNOWLEDGE CONSOLIDATION: Historical data stored in research.db"; }

std::vector<std::string> IntelligenceCore::decideAction(const std::vector<DetectedPattern>& patterns) {
    if (patterns.empty()) return {};
    
    std::vector<std::string> possibleActions = {"CPU", "RAM", "DISK", "GPU", "NETWORK"};
    std::vector<std::string> recommendations;
    
    // Multi-Armed Bandit Selection (UCB1)
    double bestUcb = -1e9;
    std::string bestAction = "";
    
    for (const auto& action : possibleActions) {
        double ucb = optimizationBandits[action].meanReward() + 
                     std::sqrt(2.0 * std::log(100 + 1) / (optimizationBandits[action].pulls + 1e-6));
        if (ucb > bestUcb) { bestUcb = ucb; bestAction = action; }
    }
    
    if (!bestAction.empty()) recommendations.push_back(bestAction);
    
    // Also add pattern-based recommendations for stability
    for (const auto& p : patterns) {
        if (p.name == "MEMORY_PRESSURE" || p.name == "MEMORY_HOG") recommendations.push_back("RAM");
        else if (p.name == "CPU_HOG" || p.name == "THERMAL_THROTTLE_RISK") recommendations.push_back("CPU");
        else if (p.name == "DISK_NEAR_CAPACITY") recommendations.push_back("DISK");
    }
    
    std::sort(recommendations.begin(), recommendations.end());
    recommendations.erase(std::unique(recommendations.begin(), recommendations.end()), recommendations.end());
    return recommendations;
}

void IntelligenceCore::learnFromBenchmark(double b, double a, const std::string& c) {
    if (!db) return;
    sqlite3_stmt* s;
    double d = a - b;
    if (sqlite3_prepare_v2(db, "INSERT INTO intelligence_log (category,content,confidence) VALUES (?,?,?);", -1, &s, nullptr) == SQLITE_OK) {
        std::string con = c + " delta=" + std::to_string(d);
        sqlite3_bind_text(s, 1, "self_learn", -1, SQLITE_TRANSIENT); sqlite3_bind_text(s, 2, con.c_str(), -1, SQLITE_TRANSIENT);
        sqlite3_bind_double(s, 3, 0.8); sqlite3_step(s); sqlite3_finalize(s);
    }

    // RL Step: reward the action that caused this improvement
    std::vector<double> state = encodeState();
    std::vector<double> actionVec = encodeAction(c);
    storeExperience({state, actionVec, d, state, false, 0});
    updateBandit(c, d);
}

std::string IntelligenceCore::suggestOptimizations() { return "SUGGESTION: Run --benchmark to learn more."; }
std::vector<std::string> IntelligenceCore::getInsights() { generateInsights(); return insights; }

void IntelligenceCore::saveNeuralWeights(const std::string& path) {
    optimizerNN.save("optimizer_" + path);
    criticNN.save("critic_" + path);
    targetCriticNN.save("target_critic_" + path);
    std::cout << col("[BRAIN]", C_GREEN) << " Neural weights saved to " << path << "*" << std::endl;
}

void IntelligenceCore::loadNeuralWeights(const std::string& path) {
    optimizerNN.load("optimizer_" + path);
    criticNN.load("critic_" + path);
    targetCriticNN.load("target_critic_" + path);
    std::cout << col("[BRAIN]", C_CYAN) << " Neural weights loaded from " << path << "*" << std::endl;
}

} // namespace pctune_up::ai
