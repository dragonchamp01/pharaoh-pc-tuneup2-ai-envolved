#pragma once
#include <string>

namespace pctune_up::core {

std::string col(const std::string& t, const std::string& c);
std::string ts();
void runCmdSilent(const std::string& cmd);
void runCmd(const std::string& cmd, const std::string& desc);
std::string captureCmd(const std::string& cmd);
bool isRoot();
bool fileExists(const std::string& p);
bool writeFile(const std::string& path, const std::string& content);

} // namespace pctune_up::core
