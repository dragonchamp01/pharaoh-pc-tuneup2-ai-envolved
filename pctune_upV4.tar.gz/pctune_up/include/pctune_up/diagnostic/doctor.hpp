#pragma once
#include <string>
#include <vector>

namespace pctune_up::diagnostic {

class DoctorPCCleanup {
private:
    struct Prescription { std::string issue, fix; int severity; };
    std::vector<Prescription> prescriptions;
    int healthScore = 100;
    std::string report;

    void analyzeSystem();
    void addPrescription(const std::string& i, const std::string& f, int s);

public:
    DoctorPCCleanup();
    void runDiagnosis();
    void applyPrescriptions();
    void printReport();
    std::string getFullReport() const { return report; }
    int getHealthScore() const { return healthScore; }
};

} // namespace pctune_up::diagnostic
