#include "pctune_up/diagnostic/benchmark.hpp"
#include "pctune_up/core/colors.hpp"
#include "pctune_up/core/utils.hpp"
#include "pctune_up/ai/intelligence_core.hpp"
#include <iostream>
#include <chrono>
#include <vector>
#include <numeric>

using namespace pctune_up::core;

namespace pctune_up::diagnostic {

double BenchmarkEngine::cpuBench() {
    auto start = std::chrono::steady_clock::now();
    volatile long long sum = 0;
    for (long long i = 0; i < 500000000LL; i++) sum += i;
    auto end = std::chrono::steady_clock::now();
    double elapsed = std::chrono::duration<double>(end - start).count();
    return 1000.0 / elapsed;
}

double BenchmarkEngine::memBench() {
    size_t size = 128 * 1024 * 1024; // 128MB
    std::vector<char> src(size, 1), dst(size, 0);
    auto start = std::chrono::steady_clock::now();
    std::copy(src.begin(), src.end(), dst.begin());
    auto end = std::chrono::steady_clock::now();
    double elapsed = std::chrono::duration<double>(end - start).count();
    if (elapsed < 0.0001) return 0;
    return (size / (1024.0 * 1024.0)) / elapsed;
}

double BenchmarkEngine::diskBench() {
    std::string testFile = "/tmp/pctune_test.bin";
    runCmdSilent("dd if=/dev/zero of=" + testFile + " bs=1M count=50 conv=fdatasync 2>/dev/null");
    std::string r = captureCmd("dd if=" + testFile + " of=/dev/null bs=1M count=50 2>&1 | grep -oE '[0-9.]+ [MG]B/s' | head -1");
    runCmdSilent("rm " + testFile);
    if (r.empty()) return 0;
    try {
        double val = std::stod(r);
        if (r.find("GB/s") != std::string::npos) val *= 1024;
        return val;
    } catch(...) { return 0; }
}

double BenchmarkEngine::netBench() {
    std::string r = captureCmd("curl -s https://www.google.com --max-time 5 | wc -c");
    return r.empty() ? 0 : 1;
}

void BenchmarkEngine::runBefore() {
    std::cout << col("\n[BENCHMARK] Running pre-optimization benchmarks...", C_MAGENTA) << std::endl;
    cpuBefore = cpuBench(); std::cout << "  CPU Score: " << (int)cpuBefore << std::endl;
    memBefore = memBench(); std::cout << "  RAM Speed: " << (int)memBefore << " MB/s" << std::endl;
    diskBefore = diskBench(); std::cout << "  Disk Speed: " << (int)diskBefore << " MB/s" << std::endl;
}

void BenchmarkEngine::runAfter() {
    std::cout << col("\n[BENCHMARK] Running post-optimization benchmarks...", C_MAGENTA) << std::endl;
    cpuAfter = cpuBench(); std::cout << "  CPU Score: " << (int)cpuAfter << std::endl;
    memAfter = memBench(); std::cout << "  RAM Speed: " << (int)memAfter << " MB/s" << std::endl;
    diskAfter = diskBench(); std::cout << "  Disk Speed: " << (int)diskAfter << " MB/s" << std::endl;
}

void BenchmarkEngine::printComparison() {
    auto printRow = [](const std::string& name, double b, double a) {
        double diff = a - b;
        double pct = b > 0 ? (diff / b) * 100.0 : 0;
        std::cout << "  " << name << ": " << (int)b << " -> " << (int)a 
                  << " (" << (diff >= 0 ? "+" : "") << (int)diff << " / " 
                  << (diff >= 0 ? col(std::to_string(pct).substr(0,4)+"%", C_GREEN) : col(std::to_string(pct).substr(0,4)+"%", C_RED)) << ")" << std::endl;
    };

    std::cout << "\n=== " << col("BENCHMARK COMPARISON", C_BOLD) << " ===" << std::endl;
    printRow("CPU Score", cpuBefore, cpuAfter);
    printRow("RAM Speed", memBefore, memAfter);
    printRow("Disk Speed", diskBefore, diskAfter);
}

void BenchmarkEngine::learn(ai::IntelligenceCore& brain) {
    brain.learnFromBenchmark(cpuBefore, cpuAfter, "CPU");
    brain.learnFromBenchmark(memBefore, memAfter, "RAM");
    brain.learnFromBenchmark(diskBefore, diskAfter, "DISK");
}

} // namespace pctune_up::diagnostic
