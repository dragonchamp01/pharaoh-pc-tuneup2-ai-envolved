#include "pctune_up/ai/web_search_ai.hpp"
#include "pctune_up/core/colors.hpp"
#include "pctune_up/core/utils.hpp"
#include <iostream>
#include <sstream>
#include <regex>
#include <algorithm>

using namespace pctune_up::core;

namespace pctune_up::ai {

WebSearchAI::WebSearchAI() {}

std::string WebSearchAI::fetchPage(const std::string& url) {
    std::string cmd = "curl -s -L --max-time 15 -A 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36' \"" + url + "\" 2>/dev/null";
    return captureCmd(cmd);
}

std::vector<SearchResult> WebSearchAI::parseResults(const std::string& html, const std::string& query) {
    std::vector<SearchResult> results;
    std::regex linkRegex("<a[^>]*href=\"([^\"]*)\"[^>]*>([^<]*)</a>");
    std::regex titleRegex("<h3[^>]*>([^<]*)</h3>");
    std::regex snippetRegex("<div[^>]*class=\"[^\"]*VwiC3b[^\"]*\"[^>]*>([^<]*)</div>");
    
    auto words_begin = std::sregex_iterator(html.begin(), html.end(), linkRegex);
    auto words_end = std::sregex_iterator();
    
    for (auto it = words_begin; it != words_end && results.size() < 10; ++it) {
        std::smatch match = *it;
        std::string url = match[1].str();
        std::string title = match[2].str();
        
        if (url.find("http") == 0 && url.find("google") == std::string::npos) {
            SearchResult r;
            r.url = url;
            r.title = title.empty() ? "Untitled" : title;
            r.relevance = 0.5;
            results.push_back(r);
        }
    }
    return results;
}

std::vector<SearchResult> WebSearchAI::search(const std::string& query, int maxResults) {
    if (cache.count(query)) return cache[query];
    
    std::string encoded = query;
    std::replace(encoded.begin(), encoded.end(), ' ', '+');
    std::string url = "https://www.google.com/search?q=" + encoded + "&num=" + std::to_string(maxResults);
    
    std::string html = fetchPage(url);
    std::vector<SearchResult> results = parseResults(html, query);
    
    cache[query] = results;
    return results;
}

std::vector<SearchResult> WebSearchAI::searchQuantumPCSpecs() {
    std::vector<std::string> queries = {
        "quantum computer specifications 2024",
        "quantum computing hardware requirements",
        "quantum PC build guide",
        "quantum ready motherboard specifications",
        "quantum computing interrupt architecture"
    };
    
    std::vector<SearchResult> allResults;
    for (auto& q : queries) {
        auto results = search(q, 5);
        allResults.insert(allResults.end(), results.begin(), results.end());
    }
    return allResults;
}

std::vector<SearchResult> WebSearchAI::searchBIOSOptimization(const std::string& motherboard) {
    std::string query = motherboard + " BIOS optimization quantum performance settings";
    return search(query, 8);
}

std::vector<SearchResult> WebSearchAI::searchCPUInstructions(const std::string& cpuModel) {
    std::string query = cpuModel + " instruction set extensions AVX AVX-512 AMX quantum";
    return search(query, 8);
}

std::vector<SearchResult> WebSearchAI::searchQuantumInterrupts() {
    return search("quantum computing interrupt handling architecture", 8);
}

std::vector<SearchResult> WebSearchAI::searchManual(const std::string& product) {
    std::string query = product + " manual quantum optimization BIOS settings";
    return search(query, 8);
}

std::string WebSearchAI::extractKeyInfo(const std::vector<SearchResult>& results) {
    std::ostringstream ss;
    ss << "WEB RESEARCH FINDINGS:\n";
    for (auto& r : results) {
        ss << "  - " << r.title << " (" << r.url << ")\n";
    }
    return ss.str();
}

} // namespace pctune_up::ai