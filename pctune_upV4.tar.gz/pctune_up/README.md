# pcTune_Up v5.0 — AI Super PC TuneUp (Modular Edition)

**pcTune_Up** is an advanced Linux system optimizer and hardware research agent that combines kernel tuning, AI-driven diagnostics, and a unique "occult" theme.

## 🚀 What's New in v5.0
- **Modular Architecture**: Completely refactored from a 3200-line monolith into 22+ maintainable C++ modules.
- **Optimization Profiles**: New `--gaming`, `--server-web`, and `--server-db` presets for specialized workloads.
- **AI Visualization**: Generates interactive Knowledge Graphs using Mermaid.js in HTML reports.
- **Boss Battles**: Interactive process management system to "exorcise" resource-heavy background tasks.
- **Machine Personality**: The AI now develops a unique persona based on your specific hardware signature.

## 🛠 Features
- **CPU/RAM/Disk Tuning**: Performance governors, zram, drop caches, fstrim, and sysctl optimizations.
- **HardwareResearchAI**: Deep hardware probing via MSR, CPUID, and ACPI.
- **IntelligenceCore v3**: Adaptive threshold anomaly detection and trend prediction.
- **Doctor PC-Cleanup**: Automated health analysis and prescriptions.
- **Interactive NLU Console**: Speak with the "machine soul" using natural language.
- **System Admin Toolkit**: Security hardening, package updates, and boot optimization.

## 📦 Quick Start
```bash
# Clone and build
git clone <repo_url>
cd pctune_up
make

# Run gaming mode (requires root)
sudo ./pctune_up --gaming --doctor

# Interactive AI session
sudo ./pctune_up --interactive
```

## 📚 Documentation
For a full list of flags, commands, and architecture details, see [manual.md](manual.md).

## ⚖️ Safety Notes
- All optimizations are standard reversible Linux kernel/OS tweaks.
- No physical hardware is damaged (the occult research is flavor/entertainment).
- You can use your PC normally while it runs.

## 📜 License
MIT
