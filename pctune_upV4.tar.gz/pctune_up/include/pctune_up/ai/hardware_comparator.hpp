#pragma once
#include <string>
#include <vector>
#include "pctune_up/ai/hardware_research.hpp"

namespace pctune_up::ai {

class HardwareComparator {
private:
    struct HardwareRef { std::string type, name; double referenceValue; };
    std::vector<HardwareRef> refDB;

public:
    HardwareComparator();
    std::string compareCPU(const std::string& model, double score);
    std::string compareMemory(double memBW);
    std::string compareDisk(double diskBW, bool isSSD);
    std::string fullReport(const HardwareResearchAI& hw, double cpuScore, double memBW, double diskBW);
};

} // namespace pctune_up::ai
