#include "pctune_up/optimizers/system.hpp"
#include "pctune_up/core/config.hpp"
#include "pctune_up/core/colors.hpp"
#include "pctune_up/core/utils.hpp"
#include <iostream>

using namespace pctune_up::core;

namespace pctune_up::optimizers {

void advisoryBIOS() {
    std::cout << "\n=== " << col("BIOS Advisory", C_BLUE) << " ===" << std::endl;

    std::string biosVendor = captureCmd("dmidecode -t bios 2>/dev/null | grep -i 'Vendor:' | head -1 | cut -d: -f2");
    std::string biosVersion = captureCmd("dmidecode -t bios 2>/dev/null | grep -i 'Version:' | head -1 | cut -d: -f2");
    std::string biosDate = captureCmd("dmidecode -t bios 2>/dev/null | grep -i 'Release Date:' | head -1 | cut -d: -f2");
    std::string boardVendor = captureCmd("dmidecode -t baseboard 2>/dev/null | grep -i 'Manufacturer:' | head -1 | cut -d: -f2");
    std::string boardName = captureCmd("dmidecode -t baseboard 2>/dev/null | grep -i 'Product Name:' | head -1 | cut -d: -f2");

    std::cout << col("  BIOS Vendor:", C_YELLOW) << (biosVendor.empty() ? " N/A" : biosVendor) << std::endl;
    std::cout << col("  BIOS Version:", C_YELLOW) << (biosVersion.empty() ? " N/A" : biosVersion) << std::endl;
    std::cout << col("  BIOS Date:", C_YELLOW) << (biosDate.empty() ? " N/A" : biosDate) << std::endl;
    std::cout << col("  Motherboard:", C_YELLOW) << (boardVendor.empty() ? " N/A" : boardVendor)
              << (boardName.empty() ? "" : " " + boardName) << std::endl;

    // fwupd check
    std::string fwupd = captureCmd("which fwupdmgr 2>/dev/null");
    if (!fwupd.empty()) {
        runCmd("fwupdmgr refresh 2>/dev/null", "Refreshing firmware metadata");
        runCmd("fwupdmgr get-updates 2>/dev/null",
               "Checking for firmware updates");
    } else {
        std::cout << col("  [!] Install fwupdmgr for firmware update checks: ", C_YELLOW)
                  << "sudo apt install fwupd" << std::endl;
    }

    // Advisory checklist
    std::cout << "\n" << col("  BIOS Optimization Checklist:", C_BOLD) << std::endl;
    std::cout << "    1. Enable XMP/DOCP for rated RAM speed" << std::endl;
    std::cout << "    2. Enable Above 4G Decoding / Resizable BAR" << std::endl;
    std::cout << "    3. Disable CSM / Enable UEFI boot" << std::endl;
    std::cout << "    4. Set power profile to Performance" << std::endl;
    std::cout << "    5. Disable unused peripherals (serial/parallel ports)" << std::endl;
    std::cout << "    6. Enable VT-d / SVM (if needed for VMs)" << std::endl;
    std::cout << "    7. Check for BIOS updates at motherboard vendor website" << std::endl;
}

void optimizeSystem() {
    std::cout << "\n=== " << col("System Optimization", C_BLUE) << " ===" << std::endl;

    runCmd("sysctl vm.max_map_count=262144 >/dev/null 2>&1",
           "Setting max map count");
    runCmd("sysctl fs.file-max=2097152 >/dev/null 2>&1",
           "Setting max file handles");
    runCmd("sysctl kernel.shmmax=1073741824 >/dev/null 2>&1",
           "Setting max shared memory segment (1GB)");
    runCmd("sysctl kernel.shmall=268435456 >/dev/null 2>&1",
           "Setting total shared memory pages");
    runCmd("sysctl net.core.netdev_max_backlog=5000 >/dev/null 2>&1",
           "Increasing network backlog");
    runCmd("sysctl net.core.somaxconn=4096 >/dev/null 2>&1",
           "Increasing socket listen backlog");
    runCmd("sysctl vm.swappiness=10 >/dev/null 2>&1",
           "Setting swappiness");
}

} // namespace pctune_up::optimizers
