#include "pctune_up/optimizers/gpu.hpp"
#include "pctune_up/core/config.hpp"
#include "pctune_up/core/colors.hpp"
#include "pctune_up/core/utils.hpp"
#include <iostream>

using namespace pctune_up::core;

namespace pctune_up::optimizers {

void probeGPU() {
    std::cout << "\n=== " << col("GPU Demonology", C_BLUE) << " ===" << std::endl;

    std::string lspciGpu = captureCmd("lspci 2>/dev/null | grep -iE 'VGA|3D|Display'");
    std::cout << col("  Detected:", C_YELLOW) << "\n" << lspciGpu;

    // NVIDIA
    std::string nvidia = captureCmd("nvidia-smi --query-gpu=name,temp.gpu,utilization.gpu,memory.total --format=csv,noheader 2>/dev/null");
    if (!nvidia.empty()) {
        std::cout << col("  NVIDIA:", C_YELLOW) << "\n" << nvidia;
        return;
    }
    // AMD
    std::string amd = captureCmd("cat /sys/class/drm/card0/device/vendor 2>/dev/null");
    if (amd.find("1002") != std::string::npos) {
        std::string amdName = captureCmd("cat /sys/class/drm/card0/device/product_name 2>/dev/null");
        std::string amdPerf = captureCmd("cat /sys/class/drm/card0/device/power_dpm_force_performance_level 2>/dev/null");
        std::cout << col("  AMD GPU:", C_YELLOW) << " " << (amdName.empty() ? "AMD Radeon" : amdName)
                  << "\n  Power level: " << (amdPerf.empty() ? "default" : amdPerf) << std::endl;
    }
    // Intel
    std::string intelGpu = captureCmd("cat /sys/class/drm/card0/gt_cur_freq_mhz 2>/dev/null");
    if (!intelGpu.empty()) {
        std::string intelMax = captureCmd("cat /sys/class/drm/card0/gt_max_freq_mhz 2>/dev/null");
        std::string intelMin = captureCmd("cat /sys/class/drm/card0/gt_min_freq_mhz 2>/dev/null");
        std::cout << col("  Intel GPU:", C_YELLOW) << " cur=" << intelGpu.substr(0,4)
                  << "MHz max=" << intelMax.substr(0,4) << "MHz min=" << intelMin.substr(0,4) << "MHz" << std::endl;
    }

    // Fallback: DRI info
    std::string drm = captureCmd("for f in /sys/class/drm/card*/device/vendor 2>/dev/null; do echo \"$f: $(cat $f 2>/dev/null)\"; done");
    if (!drm.empty()) std::cout << col("  DRM:", C_YELLOW) << std::endl << drm;
}

void optimizeGPU() {
    std::cout << "\n=== " << col("GPU Optimization", C_BLUE) << " ===" << std::endl;

    // NVIDIA
    runCmd("nvidia-smi -pm 1 2>/dev/null", "[NVIDIA] Persistent mode enabled");
    runCmd("nvidia-smi -ac 2100,1530 2>/dev/null || nvidia-smi -ac 715,1500 2>/dev/null",
           "[NVIDIA] Setting max clocks (may fail on some GPUs)");
    runCmd("nvidia-smi -pl 80 2>/dev/null || nvidia-smi -pl 95 2>/dev/null",
           "[NVIDIA] Setting power limit");

    // AMD
    runCmd("echo high > /sys/class/drm/card0/device/power_dpm_force_performance_level 2>/dev/null",
           "[AMD] Force high performance level");
    runCmd("echo manual > /sys/class/drm/card0/device/power_dpm_force_performance_level 2>/dev/null",
           "[AMD] Manual power control");

    // Intel
    std::string intelMax = captureCmd("cat /sys/class/drm/card0/gt_max_freq_mhz 2>/dev/null");
    if (!intelMax.empty()) {
        runCmd("echo " + intelMax.substr(0, intelMax.find('\n')) + " > /sys/class/drm/card0/gt_min_freq_mhz 2>/dev/null",
               "[Intel] Locking min GPU freq to max");
    }

    // Generic DRM
    runCmd("for f in /sys/class/drm/card*/device/power_dpm_force_performance_level 2>/dev/null; do echo high > $f 2>/dev/null; done",
           "Setting all DRM devices to high performance");

    std::cout << col("  [GPU]", C_GREEN) << " GPU optimization applied" << std::endl;
}

} // namespace pctune_up::optimizers
