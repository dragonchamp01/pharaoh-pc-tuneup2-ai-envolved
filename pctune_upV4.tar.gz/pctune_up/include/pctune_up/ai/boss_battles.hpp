#pragma once
#include <string>
#include <vector>
#include <sqlite3.h>

namespace pctune_up::ai {

struct CapturedSoul {
    std::string name;
    int pid;
    double cpuPct, memPct;
    std::string state;
};

class BossBattleManager {
private:
    std::vector<CapturedSoul> souls;
    void refreshSouls();
    void logSoul(const CapturedSoul& s);

public:
    BossBattleManager();
    void harvestSouls();
    void startInteractiveBattle();
    void exorcise(int pid);
    void bind(int pid);
    void enslave(int pid, int core);
};

} // namespace pctune_up::ai
