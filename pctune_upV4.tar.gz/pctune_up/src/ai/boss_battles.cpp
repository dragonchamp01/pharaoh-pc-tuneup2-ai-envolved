#include "pctune_up/ai/boss_battles.hpp"
#include "pctune_up/core/database.hpp"
#include "pctune_up/core/colors.hpp"
#include "pctune_up/core/utils.hpp"
#include <iostream>
#include <sstream>
#include <algorithm>
#include <iomanip>

using namespace pctune_up::core;

namespace pctune_up::ai {

BossBattleManager::BossBattleManager() {
    if (db) {
        sqlite3_exec(db, "CREATE TABLE IF NOT EXISTS captured_souls (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, pid INTEGER, cpu REAL, mem REAL, action TEXT DEFAULT 'HARVESTED', timestamp DATETIME DEFAULT CURRENT_TIMESTAMP);", nullptr, nullptr, nullptr);
    }
}

void BossBattleManager::refreshSouls() {
    souls.clear();
    std::string raw = captureCmd("ps aux --sort=-%cpu 2>/dev/null | head -10 | tail -n +2");
    std::istringstream ss(raw);
    std::string line;
    while (std::getline(ss, line)) {
        std::istringstream ls(line);
        std::string user, pid, cpu, mem, vsz, rss, tty, stat, start, time, cmd;
        ls >> user >> pid >> cpu >> mem >> vsz >> rss >> tty >> stat >> start >> time;
        std::getline(ls, cmd);
        
        CapturedSoul s;
        s.name = cmd.substr(1, 30);
        try {
            s.pid = std::stoi(pid);
            s.cpuPct = std::stod(cpu);
            s.memPct = std::stod(mem);
        } catch(...) { continue; }
        s.state = "DEMONIC";
        souls.push_back(s);
    }
}

void BossBattleManager::logSoul(const CapturedSoul& s) {
    if (!db) return;
    sqlite3_stmt* stmt;
    const char* sql = "INSERT INTO captured_souls (name, pid, cpu, mem) VALUES (?, ?, ?, ?);";
    if (sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr) == SQLITE_OK) {
        sqlite3_bind_text(stmt, 1, s.name.c_str(), -1, SQLITE_TRANSIENT);
        sqlite3_bind_int(stmt, 2, s.pid);
        sqlite3_bind_double(stmt, 3, s.cpuPct);
        sqlite3_bind_double(stmt, 4, s.memPct);
        sqlite3_step(stmt);
        sqlite3_finalize(stmt);
    }
}

void BossBattleManager::harvestSouls() {
    refreshSouls();
    for (const auto& s : souls) {
        if (s.cpuPct > 5.0 || s.memPct > 5.0) {
            logSoul(s);
        }
    }
}

void BossBattleManager::exorcise(int pid) {
    std::cout << col("[EXORCISM]", C_RED) << " Banishing PID " << pid << " to the void..." << std::endl;
    runCmdSilent("kill -9 " + std::to_string(pid));
}

void BossBattleManager::bind(int pid) {
    std::cout << col("[BINDING]", C_YELLOW) << " Restricting PID " << pid << " with the chains of renice..." << std::endl;
    runCmdSilent("renice +19 -p " + std::to_string(pid));
}

void BossBattleManager::enslave(int pid, int core) {
    std::cout << col("[ENSLAVEMENT]", C_MAGENTA) << " Forcing PID " << pid << " to toil on core " << core << "..." << std::endl;
    runCmdSilent("taskset -cp " + std::to_string(core) + " " + std::to_string(pid));
}

void BossBattleManager::startInteractiveBattle() {
    refreshSouls();
    std::cout << "\n=== " << col("BOSS BATTLE — DEMON PROCESSES DETECTED", C_RED) << " ===" << std::endl;
    std::cout << std::left << std::setw(8) << "PID" << std::setw(10) << "CPU%" << std::setw(10) << "MEM%" << "NAME" << std::endl;
    std::cout << std::string(50, '-') << std::endl;
    
    for (const auto& s : souls) {
        std::string color = (s.cpuPct > 30.0) ? C_RED : C_YELLOW;
        std::cout << std::left << std::setw(8) << s.pid 
                  << std::setw(10) << col(std::to_string(s.cpuPct), color) 
                  << std::setw(10) << s.memPct << s.name << std::endl;
    }
    
    std::cout << "\nChoose your action: " << col("(e)xorcise", C_RED) << ", " << col("(b)ind", C_YELLOW) << ", " << col("(s)lave", C_MAGENTA) << ", " << col("(q)uit", C_CYAN) << std::endl;
    std::cout << "> "; std::cout.flush();
    
    char action; int targetPid;
    if (!(std::cin >> action) || action == 'q') return;
    
    std::cout << "Target PID: ";
    if (!(std::cin >> targetPid)) return;
    
    if (action == 'e') exorcise(targetPid);
    else if (action == 'b') bind(targetPid);
    else if (action == 's') {
        int core; std::cout << "Target Core (0-7): "; std::cin >> core;
        enslave(targetPid, core);
    }
}

} // namespace pctune_up::ai
