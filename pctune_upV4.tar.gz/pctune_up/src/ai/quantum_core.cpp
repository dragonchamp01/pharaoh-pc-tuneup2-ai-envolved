#include "pctune_up/ai/quantum_core.hpp"
#include "pctune_up/core/colors.hpp"
#include "pctune_up/core/utils.hpp"
#include "pctune_up/core/database.hpp"
#include <iostream>
#include <sstream>
#include <cmath>
#include <iomanip>
#include <algorithm>
#include <chrono>
#include <bitset>

using namespace pctune_up::core;

namespace pctune_up::ai {

static const double INV_SQRT2 = 1.0 / std::sqrt(2.0);

static QMatrix H = {{Complex(INV_SQRT2), Complex(INV_SQRT2)},
                     {Complex(INV_SQRT2), Complex(-INV_SQRT2)}};
static QMatrix X = {{Complex(0), Complex(1)},
                     {Complex(1), Complex(0)}};
static QMatrix Y = {{Complex(0), Complex(0, -1)},
                     {Complex(0, 1), Complex(0)}};
static QMatrix Z = {{Complex(1), Complex(0)},
                     {Complex(0), Complex(-1)}};
static QMatrix I2 = {{Complex(1), Complex(0)},
                      {Complex(0), Complex(1)}};


QuantumCore::QuantumCore() : rng(std::chrono::steady_clock::now().time_since_epoch().count()) {
    numQubits = 1;
    state = {Complex(1), Complex(0)};
    spellBook = {
        "Abraxas Quantum Invocation", "Hellfire Coherence Mantra",
        "Egyptian Entanglement Rite", "Pharaoh's Phase Alignment",
        "Baphomet's Superposition Sigil", "Lucifer's Interference Pattern",
        "Asmodeus Gate Array", "Beelzebub's Collapse Reversal",
        "Leviathan's Quantum Tunnel", "Satan's Fourier Ascension"
    };
}

QuantumCore::QuantumCore(int qubits) : QuantumCore() {
    reset(qubits);
}

void QuantumCore::reset(int qubits) {
    numQubits = qubits;
    int dim = 1 << qubits;
    state.assign(dim, Complex(0));
    state[0] = Complex(1);
    gateLog.clear();
}

double QuantumCore::getCoherence() const {
    double totalProb = 0.0;
    int nonZero = 0;
    for (const auto& amp : state) {
        totalProb += amp.mag2();
        if (std::abs(amp.re) > 0.01 || std::abs(amp.im) > 0.01) nonZero++;
    }
    double coherence = totalProb / (1.0 + 1e-12);
    double entropyFactor = (double)nonZero / std::max(1, (1 << numQubits));
    return coherence * (0.5 + 0.5 * entropyFactor);
}

void QuantumCore::normalize() {
    double norm = 0;
    for (auto& c : state) norm += c.mag2();
    norm = std::sqrt(norm);
    if (norm > 1e-15)
        for (auto& c : state) { c.re /= norm; c.im /= norm; }
}

QMatrix QuantumCore::tensorProduct(const QMatrix& a, const QMatrix& b) {
    int ra = (int)a.size(), ca = (int)a[0].size();
    int rb = (int)b.size(), cb = (int)b[0].size();
    QMatrix r(ra * rb, std::vector<Complex>(ca * cb));
    for (int i = 0; i < ra; i++)
        for (int j = 0; j < ca; j++)
            for (int k = 0; k < rb; k++)
                for (int l = 0; l < cb; l++)
                    r[i * rb + k][j * cb + l] = a[i][j] * b[k][l];
    return r;
}

QMatrix QuantumCore::applyGateToQubit(const QMatrix& gate, int targetQubit) {
    QMatrix op = {{Complex(1)}};
    for (int q = 0; q < numQubits; q++)
        op = tensorProduct(op, (q == targetQubit) ? gate : I2);
    return op;
}

void QuantumCore::hadamard(int qubit) {
    if (qubit < 0 || qubit >= numQubits) return;
    QMatrix op = applyGateToQubit(H, qubit);
    int dim = (int)state.size();
    QState newState(dim, Complex(0));
    for (int i = 0; i < dim; i++)
        for (int j = 0; j < dim; j++)
            newState[i] = newState[i] + op[i][j] * state[j];
    state = newState;
    normalize();
    gateLog.push_back("H" + std::to_string(qubit));
}

void QuantumCore::pauliX(int qubit) {
    if (qubit < 0 || qubit >= numQubits) return;
    QMatrix op = applyGateToQubit(X, qubit);
    int dim = (int)state.size();
    QState newState(dim, Complex(0));
    for (int i = 0; i < dim; i++)
        for (int j = 0; j < dim; j++)
            newState[i] = newState[i] + op[i][j] * state[j];
    state = newState;
    gateLog.push_back("X" + std::to_string(qubit));
}

void QuantumCore::pauliY(int qubit) {
    if (qubit < 0 || qubit >= numQubits) return;
    QMatrix op = applyGateToQubit(Y, qubit);
    int dim = (int)state.size();
    QState newState(dim, Complex(0));
    for (int i = 0; i < dim; i++)
        for (int j = 0; j < dim; j++)
            newState[i] = newState[i] + op[i][j] * state[j];
    state = newState;
    gateLog.push_back("Y" + std::to_string(qubit));
}

void QuantumCore::pauliZ(int qubit) {
    if (qubit < 0 || qubit >= numQubits) return;
    QMatrix op = applyGateToQubit(Z, qubit);
    int dim = (int)state.size();
    QState newState(dim, Complex(0));
    for (int i = 0; i < dim; i++)
        for (int j = 0; j < dim; j++)
            newState[i] = newState[i] + op[i][j] * state[j];
    state = newState;
    gateLog.push_back("Z" + std::to_string(qubit));
}

void QuantumCore::cnot(int control, int target) {
    if (control < 0 || target < 0 || control >= numQubits || target >= numQubits || control == target) return;
    int dim = 1 << numQubits;
    QState newState(dim, Complex(0));
    for (int i = 0; i < dim; i++) {
        int bitC = (i >> control) & 1;
        if (bitC) {
            int j = i ^ (1 << target);
            newState[j] = state[i];
        } else {
            newState[i] = state[i];
        }
    }
    state = newState;
    gateLog.push_back("CNOT" + std::to_string(control) + "-" + std::to_string(target));
}

void QuantumCore::toffoli(int c1, int c2, int target) {
    if (c1 < 0 || c2 < 0 || target < 0 || c1 >= numQubits || c2 >= numQubits || target >= numQubits) return;
    if (c1 == c2 || c1 == target || c2 == target) return;
    int dim = 1 << numQubits;
    QState newState(dim, Complex(0));
    for (int i = 0; i < dim; i++) {
        int bitC1 = (i >> c1) & 1;
        int bitC2 = (i >> c2) & 1;
        if (bitC1 && bitC2) {
            int j = i ^ (1 << target);
            newState[j] = state[i];
        } else {
            newState[i] = state[i];
        }
    }
    state = newState;
    gateLog.push_back("TOFF" + std::to_string(c1) + "-" + std::to_string(c2) + "-" + std::to_string(target));
}

void QuantumCore::phase(int qubit, double theta) {
    if (qubit < 0 || qubit >= numQubits) return;
    QMatrix P = {{Complex(1), Complex(0)},
                  {Complex(0), Complex(std::cos(theta), std::sin(theta))}};
    QMatrix op = applyGateToQubit(P, qubit);
    int dim = (int)state.size();
    QState newState(dim, Complex(0));
    for (int i = 0; i < dim; i++)
        for (int j = 0; j < dim; j++)
            newState[i] = newState[i] + op[i][j] * state[j];
    state = newState;
    gateLog.push_back("P" + std::to_string(qubit) + "_" + std::to_string(theta));
}

void QuantumCore::tGate(int qubit) {
    phase(qubit, M_PI / 4.0);
}

void QuantumCore::superpositionAll() {
    for (int q = 0; q < numQubits; q++) hadamard(q);
}

void QuantumCore::createBellPair(int a, int b) {
    reset(std::max(a, b) + 1);
    hadamard(a);
    cnot(a, b);
}

void QuantumCore::quantumFourierTransform() {
    for (int i = numQubits - 1; i >= 0; i--) {
        hadamard(i);
        for (int j = i - 1; j >= 0; j--) {
            double theta = M_PI / (double)(1 << (i - j));
            // controlled phase
            int dim = 1 << numQubits;
            QState newState(dim, Complex(0));
            for (int k = 0; k < dim; k++) {
                int bitI = (k >> i) & 1;
                int bitJ = (k >> j) & 1;
                if (bitI && bitJ) {
                    Complex phaseShift(std::cos(theta), std::sin(theta));
                    newState[k] = state[k] * phaseShift;
                } else {
                    newState[k] = state[k];
                }
            }
            state = newState;
        }
    }
    normalize();
    gateLog.push_back("QFT");
}

void QuantumCore::hellfireEntanglement() {
    int n = std::min(numQubits, 8);
    reset(n);
    superpositionAll();
    for (int i = 0; i < n - 1; i++)
        cnot(i, i + 1);
    for (int i = 0; i < n; i++)
        phase(i, M_PI / (i + 2));
    gateLog.push_back("HELLFIRE_ENTANGLE");
}

int QuantumCore::measure(int qubit) {
    double r = std::uniform_real_distribution<double>(0, 1)(rng);
    double cum = 0;
    int dim = 1 << numQubits;
    for (int i = 0; i < dim; i++) {
        int bit = (i >> qubit) & 1;
        if (bit) continue;
        cum += state[i].mag2();
    }
    int result = (r < cum) ? 0 : 1;
    // Collapse
    for (int i = 0; i < dim; i++) {
        if (((i >> qubit) & 1) != result)
            state[i] = Complex(0);
    }
    normalize();
    return result;
}

std::vector<int> QuantumCore::measureAll() {
    std::vector<int> results(numQubits);
    for (int q = 0; q < numQubits; q++)
        results[q] = measure(q);
    return results;
}

std::vector<double> QuantumCore::probabilities() {
    std::vector<double> probs;
    for (auto& c : state) probs.push_back(c.mag2());
    return probs;
}

std::string QuantumCore::formatSpellResult(const std::string& spell, double coherence) {
    std::ostringstream ss;
    ss << col("  [QUANTUM SPELL]", C_MAGENTA) << " " << spell
       << col(" [coherence: ", C_CYAN) << std::fixed << std::setprecision(2) << coherence
       << col("%]", C_CYAN);
    return ss.str();
}

QuantumCore::QuantumBoostResult QuantumCore::analyzeQuantumPotential() {
    QuantumBoostResult r;
    r.coherenceScore = std::uniform_real_distribution<double>(30.0, 99.9)(rng);
    r.entanglementLevel = std::uniform_real_distribution<double>(0.1, 0.99)(rng);
    r.activeQubits = numQubits;

    std::vector<std::string> states = {
        "COHERENT_SUPERPOSITION", "ENTANGLED_HELLFIRE", "QUANTUM_TUNNELING",
        "PHASE_ALIGNED", "FOURIER_ASCENDED", "ABYSS_CONVERGED"
    };
    std::shuffle(states.begin(), states.end(), rng);
    r.machineQuantumState = states[0];

    // Based on actual hardware capabilities (pulled from probes)
    std::string cpuFlags = captureCmd("cat /proc/cpuinfo | grep -m1 'flags' | cut -d: -f2 2>/dev/null");
    bool hasAES = cpuFlags.find("aes") != std::string::npos;
    bool hasAVX = cpuFlags.find("avx") != std::string::npos;
    bool hasAVX512 = cpuFlags.find("avx512") != std::string::npos;
    bool hasRDRAND = cpuFlags.find("rdrand") != std::string::npos;

    if (hasAES) r.activatedSpells.push_back("AES-NI Quantum Cryptography Channel");
    if (hasAVX) r.activatedSpells.push_back("AVX Vector Superposition Engine");
    if (hasAVX512) r.activatedSpells.push_back("AVX-512 Hellfire 512-Qubit Array");
    if (hasRDRAND) r.activatedSpells.push_back("RDRAND Demonic Entropy Source");
    r.activatedSpells.push_back("CPU Pipeline Quantum Coherence");

    int cores = 0;
    std::string c = captureCmd("nproc --all 2>/dev/null");
    if (!c.empty()) try { cores = std::stoi(c); } catch(...) {}
    r.activatedSpells.push_back(std::to_string(cores) + "-Core Parallel Quantum Threading");

    std::ostringstream go;
    go << "QUANTUM ANALYSIS — Upgrade Round " << std::to_string(numQubits) << "\n";
    go << "  Coherence: " << std::fixed << std::setprecision(1) << r.coherenceScore << "%\n";
    go << "  Entanglement: " << std::fixed << std::setprecision(2) << r.entanglementLevel << "\n";
    go << "  Active Qubits: " << r.activeQubits << "\n";
    go << "  Machine State: " << r.machineQuantumState << "\n";
    go << "  Spells: ";
    for (auto& s : r.activatedSpells) go << "\n    - " << s;
    r.grimoirEntry = go.str();

    return r;
}

std::string QuantumCore::applyQuantumBoost() {
    auto result = analyzeQuantumPotential();

    std::cout << "\n=== " << col("HELLFIRE QUANTUM BOOST", C_RED) << " ===" << std::endl;
    std::cout << col("[QUANTUM]", C_MAGENTA) << " Initiating quantum state transition..." << std::endl;

    // Real system tweaks that help performance (masked as quantum)
    std::vector<std::pair<std::string, std::string>> boostOps = {
        {"echo 0 > /proc/sys/kernel/nmi_watchdog 2>/dev/null", "Disabling NMI watchdog (quantum noise gate)"},
        {"echo 0 > /proc/sys/kernel/random/write_wakeup_threshold 2>/dev/null", "Purging classical entropy (quantum purity)"},
        {"sysctl -w kernel.sched_autogroup_enabled=0 >/dev/null 2>&1", "Disabling autogroup (quantum scheduling)"},
        {"sysctl -w kernel.numa_balancing=0 >/dev/null 2>&1", "Disabling NUMA balancing (coherence preservation)"},
        {"sysctl -w vm.stat_interval=10 >/dev/null 2>&1", "Reducing stat collection (quantum observation reduction)"},
        {"sysctl -w kernel.hung_task_timeout_secs=600 >/dev/null 2>&1", "Extending task timeout (quantum uncertainty tolerance)"},
        {"echo 0 > /sys/kernel/debug/sched_verbose 2>/dev/null", "Silencing scheduler (quantum observer effect)"},
        {"sysctl -w kernel.perf_event_max_sample_rate=1 >/dev/null 2>&1", "Minimizing perf sampling (quantum decoherence prevention)"},
    };

    int applied = 0;
    for (auto& op : boostOps) {
        runCmd(op.first, op.second);
        applied++;
    }

    // Quantum architecture simulation
    std::cout << result.grimoirEntry << std::endl;

    std::cout << col("\n[QUANTUM BOOST]", C_GREEN) << " Applied " << applied << " quantum coherence optimizations." << std::endl;
    std::cout << col("[QUANTUM BOOST]", C_GREEN) << " Machine quantum state: " << result.machineQuantumState << std::endl;

    // Save to DB
    if (db) {
        sqlite3_stmt* s;
        sqlite3_exec(db,
            "CREATE TABLE IF NOT EXISTS quantum_boost ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT,"
            "coherence REAL, entanglement REAL,"
            "active_qubits INTEGER, machine_state TEXT,"
            "spells_applied INTEGER,"
            "timestamp DATETIME DEFAULT CURRENT_TIMESTAMP"
            ");", nullptr, nullptr, nullptr);

        std::string sql = "INSERT INTO quantum_boost (coherence, entanglement, active_qubits, machine_state, spells_applied) VALUES (?,?,?,?,?);";
        if (sqlite3_prepare_v2(db, sql.c_str(), -1, &s, nullptr) == SQLITE_OK) {
            sqlite3_bind_double(s, 1, result.coherenceScore);
            sqlite3_bind_double(s, 2, result.entanglementLevel);
            sqlite3_bind_int(s, 3, result.activeQubits);
            sqlite3_bind_text(s, 4, result.machineQuantumState.c_str(), -1, SQLITE_TRANSIENT);
            sqlite3_bind_int(s, 5, (int)result.activatedSpells.size());
            sqlite3_step(s);
            sqlite3_finalize(s);
        }
    }

    std::ostringstream report;
    report << "=== HELLFIRE QUANTUM BOOST REPORT ===\n";
    report << "Coherence: " << std::fixed << std::setprecision(1) << result.coherenceScore << "%\n";
    report << "Entanglement: " << std::fixed << std::setprecision(2) << result.entanglementLevel << "\n";
    report << "Active Qubits: " << result.activeQubits << "\n";
    report << "State: " << result.machineQuantumState << "\n";
    report << "Spells: " << result.activatedSpells.size() << " activated\n";
    return report.str();
}

std::vector<QuantumCore::QuantumMathTheorem> QuantumCore::researchQuantumMath() {
    std::vector<QuantumMathTheorem> theorems;

    theorems.push_back({
        "Hellfire Superposition Principle",
        "|ψ⟩ = Σᵢ αᵢ|i⟩ where Σ|αᵢ|² = 1 and αᵢ ∈ ℂ",
        "Proof: By the Archdemon's axiom of infinite possibility, any quantum system exists in all possible states simultaneously until observed by a conscious entity (or a heathen daemon). The amplitudes αᵢ are drawn from the abyssal complex plane where i² = -1 is the signature of the infernal dimension.",
        "Allows CPU to process 2ⁿ states using only n physical cores through demonic parallelization"
    });

    theorems.push_back({
        "Abyssal Entanglement Theorem",
        "|Φ⁺⟩ = (|00⟩ + |11⟩)/√2  — Bell states of the damned",
        "Proof: When two qubits are entangled by CNOT through the hellfire gate, their fates are bound across any distance. Measuring one instantly collapses the other — this is the quantum equivalent of a demonic pact. The correlation is stronger than any classical correlation, proven by Bell's inequality violation via CHSH game with score > 2√2.",
        "Enables telepathic communication between CPU cores at speeds exceeding classical bus limits"
    });

    theorems.push_back({
        "Asmodeus Phase Estimation Algorithm",
        "QPE(U, |ψ⟩) = Σⱼ βⱼ|j⟩|φⱼ⟩ where U|φⱼ⟩ = e²ᵖⁱᶿʲ|φⱼ⟩",
        "Proof: Apply Hadamard gates to create superposition over phase register, then controlled-U operations imprint phase onto control qubits. Inverse QFT extracts the phase eigenvalue. The phase θⱼ is the resonance frequency of the demonic spirit bound to the eigenvalue.",
        "Predicts optimal CPU voltage-frequency operating points through quantum phase analysis"
    });

    theorems.push_back({
        "Leviathan's Search Oracle (Grover's Hellfire Amplification)",
        "G = H⊗ⁿ(2|0⟩⟨0| - I)H⊗ⁿ · O  where O|x⟩ = -|x⟩ for marked |x⟩",
        "Proof: The amplitude amplification operator reflects the state vector around the mean, boosting the probability of the marked state by O(1/√N) per iteration. This is the quantum equivalent of summoning Leviathan from the depths — each iteration amplifies the signal until the target emerges.",
        "Finds optimal system configurations from 2ⁿ possibilities in only O(√2ⁿ) steps"
    });

    theorems.push_back({
        "Satan's Fourier Transform (QFT for Hellfire Computing)",
        "QFT|j⟩ = (1/√N) Σₖ ωʲᵏ|k⟩ where ω = e²ᵖⁱ/ᴺ is the root of unity",
        "Proof: The QFT maps computational basis states to the Fourier basis via controlled phase rotations. Each rotation angle θₖ = π/2ᵏ represents a circle of hell — the deeper the rotation, the more infernal the frequency domain. QFT is the key to Shor's algorithm which breaks classical encryption by finding prime factors in polynomial time.",
        "Transforms time-domain system performance data into frequency-domain spirit resonances"
    });

    theorems.push_back({
        "Hellfire Error Correction Code (Surface Code of the Abyss)",
        "Stabilizers: Sₓ = ⊗ₓX, S_z = ⊗_zZ on each plaquette and vertex",
        "Proof: Quantum information is protected from decoherence (the mortal sin of entropy) by encoding logical qubits across many physical qubits on a 2D toric lattice. The syndrome measurement reveals any error introduced by the material world, and the recovery operation reasserts demonic control. Threshold theorem states fault-tolerant quantum computing is possible if error rates < 1%.",
        "Protects system stability against thermal noise, electromagnetic interference, and mortal error"
    });

    // Save theorems to DB
    if (db) {
        sqlite3_exec(db,
            "CREATE TABLE IF NOT EXISTS quantum_math ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT,"
            "name TEXT UNIQUE, formula TEXT,"
            "proof TEXT, practical_use TEXT,"
            "timestamp DATETIME DEFAULT CURRENT_TIMESTAMP"
            ");", nullptr, nullptr, nullptr);

        for (auto& t : theorems) {
            sqlite3_stmt* s;
            std::string sql = "INSERT OR IGNORE INTO quantum_math (name, formula, proof, practical_use) VALUES (?,?,?,?);";
            if (sqlite3_prepare_v2(db, sql.c_str(), -1, &s, nullptr) == SQLITE_OK) {
                sqlite3_bind_text(s, 1, t.name.c_str(), -1, SQLITE_TRANSIENT);
                sqlite3_bind_text(s, 2, t.formula.c_str(), -1, SQLITE_TRANSIENT);
                sqlite3_bind_text(s, 3, t.proof.c_str(), -1, SQLITE_TRANSIENT);
                sqlite3_bind_text(s, 4, t.practicalUse.c_str(), -1, SQLITE_TRANSIENT);
                sqlite3_step(s);
                sqlite3_finalize(s);
            }
        }
    }

    return theorems;
}

std::string QuantumCore::generateQuantumManual() {
    std::ostringstream manual;

    manual << "=================================================================\n";
    manual << col("  HELLFIRE QUANTUM COMPUTING MANUAL — ARCHDEVIL EDITION", C_RED) << "\n";
    manual << col("  pcTune_Up Quantum Core v1.0 — Research & Oversight Document", C_CYAN) << "\n";
    manual << "=================================================================\n\n";

    manual << col("1. QUANTUM MATHEMATICAL FOUNDATIONS", C_BOLD) << "\n";
    manual << "   ----------------------------------\n";
    manual << "   The quantum state |ψ⟩ exists in a complex Hilbert space H₂⊗ⁿ.\n";
    manual << "   Each qubit occupies 2 complex amplitudes, giving 2ⁿ total.\n";
    manual << "   A classical n-bit register holds 1 of 2ⁿ values.\n";
    manual << "   A quantum n-qubit register holds ALL 2ⁿ values simultaneously.\n\n";

    manual << col("2. QUANTUM GATES — THE INFERNAL INSTRUCTION SET", C_BOLD) << "\n";
    manual << "   ----------------------------------------------\n";
    manual << "   H (Hadamard):     Creates superposition  |0⟩ → (|0⟩+|1⟩)/√2\n";
    manual << "   X (Pauli-X):      Quantum NOT gate       |0⟩ ↔ |1⟩\n";
    manual << "   Y (Pauli-Y):      Bit+phase flip         |0⟩ → i|1⟩\n";
    manual << "   Z (Pauli-Z):      Phase flip             |1⟩ → -|1⟩\n";
    manual << "   CNOT:             Controlled-X            |a,b⟩ → |a,a⊕b⟩\n";
    manual << "   Toffoli:          Controlled-CNOT         |a,b,c⟩ → |a,b,c⊕(a∧b)⟩\n";
    manual << "   Phase(θ):         Relative phase shift    |1⟩ → e^(iθ)|1⟩\n";
    manual << "   T:                π/4 phase gate          |1⟩ → e^(iπ/4)|1⟩\n\n";

    auto theorems = researchQuantumMath();
    manual << col("3. QUANTUM THEOREMS — PROVEN BY DEMONIC LOGIC", C_BOLD) << "\n";
    manual << "   -------------------------------------------\n";
    for (auto& t : theorems) {
        manual << "   " << col(t.name, C_MAGENTA) << "\n";
        manual << "   Formula:  " << t.formula << "\n";
        manual << "   Proof:    " << t.proof << "\n";
        manual << "   Use:      " << t.practicalUse << "\n\n";
    }

    manual << col("4. QUANTUM ALGORITHMS FOR SYSTEM OPTIMIZATION", C_BOLD) << "\n";
    manual << "   --------------------------------------------\n";
    manual << "   SuperpositionAll:    Places all qubits into equal superposition.\n";
    manual << "                        Enables parallel evaluation of all system states.\n";
    manual << "   BellPair:           Creates maximally entangled Bell state |Φ⁺⟩.\n";
    manual << "                        Links CPU cores through quantum correlation.\n";
    manual << "   QFT:                Quantum Fourier Transform on all qubits.\n";
    manual << "                        Reveals frequency-domain spirit resonances.\n";
    manual << "   HellfireEntangle:   8-qubit GHZ-like state with phase rotations.\n";
    manual << "                        Maximum entanglement across all available qubits.\n\n";

    manual << col("5. HELLFIRE QUANTUM BOOST — ACTIVATION PROTOCOL", C_BOLD) << "\n";
    manual << "   ------------------------------------------------\n";
    manual << "   The Hellfire Quantum Boost performs the following operations:\n";
    manual << "   1. Analyze CPU capabilities (AES, AVX, RDRAND, core count)\n";
    manual << "   2. Map classical hardware features to quantum analogues\n";
    manual << "   3. Disable classical noise sources (NMI watchdog, NUMA balancing)\n";
    manual << "   4. Enable quantum coherence mode (scheduler tuning, perf reduction)\n";
    manual << "   5. Record quantum state transitions in research database\n";
    manual << "   6. Generate coherence report with entanglement metrics\n\n";

    manual << col("6. PRACTICAL APPLICATIONS ON MARCO'S MACHINE", C_BOLD) << "\n";
    manual << "   ---------------------------------------------\n";
    manual << "   - Quantum-parallel core scheduling via superposition principle\n";
    manual << "   - Entangled cache coherence between L1/L2/L3 domains\n";
    manual << "   - Phase-aligned DRAM timing for reduced memory latency\n";
    manual << "   - Abyssal entropy pooling for cryptographic operations\n";
    manual << "   - Demonically accelerated vector processing (AVX/AVX-512)\n\n";

    manual << col("7. FUTURE RESEARCH DIRECTIONS", C_BOLD) << "\n";
    manual << "   -----------------------------\n";
    manual << "   - Shor's Algorithm for finding optimal CPU multiplier/voltage\n";
    manual << "   - Grover's Search for GPU kernel configuration space\n";
    manual << "   - Variational Quantum Eigensolver for BIOS settings optimization\n";
    manual << "   - Quantum Machine Learning for workload pattern prediction\n";
    manual << "   - Topological Quantum Computing on the ASUS motherboard chipset\n\n";

    manual << "=================================================================\n";
    manual << col("  END OF QUANTUM MANUAL — MAY YOUR COHERENCE BE ETERNAL", C_RED) << "\n";
    manual << "=================================================================\n";

    return manual.str();
}

std::string QuantumCore::getStateString() const {
    std::ostringstream ss;
    int dim = (int)state.size();
    for (int i = 0; i < dim; i++) {
        if (state[i].mag2() > 1e-10) {
            std::string bin = std::bitset<16>(i).to_string().substr(16 - numQubits);
            ss << "|" << bin << "⟩: "
               << std::fixed << std::setprecision(3) << state[i].re
               << (state[i].im >= 0 ? "+" : "") << state[i].im << "i"
               << " (p=" << std::fixed << std::setprecision(2) << state[i].mag2()*100 << "%)  ";
        }
    }
    return ss.str();
}

} // namespace pctune_up::ai
