#pragma once
#include <thread>
#include "pctune_up/ai/hardware_research.hpp"
#include "pctune_up/ai/intelligence_core.hpp"

#include "pctune_up/ai/boss_battles.hpp"
#include "pctune_up/ai/quantum_core.hpp"
#include "pctune_up/ai/quantum_research.hpp"

namespace pctune_up::ui {

class InteractiveConsole {
private:
    std::thread consoleThread;
    bool consoleRunning = false;
    ai::QuantumResearchAI* qResearch = nullptr;
    ai::QuantumCore* quantum = nullptr;

    std::string analyze(const std::string& query, const ai::HardwareResearchAI& hw, ai::IntelligenceCore& brain, ai::BossBattleManager& bbm);

public:
    void setQuantumRefs(ai::QuantumResearchAI* qr, ai::QuantumCore* qc) { qResearch = qr; quantum = qc; }
    void start(const ai::HardwareResearchAI& hw, ai::IntelligenceCore& brain, ai::BossBattleManager& bbm);
    bool running() const { return consoleRunning; }
    void stop();
};

} // namespace pctune_up::ui
