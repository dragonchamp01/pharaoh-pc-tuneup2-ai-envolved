#include "pctune_up/core/config.hpp"

namespace pctune_up::core {

Config cfg;

} // namespace pctune_up::core
