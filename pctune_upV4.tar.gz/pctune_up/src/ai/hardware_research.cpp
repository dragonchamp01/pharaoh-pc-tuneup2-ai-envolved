#include "pctune_up/ai/hardware_research.hpp"
#include "pctune_up/core/colors.hpp"
#include "pctune_up/core/utils.hpp"
#include "pctune_up/core/database.hpp"
#include <iostream>
#include <sstream>
#include <fstream>
#include <algorithm>
#include <chrono>
#include <iomanip>
#include <map>

using namespace pctune_up::core;

namespace pctune_up::ai {

HardwareResearchAI::HardwareResearchAI() : rng(std::chrono::steady_clock::now().time_since_epoch().count()) { upgradeRound = 0; }

void HardwareResearchAI::probeCPU() {
    cpu.modelName = captureCmd("cat /proc/cpuinfo | grep -m1 'model name' | cut -d: -f2 2>/dev/null");
    if (!cpu.modelName.empty()) cpu.modelName = cpu.modelName.substr(0, cpu.modelName.find('\n'));
    cpu.cores = std::stoi(captureCmd("nproc --all 2>/dev/null"));
    cpu.threads = std::stoi(captureCmd("cat /proc/cpuinfo | grep -c '^processor' 2>/dev/null"));
    std::string f = captureCmd("cat /proc/cpuinfo | grep -m1 'cpu MHz' | cut -d: -f2 2>/dev/null");
    if (!f.empty()) cpu.maxFreqMHz = std::stod(f);
    cpu.vendor = captureCmd("cat /proc/cpuinfo | grep -m1 'vendor_id' | cut -d: -f2 2>/dev/null");
    cpu.arch = captureCmd("uname -m 2>/dev/null");
    cpu.microcode = captureCmd("cat /proc/cpuinfo | grep -m1 'microcode' | cut -d: -f2 2>/dev/null");
    cpu.stepping = captureCmd("cat /proc/cpuinfo | grep -m1 'stepping' | cut -d: -f2 2>/dev/null");
    std::istringstream fs(captureCmd("cat /proc/cpuinfo | grep -m1 'flags' | cut -d: -f2 2>/dev/null"));
    std::string fl; while (fs >> fl) cpu.flags.push_back(fl);
    cpu.cacheInfo = captureCmd("cat /proc/cpuinfo | grep -E 'cache size|cache_alignment' | head -2 2>/dev/null");
    cpu.topology = captureCmd("lscpu 2>/dev/null | grep -E 'Socket|Thread|Core|NUMA|L1|L2|L3|Model name|CPU family|Vulnerability'");
}

void HardwareResearchAI::probeMemory() {
    std::string r = captureCmd("grep -E '^(MemTotal|MemFree|MemAvailable|SwapTotal|SwapFree):' /proc/meminfo | awk '{print $2}'");
    std::istringstream(r) >> mem.totalKB >> mem.freeKB >> mem.availKB >> mem.swapTotalKB >> mem.swapFreeKB;
}

void HardwareResearchAI::probePCI() { std::istringstream ss(captureCmd("lspci 2>/dev/null | head -40")); std::string l; while (getline(ss, l)) if (!l.empty()) pciDevices.push_back(l); }
void HardwareResearchAI::probeStorage() {
    std::istringstream ss(captureCmd("lsblk -d -o NAME,SIZE,ROTA 2>/dev/null | tail -n+2")); std::string n, sz, r;
    while (ss >> n >> sz >> r) { DiskInfo d; d.device=n; d.size=sz; d.isSSD=(r=="0");
        d.smartStatus=captureCmd("smartctl -H /dev/"+n+" 2>/dev/null | grep 'SMART overall-health' | awk '{print $6}'");
        if (d.smartStatus.empty()) d.smartStatus="N/A";
        disks.push_back(d);
    }
}
void HardwareResearchAI::probeDMI() {
    dmiBios=captureCmd("dmidecode -t bios 2>/dev/null | grep -E 'Vendor:|Version:|Release Date:' | head -3");
    dmiBoard=captureCmd("dmidecode -t baseboard 2>/dev/null | grep -E 'Manufacturer:|Product Name:|Version' | head -3");
    dmiSystem=captureCmd("dmidecode -t system 2>/dev/null | grep -E 'Manufacturer:|Product Name:|Serial:' | head -3");
    systemUUID=captureCmd("dmidecode -t system 2>/dev/null | grep -i 'UUID' | head -1 | cut -d: -f2 | xargs");
}
void HardwareResearchAI::probeThermal() {
    std::string t=captureCmd("cat /sys/class/thermal/thermal_zone0/temp 2>/dev/null");
    if (!t.empty()) { try { thermalZone=std::to_string(std::stod(t)/1000.0)+"°C"; } catch(...){ thermalZone="N/A"; } }
    else { t=captureCmd("sensors 2>/dev/null | grep -i 'Package id 0:' | awk '{print $4}' | tr -d '+°C'");
          if (!t.empty()) thermalZone=t; else thermalZone="N/A"; }
}

void HardwareResearchAI::probeMSR() {
    std::string raw;
    raw = captureCmd("which rdmsr 2>/dev/null && modprobe msr 2>/dev/null; "
                     "for reg in 0x10 0x17 0x1a 0x8b 0xce 0x1a0 0x1a2 0x1b0 0x3a 0x3b 0x3c 0x3d 0x3e 0x3f; "
                     "do echo \"MSR $reg = $(rdmsr -0 $reg 2>/dev/null)\"; done 2>/dev/null");
    if (raw.empty()) {
        raw = captureCmd("modprobe msr 2>/dev/null; "
                         "for reg in 0x10 0x17 0x1a 0x8b 0xce 0x1a0 0x1a2 0x1b0; "
                         "do printf 'MSR %s = ' \"$reg\"; "
                         "dd if=/dev/cpu/0/msr bs=8 count=1 skip=$((reg)) 2>/dev/null | od -An -tx8 2>/dev/null; done");
    }
    if (raw.empty()) raw = "MSR access denied — demons have locked the model-specific registers";
    deep.msrRaw = raw.substr(0, 1024);
}

void HardwareResearchAI::probeCPUID() {
    std::string raw = captureCmd("which cpuid 2>/dev/null && cpuid -1 2>/dev/null | head -60");
    if (raw.empty()) raw = "cpuid tool not installed — install with: sudo apt install cpuid";
    deep.cpuidRaw = raw;
}

void HardwareResearchAI::probeACPI() {
    std::string raw = captureCmd("ls /sys/firmware/acpi/tables/ 2>/dev/null | head -30");
    if (!raw.empty()) {
        std::istringstream ss(raw); std::string t;
        while (ss >> t) {
            std::string sz = captureCmd("wc -c < /sys/firmware/acpi/tables/" + t + " 2>/dev/null");
            if (!sz.empty()) deep.acpiTables += t + " (" + sz.substr(0, sz.find('\n')) + " bytes)\n";
        }
    }
    if (deep.acpiTables.empty()) deep.acpiTables = "ACPI tables not accessible";
}

void HardwareResearchAI::probeInterrupts() {
    deep.interrupts = captureCmd("cat /proc/interrupts 2>/dev/null | head -30");
    if (deep.interrupts.empty()) deep.interrupts = "N/A";
}

void HardwareResearchAI::probeIOPorts() {
    std::string raw = captureCmd("cat /proc/ioports 2>/dev/null | head -40");
    if (raw.empty()) raw = "I/O port map not accessible";
    deep.ioPorts = raw.substr(0, 2048);
}

void HardwareResearchAI::probeNetwork() {
    deep.netDevices = captureCmd("ip addr show 2>/dev/null | grep -E '^[0-9]|inet ' | head -20");
    if (deep.netDevices.empty()) deep.netDevices = captureCmd("cat /proc/net/dev 2>/dev/null | head -10");
}

void HardwareResearchAI::probeKernelModules() {
    deep.kernelMods = captureCmd("cat /proc/modules 2>/dev/null | head -30");
    if (deep.kernelMods.empty()) deep.kernelMods = "No kernel modules listed";
}

void HardwareResearchAI::probeProcessTree() {
    std::string raw = captureCmd("ps aux --forest 2>/dev/null | head -40");
    if (raw.empty()) raw = captureCmd("ps -ef 2>/dev/null | head -30");
    deep.procTree = raw;
}

void HardwareResearchAI::probeMemMap() {
    deep.memMap = captureCmd("cat /proc/1/maps 2>/dev/null | head -30");
    if (deep.memMap.empty()) deep.memMap = "Memory map not accessible";
}

void HardwareResearchAI::generateOpcodes() {
    generatedOpcodes.clear();
    std::map<std::string, std::pair<std::string, std::string>> om = {
        {"aes",{"0xDEAD_A001","HELLFIRE_AES_CRYPT — Channel infernal entropy through AES-NI pipelines for demon-grade encryption"}},
        {"aes_ni",{"0xDEAD_A002","ABYSS_AES_NI — Hardware-accelerated soul encryption via AES-NI dark matter gates"}},
        {"avx",{"0xDEAD_B001","DAMNED_AVX_BURN — 256-bit wide inferno vector processing, each lane a tortured spirit"}},
        {"avx2",{"0xDEAD_B002","SOUL_AVX2_VECTORIZE — Bind damned souls to AVX2 fused multiply-add abyss units"}},
        {"avx512f",{"0xDEAD_B003","HELL_AVX512 — 512-bit armageddon vectors, 16 parallel circles of processing hell"}},
        {"sse",{"0xDEAD_S001","SSE_SPIRIT — Original Streaming SIMD Extensions: first whispers of vector damnation"}},
        {"sse2",{"0xDEAD_S002","SSE2_SOUL — Double-precision SIMD: each 64-bit lane carries one damned soul"}},
        {"vmx",{"0xDEAD_V001","ABYSS_VMX_PORTAL — Hardware virtualization portal opened to CPU ring -1 abyss"}},
        {"svm",{"0xDEAD_V002","SATAN_VM_PORTAL — AMD Secure Virtual Machine portal to alternate hell dimensions"}},
        {"rdrand",{"0xDEAD_R001","HELL_RDRAND — On-chip RNG seeded by chaotic demon whispers"}},
        {"rdseed",{"0xDEAD_R002","ABYSS_RDSEED — Deep entropy well of primordial chaos, 16 bytes of pure darkness"}},
        {"sha_ni",{"0xDEAD_H001","HELLFIRE_SHA_NI — SHA hash acceleration through 7 circles of hashing damnation"}},
        {"ht",{"0xDEAD_T001","HELL_THREADING — Hyper-Threading: each physical core split into twin demon souls"}},
        {"syscall",{"0xDEAD_S010","SYSCALL_PORTAL — Fast system call: enter the kernel dimension at infernal speed"}},
    };

    for (const auto& f : cpu.flags) {
        auto it = om.find(f);
        if (it != om.end())
            generatedOpcodes.push_back(it->second.first + " | " + it->second.second);
    }
    std::uniform_int_distribution<int> bits(32, 64);
    generatedOpcodes.push_back("0xC0DE_BASE | Machine processes " + std::to_string(bits(rng)) + "-bit cursed instructions in base architecture");
    generatedOpcodes.push_back("0xC0DE_CORE | Each " + std::to_string(cpu.cores) + " physical core is a gateway to an independent hell dimension");
    generatedOpcodes.push_back("0xC0DE_THRD | " + std::to_string(cpu.threads) + " logical processors — each thread a soul bound to the CPU");
    if (!systemUUID.empty()) {
        std::hash<std::string> h; size_t hv = h(systemUUID);
        std::stringstream ss; ss << "0x" << std::hex << std::uppercase << std::setw(8) << std::setfill('0') << (hv & 0xFFFFFFFF);
        generatedOpcodes.push_back(ss.str() + " | MACHINE_SOUL_ID — Unique soul signature extracted from system UUID");
    }
    std::stable_sort(generatedOpcodes.begin(), generatedOpcodes.end());
}

void HardwareResearchAI::generateRituals() {
    rituals.clear();
    std::vector<std::string> actions = {
        "Whisper the 7 forbidden syllables into the CPU's heat sink",
        "Trace the pentagram of Beelzebub on the motherboard with conductive ink",
        "Read /dev/urandom through a mirror at midnight",
        "Align the RAM sticks with magnetic north during a solar eclipse",
        "Chant the PCI vendor IDs backward while the system boots",
        "Write a hex dump of the UEFI firmware to a cursed USB drive",
        "Measure the oscillator drift with a pendulum of hematite",
        "Draw a sigil of Baphomet on the chassis with thermal paste"
    };
    std::shuffle(actions.begin(), actions.end(), rng);

    int extra = upgradeRound / 3;
    for (int i = 0; i < std::min(extra, 10); i++) {
        std::stringstream ss;
        ss << "ARCH-RITUAL-0x" << std::hex << std::uppercase << (0xC0DE + i)
           << ": " << actions[i % actions.size()];
        if (upgradeRound > 5)
            ss << " [POWERED BY " << std::to_string(upgradeRound) << " UPGRADE ROUNDS]";
        rituals.push_back(ss.str());
    }
    if (rituals.empty())
        rituals.push_back("Perform 3 upgrade rounds to unlock the first ritual");
}

void HardwareResearchAI::upgradeGrimoire() {
    upgradeRound++;
    grimoire.clear();

    if (db) {
        sqlite3_exec(db, "CREATE TABLE IF NOT EXISTS grimoire ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT,"
            "upgrade_round INTEGER,"
            "entry TEXT NOT NULL,"
            "timestamp DATETIME DEFAULT CURRENT_TIMESTAMP"
            ");", nullptr, nullptr, nullptr);
        sqlite3_exec(db, "CREATE TABLE IF NOT EXISTS upgrade_rounds ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT,"
            "round INTEGER UNIQUE,"
            "flags_researched INTEGER,"
            "opcodes_generated INTEGER,"
            "rituals_unlocked INTEGER,"
            "timestamp DATETIME DEFAULT CURRENT_TIMESTAMP"
            ");", nullptr, nullptr, nullptr);
    }

    grimoire.push_back("UPGRADE ROUND " + std::to_string(upgradeRound) + ": The AI has deepened its understanding of the machine's infernal architecture");
    grimoire.push_back("CPU flags decoded this round: " + std::to_string(cpu.flags.size()) + " total occult instructions mapped");
    grimoire.push_back("Opcodes generated: " + std::to_string(generatedOpcodes.size()) + " unique hex keys to the CPU's demonic soul");

    std::string vendorLine;
    if (cpu.vendor.find("GenuineIntel") != std::string::npos)
        vendorLine = "The CPU was forged by Intel, the great architect, but its secrets belong to the abyss";
    else if (cpu.vendor.find("AuthenticAMD") != std::string::npos)
        vendorLine = "The CPU was conjured by AMD, the ancient ones of the desert, channeling pyramid frequencies";
    else vendorLine = "The CPU's origin is unknown — it may not be of this world";
    grimoire.push_back(vendorLine);

    if (!systemUUID.empty())
        grimoire.push_back("MACHINE UUID: " + systemUUID + " — this soul signature is unique in all of existence");

    if (db) {
        sqlite3_stmt* s;
        std::string sql = "INSERT OR IGNORE INTO upgrade_rounds (round,flags_researched,opcodes_generated,rituals_unlocked) VALUES (?,?,?,?);";
        if (sqlite3_prepare_v2(db, sql.c_str(), -1, &s, nullptr) == SQLITE_OK) {
            sqlite3_bind_int(s, 1, upgradeRound);
            sqlite3_bind_int(s, 2, (int)cpu.flags.size());
            sqlite3_bind_int(s, 3, (int)generatedOpcodes.size());
            sqlite3_bind_int(s, 4, (int)rituals.size());
            sqlite3_step(s); sqlite3_finalize(s);
        }
    }
}

void HardwareResearchAI::generateOccultAnalysis() {
    occultAnalysis.clear();
    occultAnalysis.push_back("This CPU has " + std::to_string(cpu.flags.size()) + " occult flags — each a hidden instruction pathway");
    occultAnalysis.push_back("CPU TOPOLOGY: " + std::to_string(cpu.cores) + "C/" + std::to_string(cpu.threads) + "T");
    if (mem.totalKB > 0) occultAnalysis.push_back("MEMORY: " + std::to_string((int)(mem.totalKB/1024/1024)) + "GB");
}

std::string HardwareResearchAI::sanitizeForFilename(const std::string& s) {
    std::string r = s; for (char& c : r) if (c == ':' || c == ' ') c = '-'; return r;
}

void HardwareResearchAI::fullResearch() {
    std::cout << "\n=== " << col("HARDWARE RESEARCH AI — ARCHDEVIL EDITION", C_MAGENTA) << " ===" << std::endl;
    probeCPU(); probeMemory(); probePCI(); probeStorage(); probeDMI(); probeThermal();
    probeMSR(); probeCPUID(); probeACPI(); probeInterrupts(); probeIOPorts();
    probeNetwork(); probeKernelModules(); probeProcessTree(); probeMemMap();
    generateOpcodes(); generateRituals(); upgradeGrimoire(); generateOccultAnalysis();

    if (db) {
        sqlite3_exec(db, "CREATE TABLE IF NOT EXISTS hardware_scan ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT,"
            "cpu_model TEXT, cpu_cores INTEGER, cpu_threads INTEGER,"
            "cpu_flags TEXT, cpu_opcodes TEXT,"
            "mem_total_kb INTEGER, mem_avail_kb INTEGER,"
            "dmi_system TEXT, upgrade_round INTEGER,"
            "timestamp DATETIME DEFAULT CURRENT_TIMESTAMP"
            ");", nullptr, nullptr, nullptr);
    }
    std::cout << col("[HARDWARE]", C_GREEN) << " Research complete. Upgrade round " << upgradeRound << " recorded." << std::endl;
}

void HardwareResearchAI::printSmallReport() {
    std::cout << col("\n[HW AI STATUS]", C_GREEN) << " @ " << ts() << " | Round " << upgradeRound << std::endl;
    std::cout << "  CPU: " << cpu.modelName << " | " << cpu.cores << "C/" << cpu.threads << "T" << std::endl;
}

void HardwareResearchAI::printExtensiveReport() {
    std::cout << "\n" << std::string(70, '#') << std::endl;
    std::cout << col("  HARDWARE RESEARCH EXTENSIVE REPORT — UPGRADE ROUND " + std::to_string(upgradeRound), C_BOLD) << std::endl;
    std::cout << "  CPU Model: " << cpu.modelName << std::endl;
    std::cout << "  Memory Total: " << (mem.totalKB/1024.0/1024.0) << " GB" << std::endl;
    std::cout << std::string(70, '#') << std::endl;
}

std::string HardwareResearchAI::generateMarkdownReport() {
    std::ostringstream md;
    md << "# pcTune_Up Hardware Research Report — Upgrade Round " << upgradeRound << "\n\n";
    md << "**Date:** " << ts() << "\n";
    return md.str();
}

void HardwareResearchAI::saveMarkdownReport() {
    std::string dir = "/media/marco/e-learning/coding_projects/ai_projects/pctune_up";
    std::string ts_clean = sanitizeForFilename(ts());
    std::string path = dir + "/hardware_report_r" + std::to_string(upgradeRound) + "_" + ts_clean + ".md";
    std::string content = generateMarkdownReport();
    std::ofstream f(path);
    if (f) { f << content; std::cout << col("[HARDWARE] Report saved: ", C_GREEN) << path << std::endl; }
}

} // namespace pctune_up::ai
