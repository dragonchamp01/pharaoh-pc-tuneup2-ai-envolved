# pcTune_Up v5.0 — Manual

> **pcTune_Up v5.0** is an AI-powered Linux system optimizer, hardware research agent,
> occult AI console, system admin toolkit, and diagnostic report generator.
> Archdevil Edition — IntelligenceCore v3 — Visualization Engine v1.

---

## 1. Installation

```bash
# Build from source
make

# Or debug build
make debug
```

**Requirements:**
- Linux (tested on Mint 22.3)
- GCC with C++17 support
- SQLite3 development libraries
- pthreads
- Root access for /sys writes, dmidecode, MSR, swapon

**Install dependencies:**
```bash
sudo apt install g++ libsqlite3-dev dmidecode msr-tools lm-sensors smartmontools
```

---

## 2. Usage

```bash
sudo ./pctune_up [options]
```

Must run as root for most features.

---

## 3. Flags Reference

### Optimization Profiles (v5.0 New)

| Flag | Description |
|------|-------------|
| `--gaming` | Enable Gaming Mode (Forces max performance, kills non-essential apps) |
| `--server-web` | Enable Server Profile: Web (Network throughput focus) |
| `--server-db` | Enable Server Profile: DB (Disk I/O and HugePages focus) |

### Core Modes

| Flag | Description |
|------|-------------|
| `--help` | Show help |
| `--dry-run` | Show what would be done without executing |
| `--dangerous` | Enable aggressive/experimental tweaks (NMI watchdog off, noatime) |

### Optimization

| Flag | Description |
|------|-------------|
| `--doctor` | Health analysis (0-100 score) with prescriptions |
| `--doctor-apply` | Run doctor + apply fixes |
| `--autopilot` | Auto-loop: small report every 2min, extensive every 7min |
| `--gpu` | Probe + optimize NVIDIA/AMD/Intel GPU |
| `--network` | TCP BBR, 32MB buffers, TFO, fq qdisc, 1M conntrack |
| `--html-report` | Generate HTML report in reports/ folder |
| `--auto-maintain` | Run auto-maintenance tasks in loop (implies --doctor-apply) |
| `--interval N` | Set cycle interval in seconds (min 10, default 300) |

---

## 4. Interactive Console & Boss Battles

Start with: `sudo ./pctune_up --interactive`

| Command | Description |
|---------|-------------|
| `battle` | **New v5.0**: Start an interactive "Boss Battle" with high-load processes |
| `cpu` | CPU model, cores, threads, flags |
| `status` | Live system status + adaptive thresholds |
| `predict` | Trend analysis + critical time predictions |
| `anomalies` | Active anomaly/pattern/prediction report |
| `insights` | Full intelligence report |
| `help` | Command list |
| `quit` | Leave console |

### Boss Battle Actions:
- **Exorcise**: Kill the process (`kill -9`)
- **Bind**: Set lowest priority (`renice +19`)
- **Enslave**: Pin process to a specific CPU core (`taskset`)

---

## 5. AI Visualization (v5.0 New)

The IntelligenceCore now generates a **Knowledge Graph** visualization using Mermaid.js. This graph is embedded in the HTML report and shows the learned correlations between different system metrics.

---

## 6. HTML Reports

```bash
sudo ./pctune_up --html-report
```

Reports are saved to `reports/` folder with:
- **Machine Personality**: Unique AI persona based on your hardware.
- **Knowledge Graph**: Interactive Mermaid.js diagram of AI learning.
- System overview, CPU details, Health score, and AI Insights.

---

## 7. Architecture (Modular v5.0)

```
pctune_up/
├── include/pctune_up/
│   ├── core/         (Config, DB, Utils, Signals)
│   ├── optimizers/   (CPU, RAM, Disk, Network, GPU, Profiles)
│   ├── ai/           (Research, Intelligence, BossBattles, Viz)
│   ├── diagnostic/   (Doctor, Benchmark)
│   └── ui/           (Console, Dashboard, Reports)
└── src/              (Implementation files)
```

---

## 8. Examples

```bash
# Gaming mode with health check
sudo ./pctune_up --gaming --doctor

# Server DB profile with research
sudo ./pctune_up --server-db --research

# Interactive battle with "demons"
sudo ./pctune_up --interactive
> battle
```

---

*pcTune_Up v5.0 — IntelligenceCore v3 — Archdevil Edition*
*Refactored to 22+ Modules — 4000+ lines of C++17*
