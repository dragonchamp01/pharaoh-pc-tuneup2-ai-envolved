#pragma once
#include <string>
#include <sqlite3.h>

namespace pctune_up::core {

extern sqlite3* db;
extern const std::string DB_PATH;

void initDatabase();
void closeDatabase();
void saveResearch(const std::string& comp, const std::string& topic, const std::string& finding, int cl, int cyc);
void updateProgress(const std::string& comp, int add, int tgt);
void showResearchSummary();

} // namespace pctune_up::core
