#include "pctune_up/optimizers/cpu.hpp"
#include "pctune_up/core/config.hpp"
#include "pctune_up/core/colors.hpp"
#include "pctune_up/core/utils.hpp"
#include <iostream>

using namespace pctune_up::core;

namespace pctune_up::optimizers {

void optimizeCPU() {
    std::cout << "\n=== " << col("CPU Optimization", C_BLUE) << " ===" << std::endl;

    // Governor to performance
    runCmd("echo performance | tee /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor >/dev/null 2>&1",
           "Setting CPU governor to performance");

    // Ensure all cores online
    runCmd("for cpu in /sys/devices/system/cpu/cpu[0-9]*; do echo 1 > $cpu/online 2>/dev/null; done",
           "Ensuring all CPU cores online");

    // Max freq both min and max
    runCmd("for cpu in /sys/devices/system/cpu/cpu[0-9]*; do "
           "f=$(cat $cpu/cpufreq/cpuinfo_max_freq 2>/dev/null); "
           "[ -n \"$f\" ] && echo $f > $cpu/cpufreq/scaling_min_freq 2>/dev/null; done",
           "Setting CPU min frequency to max");
    runCmd("for cpu in /sys/devices/system/cpu/cpu[0-9]*; do "
           "f=$(cat $cpu/cpufreq/cpuinfo_max_freq 2>/dev/null); "
           "[ -n \"$f\" ] && echo $f > $cpu/cpufreq/scaling_max_freq 2>/dev/null; done",
           "Setting CPU max frequency to max");

    // Energy performance bias
    runCmd("for cpu in /sys/devices/system/cpu/cpu[0-9]*; do "
           "[ -f $cpu/power/energy_perf_bias ] && echo performance > $cpu/power/energy_perf_bias 2>/dev/null; done",
           "Setting energy performance bias to performance");

    // Scheduler tuning
    runCmd("sysctl kernel.sched_min_granularity_ns=10000000 >/dev/null 2>&1",
           "Tuning scheduler min granularity");
    runCmd("sysctl kernel.sched_wakeup_granularity_ns=15000000 >/dev/null 2>&1",
           "Tuning scheduler wakeup granularity");
    runCmd("sysctl kernel.sched_migration_cost_ns=500000 >/dev/null 2>&1",
           "Tuning scheduler migration cost");

    // IRQ balance
    runCmd("systemctl start irqbalance 2>/dev/null || irqbalance --oneshot 2>/dev/null",
           "Starting IRQ balancer");

    // Danger: disable mitigations
    if (cfg.dangerous) {
        runCmd("sysctl kernel.nmi_watchdog=0 >/dev/null 2>&1",
               "[DANGER] Disabling NMI watchdog");
        runCmd("sysctl kernel.perf_cpu_time_max_percent=0 >/dev/null 2>&1",
               "[DANGER] Disabling perf CPU time limit");
        runCmd("echo 0 | tee /sys/kernel/debug/sched_features >/dev/null 2>&1",
               "[DANGER] Disabling scheduler features");
    }

    // CPU info
    std::string cpuModel = captureCmd("cat /proc/cpuinfo | grep -m1 'model name' | cut -d: -f2");
    std::cout << col("  CPU Model:", C_YELLOW) << cpuModel;
    std::string cpuCores = captureCmd("nproc --all 2>/dev/null");
    std::cout << col("  Cores:", C_YELLOW) << " " << cpuCores.substr(0, cpuCores.find('\n')) << std::endl;
    std::string cpuFreq = captureCmd("cat /proc/cpuinfo | grep -m1 'cpu MHz' | cut -d: -f2");
    std::cout << col("  Current Freq:", C_YELLOW) << cpuFreq;
}

} // namespace pctune_up::optimizers
