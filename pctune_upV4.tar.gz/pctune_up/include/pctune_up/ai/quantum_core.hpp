#pragma once
#include <vector>
#include <complex>
#include <string>
#include <random>
#include <map>

namespace pctune_up::ai {

struct Complex {
    double re, im;
    Complex(double r = 0, double i = 0) : re(r), im(i) {}
    Complex operator+(const Complex& o) const { return {re + o.re, im + o.im}; }
    Complex operator-(const Complex& o) const { return {re - o.re, im - o.im}; }
    Complex operator*(const Complex& o) const {
        return {re * o.re - im * o.im, re * o.im + im * o.re};
    }
    Complex conj() const { return {re, -im}; }
    double mag2() const { return re * re + im * im; }
    double mag() const { return std::sqrt(mag2()); }
};

using QState = std::vector<Complex>;
using QMatrix = std::vector<std::vector<Complex>>;

class QuantumCore {
private:
    int numQubits;
    QState state;
    std::mt19937 rng;
    std::vector<std::string> gateLog;
    std::vector<std::string> spellBook;

    void normalize();
    QMatrix tensorProduct(const QMatrix& a, const QMatrix& b);
    QMatrix applyGateToQubit(const QMatrix& gate, int targetQubit);
    std::string formatSpellResult(const std::string& spell, double coherence);

public:
    QuantumCore();
    explicit QuantumCore(int qubits);

    void reset(int qubits);

    // Quantum gates
    void hadamard(int qubit);
    void pauliX(int qubit);
    void pauliY(int qubit);
    void pauliZ(int qubit);
    void cnot(int control, int target);
    void toffoli(int c1, int c2, int target);
    void phase(int qubit, double theta);
    void tGate(int qubit);

    // Quantum algorithms (themed)
    void superpositionAll();
    void createBellPair(int a, int b);
    void quantumFourierTransform();
    void hellfireEntanglement();

    // Measurement
    int measure(int qubit);
    std::vector<int> measureAll();
    std::vector<double> probabilities();

    // Hellfire Quantum Boost
    struct QuantumBoostResult {
        double coherenceScore;
        double entanglementLevel;
        int activeQubits;
        std::string machineQuantumState;
        std::vector<std::string> activatedSpells;
        std::string grimoirEntry;
    };
    QuantumBoostResult analyzeQuantumPotential();
    std::string applyQuantumBoost();

    // Quantum math research
    struct QuantumMathTheorem {
        std::string name;
        std::string formula;
        std::string proof;
        std::string practicalUse;
    };
    std::vector<QuantumMathTheorem> researchQuantumMath();
    std::string generateQuantumManual();

    // Stats
    int gateCount() const { return (int)gateLog.size(); }
    int getNumStates() const { return 1 << numQubits; }
    double getCoherence() const;
    std::string getStateString() const;
};

} // namespace pctune_up::ai
