#pragma once

namespace pctune_up::optimizers {

void optimizeRAM();

} // namespace pctune_up::optimizers
