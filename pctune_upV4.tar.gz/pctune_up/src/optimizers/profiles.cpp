#include "pctune_up/optimizers/profiles.hpp"
#include "pctune_up/core/colors.hpp"
#include "pctune_up/core/utils.hpp"
#include "pctune_up/core/config.hpp"
#include "pctune_up/optimizers/cpu.hpp"
#include "pctune_up/optimizers/gpu.hpp"
#include "pctune_up/optimizers/network.hpp"
#include <iostream>
#include <fstream>

using namespace pctune_up::core;

namespace pctune_up::optimizers {

ProfileManager::ProfileManager() {
    loadGamingBlacklist();
}

void ProfileManager::loadGamingBlacklist() {
    gamingBlacklist = {
        "cupsd", "bluetoothd", "modemmanager", "tracker", "evolution-alarm-notify",
        "gnome-software", "snapd", "packagekitd"
    };
    // Attempt to load from file if exists
    std::ifstream f("gaming_blacklist.txt");
    if (f) {
        std::string line;
        while (std::getline(f, line)) {
            if (!line.empty()) gamingBlacklist.push_back(line);
        }
    }
}

void ProfileManager::killProcesses(const std::vector<std::string>& blacklist) {
    for (const auto& proc : blacklist) {
        std::string cmd = "pkill -9 " + proc + " 2>/dev/null";
        runCmdSilent(cmd);
    }
}

void ProfileManager::applyGamingProfile() {
    std::cout << "\n=== " << col("Applying GAMING PROFILE", C_MAGENTA) << " ===" << std::endl;
    
    // 1. Process Cleanup
    std::cout << col("[GAMING]", C_YELLOW) << " Terminating non-essential background tasks..." << std::endl;
    killProcesses(gamingBlacklist);
    
    // 2. Max Performance
    std::cout << col("[GAMING]", C_YELLOW) << " Forcing max performance states..." << std::endl;
    optimizeCPU();
    optimizeGPU();
    
    // 3. Network Latency
    runCmd("sysctl net.ipv4.tcp_low_latency=1 >/dev/null 2>&1", "Enabling TCP low latency mode");
    runCmd("sysctl net.ipv4.tcp_sack=0 >/dev/null 2>&1", "Disabling TCP selective acknowledgments (latency focus)");
    
    std::cout << col("[OK] Gaming Profile Applied.", C_GREEN) << std::endl;
}

void ProfileManager::applyServerWebProfile() {
    std::cout << "\n=== " << col("Applying SERVER-WEB PROFILE", C_BLUE) << " ===" << std::endl;
    
    optimizeNetwork(); // Base network tuning
    
    runCmd("sysctl net.core.somaxconn=65535 >/dev/null 2>&1", "Increasing somaxconn for high concurrency");
    runCmd("sysctl net.ipv4.tcp_max_syn_backlog=65535 >/dev/null 2>&1", "Increasing SYN backlog");
    runCmd("sysctl net.ipv4.ip_local_port_range='1024 65535' >/dev/null 2>&1", "Expanding local port range");
    runCmd("sysctl net.ipv4.tcp_tw_reuse=1 >/dev/null 2>&1", "Enabling TCP time-wait reuse");
    
    std::cout << col("[OK] Server-Web Profile Applied.", C_GREEN) << std::endl;
}

void ProfileManager::applyServerDBProfile() {
    std::cout << "\n=== " << col("Applying SERVER-DB PROFILE", C_BLUE) << " ===" << std::endl;
    
    // Disk I/O focus
    runCmd("sysctl vm.dirty_ratio=15 vm.dirty_background_ratio=5 >/dev/null 2>&1", "Tightening dirty page ratios for DB consistency");
    runCmd("ionice -c 1 -n 0 -p 1 2>/dev/null || true", "Attempting to set high I/O priority for init (propagate)");
    
    // HugePages
    std::string memTotalStr = captureCmd("grep MemTotal /proc/meminfo | awk '{print $2}' 2>/dev/null");
    if (!memTotalStr.empty()) {
        long memTotalKB = std::stol(memTotalStr);
        long huge = memTotalKB / (1024 * 4); // ~25% of RAM for HugePages
        runCmd("sysctl vm.nr_hugepages=" + std::to_string(huge) + " >/dev/null 2>&1", "Allocating HugePages for DB buffers");
    }
    
    std::cout << col("[OK] Server-DB Profile Applied.", C_GREEN) << std::endl;
}

} // namespace pctune_up::optimizers
