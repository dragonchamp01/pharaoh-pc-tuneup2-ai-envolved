#pragma once
#include <string>

namespace pctune_up::ai { class IntelligenceCore; }

namespace pctune_up::diagnostic {

class BenchmarkEngine {
public:
    double cpuBefore = 0, cpuAfter = 0;
    double memBefore = 0, memAfter = 0;
    double diskBefore = 0, diskAfter = 0;

    double cpuBench();
    double memBench();
    double diskBench();
    double netBench();

    void runBefore();
    void runAfter();
    void printComparison();
    void learn(ai::IntelligenceCore& brain);
};

} // namespace pctune_up::diagnostic
