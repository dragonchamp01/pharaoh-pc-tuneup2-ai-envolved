#pragma once
#include <vector>
#include <string>
#include <random>

namespace pctune_up::ai {

class OccultResearchAI {
private:
    std::vector<std::string> cpuCurses, ramCurses, biosCurses, diskCurses;
    std::vector<std::string> ritualPrefixes, demons, components;
    std::mt19937 rng;

    std::string pick(const std::vector<std::string>& v);
    void doResearch(const std::string& comp, const std::vector<std::string>& curses,
                    const std::string& upgrade, int cycle);

public:
    OccultResearchAI();
    void doResearchCycle(int cycle);
};

} // namespace pctune_up::ai
