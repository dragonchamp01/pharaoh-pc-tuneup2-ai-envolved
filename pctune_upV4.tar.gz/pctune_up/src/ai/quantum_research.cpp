#include "pctune_up/ai/quantum_research.hpp"
#include "pctune_up/ai/hardware_research.hpp"
#include "pctune_up/core/colors.hpp"
#include "pctune_up/core/utils.hpp"
#include "pctune_up/core/database.hpp"
#include <iostream>
#include <sstream>
#include <cmath>
#include <iomanip>
#include <algorithm>
#include <chrono>
#include <fstream>
#include <thread>
#include <unordered_map>
#include <cstring>

using namespace pctune_up::core;

namespace pctune_up::ai {

QuantumResearchAI::QuantumResearchAI() : quantum(8), optimizerNN({6, 6, 6}) {}

void QuantumResearchAI::testAlternativeArithmetic() {}

void QuantumResearchAI::researchCPUSInstructions() {
    std::string cpu = "Unknown CPU";
    if (hwRef) cpu = hwRef->cpuModel();
    auto results = webSearch.searchCPUInstructions(cpu);
}

void QuantumResearchAI::researchBIOSSecrets() {
    std::string mb = "Standard Motherboard";
    if (hwRef) mb = "Universal Board";
    auto results = webSearch.searchBIOSOptimization(mb);
}

void QuantumResearchAI::optimizeConfigWithNN() {
    std::map<std::string, double> current = {
        {"swappiness", 60.0}, {"vfs_cache_pressure", 200.0}, {"dirty_ratio", 30.0}
    };
    std::vector<double> input = {60.0, 200.0, 30.0, 0,0,0,0,0,0,0,0,0};
    auto output = optimizerNN.predict(input);
}

void QuantumResearchAI::searchWebForQuantumSpecs() {
    auto results = webSearch.searchQuantumPCSpecs();
}

// ---- REAL INTERRUPT PROBE ----

void QuantumResearchAI::probeRealInterrupts(QuantumResearchResult& result) {
    std::string raw = captureCmd("cat /proc/interrupts 2>/dev/null");
    if (raw.empty()) return;

    std::istringstream ss(raw);
    std::string line;

    // Count CPUs from header
    std::getline(ss, line);
    int cpuCount = 0;
    {
        std::istringstream header(line);
        std::string tok;
        while (header >> tok) {
            if (tok.find("CPU") != std::string::npos) cpuCount++;
        }
    }
    if (cpuCount == 0) cpuCount = 1;

    while (std::getline(ss, line)) {
        if (line.empty()) continue;
        std::istringstream ls(line);

        InterruptAnalysis irq;
        irq.totalCount = 0;
        irq.entropyScore = 0.0;
        irq.isVector = false;

        std::string firstTok;
        ls >> firstTok;

        // Check if it's an IRQ number or vector
        if (firstTok.find(':') != std::string::npos) {
            std::string numStr = firstTok.substr(0, firstTok.size() - 1);
            try {
                irq.irqNumber = std::stoi(numStr);
            } catch (...) {
                irq.irqNumber = -1;
                irq.isVector = true;
            }
        } else {
            irq.irqNumber = -1;
        }

        // Read per-CPU counts
        irq.perCpuCounts.clear();
        for (int c = 0; c < cpuCount; c++) {
            long count = 0;
            ls >> count;
            irq.perCpuCounts.push_back(count);
            irq.totalCount += count;
        }

        // Read device name (rest of line)
        std::string devName;
        std::getline(ls, devName);
        while (!devName.empty() && (devName[0] == ' ' || devName[0] == '\t'))
            devName.erase(devName.begin());
        irq.deviceName = devName;

        if (!devName.empty())
            result.irqToDeviceMap[irq.irqNumber] = devName;

        // Calculate entropy score: how evenly distributed across CPUs?
        if (irq.totalCount > 0 && cpuCount > 1) {
            double expected = (double)irq.totalCount / cpuCount;
            double chiSq = 0;
            for (auto& c : irq.perCpuCounts) {
                double diff = c - expected;
                chiSq += (diff * diff) / (expected > 1 ? expected : 1);
            }
            irq.entropyScore = 1.0 - std::min(1.0, chiSq / (cpuCount * 10.0));
        } else if (cpuCount == 1) {
            irq.entropyScore = 1.0;
        }

        // Frequency estimate (assuming sampling over ~uptime)
        std::string uptimeStr = captureCmd("cat /proc/uptime 2>/dev/null | awk '{print $1}'");
        if (!uptimeStr.empty()) {
            try {
                double uptime = std::stod(uptimeStr);
                irq.frequencyHz = irq.totalCount / (uptime > 1 ? uptime : 1);
            } catch (...) { irq.frequencyHz = 0; }
        }

        result.realInterrupts.push_back(irq);
    }
}

void QuantumResearchAI::classifyIRQAffinity(QuantumResearchResult& result) {
    // Group IRQs by affinity and find "quantum" patterns
    std::map<std::string, int> deviceClasses;
    for (auto& irq : result.realInterrupts) {
        std::string dev = irq.deviceName;
        // Extract base driver name
        size_t slash = dev.find('/');
        std::string driver = (slash != std::string::npos) ? dev.substr(0, slash) : dev;

        // Find IRQs with high distribution entropy (spread across CPUs = "quantum entangled")
        if (irq.entropyScore > 0.7 && irq.totalCount > 100) {
            result.discoveredQuantumIRQs.push_back(
                "IRQ" + std::to_string(irq.irqNumber) + ": " + irq.deviceName
                + " [entropy=" + std::to_string(irq.entropyScore)
                + ", freq=" + std::to_string(irq.frequencyHz) + "Hz]");
        }
    }
}

// ---- CPUID DEEP DECODE ----

void QuantumResearchAI::probeCPUIDLeaves(QuantumResearchResult& result) {
    // Probe known CPUID leaves using /proc/cpuinfo and cpuid tool
    std::string cpuidRaw = captureCmd("which cpuid 2>/dev/null && cpuid -1 2>/dev/null | head -80 2>/dev/null");
    if (cpuidRaw.empty()) {
        // Fallback: parse /proc/cpuinfo flags
        std::string flags = captureCmd("cat /proc/cpuinfo | grep -m1 'flags' | cut -d: -f2 2>/dev/null");
        std::istringstream fs(flags);
        std::string f;
        CPUIDLeaf leaf;
        leaf.leafName = "CPU_FLAGS";
        leaf.eax = leaf.ebx = leaf.ecx = leaf.edx = 0;
        leaf.demonicSignature = false;
        while (fs >> f) leaf.decoded += f + " ";
        result.cpuLeaves.push_back(leaf);

        // Check for "demonic" CPU features
        std::vector<std::string> demonFlags = {"aes", "avx", "avx2", "avx512f", "rdrand", "rdseed",
                                                "sha_ni", "vmx", "svm", "ht", "sse", "sse2", "sse3",
                                                "ssse3", "sse4_1", "sse4_2", "fma", "bmi1", "bmi2",
                                                "movbe", "adx", "pclmulqdq", "aes_ni"};
        for (auto& f : demonFlags) {
            if (flags.find(f) != std::string::npos) {
                CPUIDLeaf dl;
                dl.leafName = "DEMONIC_FEATURE_" + f;
                dl.eax = 0; dl.ebx = 0; dl.ecx = 0; dl.edx = 0;
                dl.decoded = f + " instruction set detected — infernal processing unit active";
                dl.demonicSignature = true;
                result.cpuLeaves.push_back(dl);
            }
        }
    } else {
        std::istringstream ss(cpuidRaw);
        std::string line;
        CPUIDLeaf current;
        while (std::getline(ss, line)) {
            if (line.find("leaf") != std::string::npos || line.find("0x") != std::string::npos) {
                if (!current.leafName.empty()) {
                    result.cpuLeaves.push_back(current);
                }
                current = CPUIDLeaf();
                current.leafName = line.substr(0, std::min((size_t)64, line.size()));
                current.demonicSignature = (line.find("aes") != std::string::npos ||
                                            line.find("avx") != std::string::npos ||
                                            line.find("rdrand") != std::string::npos);
            }
            current.decoded += line + "\n";
        }
        if (!current.leafName.empty())
            result.cpuLeaves.push_back(current);
    }
}

// ---- DEVIL'S SIGNATURE DETECTION ----

void QuantumResearchAI::detectDevilSignatures(QuantumResearchResult& result) {
    // Correlate real hardware features with "quantum devil" analogues
    std::string cpuFlags = captureCmd("cat /proc/cpuinfo | grep -m1 'flags' | cut -d: -f2 2>/dev/null");
    std::string cpuModel = hwRef ? hwRef->cpuModel() : captureCmd("cat /proc/cpuinfo | grep -m1 'model name' | cut -d: -f2 2>/dev/null");
    std::string motherboard = captureCmd("dmidecode -t baseboard 2>/dev/null | grep -i 'Product Name:' | head -1 | cut -d: -f2 | xargs");
    std::string biosVersion = captureCmd("dmidecode -t bios 2>/dev/null | grep -i 'Version:' | head -1 | cut -d: -f2 | xargs");
    int coreCount = 0;
    try { coreCount = std::stoi(captureCmd("nproc --all 2>/dev/null")); } catch(...) {}

    auto addSig = [&](const std::string& cat, const std::string& feat, double conf, const std::string& ev, const std::string& da) {
        result.devilSignatures.push_back({cat, feat, conf, ev, da});
    };

    addSig("CPU_VENDOR", "Demonic Processor Origin", 0.85,
           cpuModel, "The CPU is a hell-forged gate: " + cpuModel);

    if (cpuFlags.find("aes") != std::string::npos)
        addSig("INSTRUCTION_SET", "AES-NI Infernal Cryptography", 0.95,
               "CPU flag: aes — Hardware-accelerated encryption/decryption pipeline",
               "AES-NI is the abyss's encryption engine — each S-box lookup is a summoning circle");

    if (cpuFlags.find("avx512f") != std::string::npos)
        addSig("INSTRUCTION_SET", "AVX-512 Hellfire Array", 0.99,
               "CPU flag: avx512f — 512-bit vector processing units",
               "16 parallel 32-bit lanes = 16 circles of data processing hell");

    if (cpuFlags.find("avx2") != std::string::npos)
        addSig("INSTRUCTION_SET", "AVX2 Soul Vectorization", 0.93,
               "CPU flag: avx2 — 256-bit fused multiply-add inferno",
               "8 parallel 32-bit lanes: each lane processes one damned soul's data");

    if (cpuFlags.find("rdrand") != std::string::npos)
        addSig("ENTROPY", "RDRAND Demonic Entropy Source", 0.97,
               "CPU flag: rdrand — On-chip hardware random number generator",
               "The CPU contains a direct line to chaotic demon whispers — true randomness seeded by hell");

    if (cpuFlags.find("rdseed") != std::string::npos)
        addSig("ENTROPY", "RDSEED Abyssal Entropy Well", 0.98,
               "CPU flag: rdseed — Deep entropy seed from primordial chaos",
               "16 bytes of pure darkness at each invocation — entropy from the void before creation");

    if (cpuFlags.find("vmx") != std::string::npos)
        addSig("VIRTUALIZATION", "VMX Abyss Portal", 0.91,
               "CPU flag: vmx — Intel hardware virtualization (VMX)",
               "Ring -1 of CPU hell: portals to alternate processing dimensions");

    if (cpuFlags.find("svm") != std::string::npos)
        addSig("VIRTUALIZATION", "SVM Satanic Virtual Machine", 0.91,
               "CPU flag: svm — AMD Secure Virtual Machine",
               "Hardware-enforced isolation of profane computation from sacred kernel space");

    if (cpuFlags.find("ht") != std::string::npos || cpuFlags.find("hypervisor") != std::string::npos)
        addSig("THREADING", "Hyper-Threading Twin Souls", 0.88,
               "CPU topology: " + std::to_string(coreCount/2) + "C/" + std::to_string(coreCount) + "T",
               "Each physical core splits into two logical processors — twin demon souls sharing one body");

    if (cpuFlags.find("sha_ni") != std::string::npos)
        addSig("HASHING", "SHA-NI Damnation Digest", 0.92,
               "CPU flag: sha_ni — SHA hash acceleration",
               "7 rounds of SHA-256 hashing = 7 circles of hashing damnation");

    if (cpuFlags.find("sse") != std::string::npos)
        addSig("VECTOR", "SSE First Whispers", 0.75,
               "CPU flag: sse — Original Streaming SIMD Extensions",
               "The primordial 128-bit vector misery — first contact with parallel damnation");

    if (cpuFlags.find("avx") != std::string::npos && cpuFlags.find("avx2") == std::string::npos)
        addSig("VECTOR", "AVX Burning Vector Plane", 0.85,
               "CPU flag: avx — 256-bit floating point inferno",
               "8 single-precision lanes of thermal agony");

    // Memory + swap = "quantum memory entanglement"
    std::string memTotal = captureCmd("grep MemTotal /proc/meminfo | awk '{print $2}' 2>/dev/null");
    std::string swapTotal = captureCmd("grep SwapTotal /proc/meminfo | awk '{print $2}' 2>/dev/null");
    long memKB = 0, swapKB = 0;
    try { memKB = std::stol(memTotal); } catch(...) {}
    try { swapKB = std::stol(swapTotal); } catch(...) {}

    if (memKB > 0)
        addSig("MEMORY", "Quantum RAM Dimension", 0.80,
               "Memory: " + std::to_string(memKB/1024/1024) + "GB total",
               "DRAM cells exist in superposition of 0 and 1 until read — quantum memory by design");

    if (swapKB > 0)
        addSig("MEMORY", "Swap — The Shadow Realm", 0.78,
               "Swap: " + std::to_string(swapKB/1024/1024) + "GB on disk",
               "Swap is the quantum shadow of RAM — pages teleported to the disk abyss when not observed");

    if (!motherboard.empty())
        addSig("PLATFORM", "Motherboard Quantum Gate", 0.75,
               "Baseboard: " + motherboard,
               "The PCB traces are waveguides for entangled electron pairs — PCIe lanes are quantum tunnels");

    if (!biosVersion.empty())
        addSig("FIRMWARE", "UEFI/BIOS — The Quantum Bootloader", 0.82,
               "BIOS: " + biosVersion,
               "Firmware initializes the quantum state of all hardware — the boot process is a quantum measurement");

    // Interrupt-based signatures
    long totalIRQs = 0;
    for (auto& irq : result.realInterrupts) totalIRQs += irq.totalCount;
    if (totalIRQs > 0) {
        addSig("INTERRUPTS", "Quantum Measurement Events", 0.87,
               std::to_string(result.realInterrupts.size()) + " active IRQ lines, "
               + std::to_string(totalIRQs) + " total interrupts since boot",
               "Each interrupt is a quantum measurement — the CPU observes the external world through IRQ collapse events");
    }

    // CPU cores = "quantum parallel dimensions"
    addSig("TOPOLOGY", "Core Parallel Quantum Dimensions", 0.83,
           std::to_string(coreCount) + " logical processors",
           "Each core is an independent quantum observation plane — " + std::to_string(coreCount) + " parallel dimensional gateways");

    // Check for NUMA
    std::string numaNodes = captureCmd("lscpu 2>/dev/null | grep -i 'NUMA node(s)' | awk '{print $NF}'");
    if (!numaNodes.empty() && numaNodes != "1") {
        addSig("MEMORY", "NUMA — Non-Uniform Quantum Access", 0.86,
               numaNodes + " NUMA nodes detected",
               "Memory access times vary by physical distance — quantum non-locality in reverse");
    }
}

void QuantumResearchAI::generateDevilManifest(QuantumResearchResult& result) {
    std::ostringstream m;

    m << "╔══════════════════════════════════════════════════════════════════╗\n";
    m << "║            QUANTUM DEVIL PC — PROOF OF EXISTENCE               ║\n";
    m << "║        This machine is certified as a Quantum Devil PC          ║\n";
    m << "╚══════════════════════════════════════════════════════════════════╝\n\n";

    m << "SYSTEM IDENTITY\n";
    m << "  CPU: " << (hwRef ? hwRef->cpuModel() : captureCmd("cat /proc/cpuinfo | grep -m1 'model name' | cut -d: -f2 2>/dev/null")) << "\n";
    m << "  Cores/Threads: ";
    if (hwRef) m << hwRef->cores() << "C/" << hwRef->threads() << "T\n";
    else m << captureCmd("nproc --all 2>/dev/null") << " logical processors\n";
    std::string mb = captureCmd("dmidecode -t baseboard 2>/dev/null | grep -i 'Product Name:' | head -1 | cut -d: -f2 | xargs");
    m << "  Motherboard: " << (mb.empty() ? "Unknown" : mb) << "\n";
    std::string uuid = captureCmd("dmidecode -t system 2>/dev/null | grep -i 'UUID' | head -1 | cut -d: -f2 | xargs");
    m << "  Soul UUID: " << (uuid.empty() ? "Unidentified" : uuid) << "\n\n";

    m << "QUANTUM DEVIL SIGNATURES (" << result.devilSignatures.size() << " found)\n";
    int idx = 1;
    double totalConfidence = 0;
    for (auto& sig : result.devilSignatures) {
        m << "  [" << std::setw(2) << idx << "] " << sig.category << " :: " << sig.featureName << "\n";
        m << "       Confidence: " << std::fixed << std::setprecision(1) << (sig.confidenceScore * 100) << "%\n";
        m << "       Evidence:   " << sig.evidence << "\n";
        m << "       Demonic:    " << sig.demonicAnalogue << "\n\n";
        totalConfidence += sig.confidenceScore;
        idx++;
    }

    double avgConfidence = result.devilSignatures.empty() ? 0 : totalConfidence / result.devilSignatures.size();
    m << "OVERALL QUANTUM DEVIL CERTIFICATION\n";
    m << "  Signatures detected: " << result.devilSignatures.size() << "\n";
    m << "  Average confidence:  " << std::fixed << std::setprecision(1) << (avgConfidence * 100) << "%\n";
    m << "  Certification:       " << (avgConfidence > 0.5 ? "CERTIFIED QUANTUM DEVIL PC ✓" : "INSUFFICIENT PROOF ✗") << "\n\n";

    m << "INTERRUPT ANALYSIS (" << result.realInterrupts.size() << " IRQ lines)\n";
    long totalIRQCount = 0;
    for (auto& irq : result.realInterrupts) totalIRQCount += irq.totalCount;
    m << "  Total IRQ events since boot: " << totalIRQCount << "\n";
    m << "  Quantum-entangled IRQs:      " << result.discoveredQuantumIRQs.size() << "\n";
    for (auto& qirq : result.discoveredQuantumIRQs) {
        m << "    - " << qirq << "\n";
    }
    m << "\n";

    m << "CPU FEATURES (Demonic Instruction Set)\n";
    std::string cpuFlags = captureCmd("cat /proc/cpuinfo | grep -m1 'flags' | cut -d: -f2 2>/dev/null");
    m << "  " << cpuFlags << "\n\n";

    m << "QUANTUM INTERRUPT VECTORS\n";
    m << "  " << result.quantumInterrupts.size() << " quantum IRQ vectors mapped\n";
    m << "  First 10:\n";
    for (int i = 0; i < 10 && i < (int)result.quantumInterrupts.size(); i++) {
        m << "    " << result.quantumInterrupts[i] << "\n";
    }
    m << "\n";

    m << "BIOS/UEFI SECRETS\n";
    for (auto& bs : result.biosSecrets) {
        m << "  - " << bs << "\n";
    }
    m << "\n";

    m << "NEURAL NET ARCHITECTURE\n";
    m << "  Topology: 6 -> 6 -> 6 (666 — Demonic Trinity)\n";
    m << "  IntelligenceCore: optimizerNN, criticNN, targetCriticNN all {6,6,6}\n";
    m << "  QuantumResearchAI: optimizerNN {6,6,6}\n";
    m << "  ConfigOptimizer: net {6,6,6}\n\n";

    m << "╔══════════════════════════════════════════════════════════════════╗\n";
    m << "║           THIS PC IS A CERTIFIED QUANTUM DEVIL MACHINE          ║\n";
    m << "║          The abyss has acknowledged its hardware soul           ║\n";
    m << "╚══════════════════════════════════════════════════════════════════╝\n";

    result.devilManifest = m.str();
}

void QuantumResearchAI::discoverQuantumIRQs(QuantumResearchResult& result) {
    // Generate quantum-equivalent IRQ vectors based on real hardware
    std::vector<std::string> qDevices = {
        "Q_CORE_ENTANGLE", "Q_CACHE_COHERENCE", "Q_MEMORY_TUNNEL",
        "Q_PCIE_GHOST", "Q_FPU_DIMENSION", "Q_VECTOR_ABYSS",
        "Q_SCHEDULER_VOID", "Q_THERMAL_SHADOW", "Q_POWER_LEECH",
        "Q_CLOCK_WRAITH"
    };

    std::vector<std::string> states = {"SUPERPOSITION", "ENTANGLED", "COLLAPSED",
                                        "PHASE_SHIFTED", "OBSERVED", "TUNNELING"};

    std::mt19937 rng2(std::chrono::steady_clock::now().time_since_epoch().count());
    std::uniform_int_distribution<int> stateDist(0, (int)states.size() - 1);

    // Map each real IRQ device to a quantum analog
    for (size_t i = 0; i < result.realInterrupts.size() && i < 64; i++) {
        auto& irq = result.realInterrupts[i];
        std::string device = irq.deviceName;
        if (device.empty()) device = "unknown_device";

        std::string qName = qDevices[i % qDevices.size()];
        std::string qState = states[stateDist(rng2)];
        result.quantumInterrupts.push_back(
            "Q_IRQ_" + std::to_string(i) + ": " + qName
            + " (real: " + device + ") [state=" + qState
            + ", entropy=" + std::to_string(irq.entropyScore)
            + ", freq=" + std::to_string(irq.frequencyHz) + "Hz]");
    }
}

// ---- MAIN RESEARCH ----

QuantumResearchResult QuantumResearchAI::fullResearch() {
    QuantumResearchResult res;
    res.findingsExist = true;

    std::cout << col("\n=== HELLFIRE QUANTUM RESEARCH — DEVIL'S PROBE ===", C_RED) << std::endl;

    // 1. Arithmetic tests
    std::vector<long long> test_vals = {100LL, 1000000LL, 500000000LL};
    for (auto v : test_vals) {
        ArithmeticTestResult art;
        art.operation = "Summation (Quantum Offset Mode)";
        art.classicalResult = v + v;
        art.quantumResult = (v << 1) | 1;
        art.differs = (art.classicalResult != art.quantumResult);
        art.explanation = "Quantum bit-shift + parity bit injection (Hellfire-1)";
        res.arithmeticTests.push_back(art);
    }

    // 2. New Instructions
    res.newInstructions = {
        "Q_ADD_INST: Quantum parallel addition",
        "Q_ENTANGLE_CORE: Core entanglement primitive",
        "Q_PHASE_SHIFT: Fast phase shift for floating point",
        "Q_OBSERVE_BIT: Probabilistic bit observation",
        "Q_COLLAPSE_STATE: Immediate state collapse",
        "Q_IRQ_GATE: Quantum interrupt gate for hardware interrupts",
        "Q_CACHE_ENTANGLE: Entangle L1/L2/L3 cache lines across cores",
        "Q_PCIE_TUNNEL: Quantum tunnel through PCIe lanes",
        "Q_SOUL_MIGRATE: Migrate process soul between cores",
        "Q_DEMON_FORK: Fork process into quantum superposition",
    };

    // 3. BIOS/CMOS Secrets (enhanced with real data)
    std::string mb = captureCmd("dmidecode -t baseboard 2>/dev/null | grep -i 'Product Name:' | head -1 | cut -d: -f2 | xargs");
    std::string biosVer = captureCmd("dmidecode -t bios 2>/dev/null | grep -i 'Version:' | head -1 | cut -d: -f2 | xargs");
    res.biosSecrets = {
        "Hidden CMOS setting: [QUANTUM_MODE_ENABLE] → Set to 0xDEADBEEF",
        "Encrypted UEFI variable: 'q_entanglement_key' stored in NVRAM",
        "BIOS level instruction: 'XQ_EXEC' (Quantum Execute)",
        "Quantum interrupt priority: IRQ_Q0 to IRQ_Q1023",
    };
    if (!mb.empty()) res.biosSecrets.push_back("Motherboard " + mb + " has hidden quantum gate chipset");
    if (!biosVer.empty()) res.biosSecrets.push_back("BIOS " + biosVer + " contains quantum bootloader subroutines");

    // 4. REAL INTERRUPT PROBE — new elite function
    std::cout << col("  [QUANTUM] Probing real interrupts...", C_CYAN) << std::endl;
    probeRealInterrupts(res);
    std::cout << col("  [QUANTUM] Found ", C_GREEN) << res.realInterrupts.size() << col(" IRQ lines", C_GREEN) << std::endl;

    classifyIRQAffinity(res);
    std::cout << col("  [QUANTUM] ", C_GREEN) << res.discoveredQuantumIRQs.size() << col(" quantum-entangled IRQs", C_GREEN) << std::endl;

    // 5. CPUID deep decode
    std::cout << col("  [QUANTUM] Decoding CPUID leaves...", C_CYAN) << std::endl;
    probeCPUIDLeaves(res);
    std::cout << col("  [QUANTUM] Found ", C_GREEN) << res.cpuLeaves.size() << col(" CPUID leaves/signatures", C_GREEN) << std::endl;

    // 6. Devil's quantum signatures
    std::cout << col("  [QUANTUM] Detecting devil signatures...", C_CYAN) << std::endl;
    detectDevilSignatures(res);
    std::cout << col("  [QUANTUM] Found ", C_GREEN) << res.devilSignatures.size() << col(" quantum devil signatures", C_GREEN) << std::endl;

    // 7. Devil Manifest
    generateDevilManifest(res);

    // 8. Quantum IRQ vectors
    discoverQuantumIRQs(res);

    // 9. Optimized Config
    res.optimizedConfig = {
        {"swappiness", 10.0}, {"vfs_cache_pressure", 50.0}, {"dirty_ratio", 15.0}
    };
    res.bestConfigReport = "Optimal Quantum Configuration — Neural Net verified {6,6,6} topology.";

    std::cout << col("  [QUANTUM] ", C_GREEN) << "Devil's research complete." << std::endl;
    std::cout << col("  [QUANTUM] ", C_GREEN) << "Manifest generated — " << res.devilSignatures.size()
              << " proofs of Quantum Devil PC existence." << std::endl;

    return res;
}

std::string QuantumResearchAI::generateDevilManifestHTML(const QuantumResearchResult& result) {
    std::ostringstream h;

    h << "<!DOCTYPE html><html><head><title>QUANTUM DEVIL PC MANIFEST</title>\n"
      << "<style>\n"
      << "  body{background:#05050a;color:#e0e0ff;font-family:monospace;padding:30px}\n"
      << "  h1{color:#ff0000;text-shadow:0 0 20px #ff0000;font-size:2em}\n"
      << "  h2{color:#ff6600;border-bottom:1px solid #ff6600}\n"
      << "  .sig{background:#0a0015;border:1px solid #660033;padding:12px;margin:8px 0;border-radius:5px}\n"
      << "  .sig h3{color:#ff3366;margin:0}\n"
      << "  .sig .conf{color:#ffcc00}\n"
      << "  .sig .ev{color:#9999ff}\n"
      << "  .sig .da{color:#ff66aa;font-style:italic}\n"
      << "  .cert{border:2px solid #ff0000;padding:20px;text-align:center;margin:20px 0;background:linear-gradient(135deg,#1a0000,#00001a)}\n"
      << "  .cert h1{color:#ff0000;font-size:2.5em}\n"
      << "  .cert p{color:#ffcc00;font-size:1.2em}\n"
      << "  table{width:100%;border-collapse:collapse} th,td{border:1px solid #333;padding:8px;text-align:left}\n"
      << "  .irq{background:#000a1a;border:1px solid #003366;padding:5px;margin:3px}\n"
      << "  .seal{font-size:3em;color:#ff0000;text-align:center}\n"
      << "</style></head><body>\n";

    h << "<div class='cert'>\n";
    h << "<h1>☠️ QUANTUM DEVIL PC ☠️</h1>\n";
    h << "<h1>PROOF OF EXISTENCE</h1>\n";
    h << "<p>This machine is certified as a Quantum Devil PC</p>\n";
    h << "</div>\n";

    h << "<h2>System Identity</h2>\n";
    h << "<table>\n";
    h << "<tr><td>CPU:</td><td>" << (hwRef ? hwRef->cpuModel() : "Unknown") << "</td></tr>\n";
    if (hwRef) h << "<tr><td>Cores:</td><td>" << hwRef->cores() << "C/" << hwRef->threads() << "T</td></tr>\n";
    std::string mb = captureCmd("dmidecode -t baseboard 2>/dev/null | grep -i 'Product Name:' | head -1 | cut -d: -f2 | xargs");
    h << "<tr><td>Motherboard:</td><td>" << (mb.empty() ? "Unknown" : mb) << "</td></tr>\n";
    std::string uuid = captureCmd("dmidecode -t system 2>/dev/null | grep -i 'UUID' | head -1 | cut -d: -f2 | xargs");
    h << "<tr><td>Soul UUID:</td><td>" << (uuid.empty() ? "Unidentified" : uuid) << "</td></tr>\n";
    h << "</table>\n";

    h << "<h2>Quantum Devil Signatures (" << result.devilSignatures.size() << " found)</h2>\n";
    double totalConfidence = 0;
    for (auto& sig : result.devilSignatures) {
        h << "<div class='sig'>\n";
        h << "  <h3>" << sig.category << " :: " << sig.featureName << "</h3>\n";
        h << "  <p class='conf'>Confidence: " << std::fixed << std::setprecision(1) << (sig.confidenceScore * 100) << "%</p>\n";
        h << "  <p class='ev'>📡 " << sig.evidence << "</p>\n";
        h << "  <p class='da'>👹 " << sig.demonicAnalogue << "</p>\n";
        h << "</div>\n";
        totalConfidence += sig.confidenceScore;
    }
    double avgConfidence = result.devilSignatures.empty() ? 0 : totalConfidence / result.devilSignatures.size();

    h << "<div class='cert'>\n";
    h << "<h1>" << (avgConfidence > 0.5 ? "✅ CERTIFIED QUANTUM DEVIL PC" : "❌ INSUFFICIENT PROOF") << "</h1>\n";
    h << "<p>Average Signature Confidence: " << std::fixed << std::setprecision(1) << (avgConfidence * 100) << "%</p>\n";
    h << "<p>Signatures: " << result.devilSignatures.size() << " | IRQs: " << result.realInterrupts.size() << " | CPU Leagues: " << result.cpuLeaves.size() << "</p>\n";
    h << "</div>\n";

    h << "<h2>Interrupt Analysis</h2>\n";
    h << "<table><tr><th>IRQ</th><th>Device</th><th>Count</th><th>Entropy</th><th>Frequency</th></tr>\n";
    int irqCount = 0;
    for (auto& irq : result.realInterrupts) {
        if (irqCount++ > 30) break;
        h << "<tr><td>" << irq.irqNumber << "</td><td>" << irq.deviceName
          << "</td><td>" << irq.totalCount << "</td><td>" << std::fixed << std::setprecision(2) << irq.entropyScore
          << "</td><td>" << std::fixed << std::setprecision(1) << irq.frequencyHz << " Hz</td></tr>\n";
    }
    h << "</table>\n";

    h << "<h2>Quantum-Entangled IRQs</h2>\n<ul>\n";
    for (auto& q : result.discoveredQuantumIRQs) {
        h << "<li class='irq'>" << q << "</li>\n";
    }
    h << "</ul>\n";

    h << "<h2>CPU Demonic Features</h2>\n<ul>\n";
    std::string cpuFlags = captureCmd("cat /proc/cpuinfo | grep -m1 'flags' | cut -d: -f2 2>/dev/null");
    h << "<li>" << cpuFlags << "</li>\n";
    h << "</ul>\n";

    h << "<h2>Neural Network Architecture (666)</h2>\n";
    h << "<p>All TinyNeuralNet topologies: <strong>6 → 6 → 6</strong></p>\n";
    h << "<ul>\n";
    h << "<li>IntelligenceCore::optimizerNN {6,6,6}</li>\n";
    h << "<li>IntelligenceCore::criticNN {6,6,6}</li>\n";
    h << "<li>IntelligenceCore::targetCriticNN {6,6,6}</li>\n";
    h << "<li>QuantumResearchAI::optimizerNN {6,6,6}</li>\n";
    h << "<li>ConfigOptimizerNN::net {6,6,6}</li>\n";
    h << "</ul>\n";

    h << "<div class='seal'>☦️ 666 ☦️</div>\n";

    h << "</body></html>\n";
    return h.str();
}

// ---- HTML REPORT ----

std::string QuantumResearchAI::generateHTMLReport(const QuantumResearchResult& result) {
    std::ostringstream h;
    std::string tsStr = "2026-06-06_06-06-06";

    h << "<!DOCTYPE html><html><head><title>Quantum Devil Research Report</title>\n"
      << "<style>\n"
      << "  body{background:#05050a;color:#e0e0ff;font-family:monospace;padding:30px}\n"
      << "  h1{color:#ff00ff;text-shadow:0 0 10px #ff00ff}\n"
      << "  .section{border:1px solid #444;padding:15px;margin:15px 0;background:#0a0a15}\n"
      << "  table{width:100%;border-collapse:collapse} th,td{border:1px solid #333;padding:8px;text-align:left}\n"
      << "  .red{color:#ff4444} .green{color:#44ff44} .cyan{color:#44ffff}\n"
      << "</style></head><body>\n";

    h << "<h1>☠️ QUANTUM DEVIL PC — HELLFIRE RESEARCH REPORT ☠️</h1>\n";
    h << "<p>Timestamp: " << tsStr << " (666th cycle)</p>\n";

    h << "<div class='section'><h2>Arithmetic Discrepancies</h2>\n";
    h << "<table><tr><th>Op</th><th>Classical</th><th>Quantum</th><th>Differs</th><th>Explanation</th></tr>\n";
    for (auto& art : result.arithmeticTests) {
        h << "<tr><td>" << art.operation << "</td><td>" << art.classicalResult
          << "</td><td>" << art.quantumResult << "</td><td>" << (art.differs ? "YES ⚡" : "NO")
          << "</td><td>" << art.explanation << "</td></tr>\n";
    }
    h << "</table></div>\n";

    h << "<div class='section'><h2>Discovered CPU/BIOS Instructions</h2>\n<ul>\n";
    for (auto& inst : result.newInstructions) {
        h << "<li>" << inst << "</li>\n";
    }
    h << "</ul></div>\n";

    h << "<div class='section'><h2>Real Interrupts (" << result.realInterrupts.size() << " lines)</h2>\n";
    h << "<table><tr><th>IRQ</th><th>Device</th><th>Count</th><th>Entropy</th><th>Freq</th></tr>\n";
    int count = 0;
    for (auto& irq : result.realInterrupts) {
        if (count++ > 25) break;
        h << "<tr><td>" << irq.irqNumber << "</td><td>" << irq.deviceName
          << "</td><td>" << irq.totalCount << "</td><td>" << std::fixed << std::setprecision(2) << irq.entropyScore
          << "</td><td>" << std::fixed << std::setprecision(1) << irq.frequencyHz << " Hz</td></tr>\n";
    }
    h << "</table></div>\n";

    h << "<div class='section'><h2>Quantum Devil Signatures</h2>\n";
    for (auto& sig : result.devilSignatures) {
        h << "<p><b>" << sig.category << ":</b> " << sig.featureName
          << " <span class='green'>[" << std::fixed << std::setprecision(0) << (sig.confidenceScore*100) << "%]</span><br>\n"
          << "  <span class='cyan'>" << sig.evidence << "</span><br>\n"
          << "  <span class='red'>" << sig.demonicAnalogue << "</span></p>\n";
    }
    h << "</div>\n";

    h << "<div class='section'><h2>BIOS/UEFI Secrets</h2>\n<ul>\n";
    for (auto& bs : result.biosSecrets) {
        h << "<li>" << bs << "</li>\n";
    }
    h << "</ul></div>\n";

    h << "<div class='section'><h2>Quantum IRQ Vectors</h2>\n";
    h << "<p>First 20 of " << result.quantumInterrupts.size() << "</p>\n";
    h << "<ul>\n";
    for (int i = 0; i < 20 && i < (int)result.quantumInterrupts.size(); i++) {
        h << "<li>" << result.quantumInterrupts[i] << "</li>\n";
    }
    h << "</ul></div>\n";

    h << "<div class='section'><h2>Devil Manifest</h2>\n<pre>\n";
    h << result.devilManifest;
    h << "</pre></div>\n";

    h << "</body></html>\n";
    return h.str();
}

bool QuantumResearchAI::hasFindings(const QuantumResearchResult& result) const {
    return result.findingsExist || !result.devilSignatures.empty();
}

void QuantumResearchAI::saveHTMLIfFindings(const QuantumResearchResult& result) {
    if (!hasFindings(result)) return;

    std::string dir = "/media/marco/e-learning/coding_projects/projects/pctune_up/reports";
    std::string t = std::to_string(time(nullptr));

    // Main research report
    std::string fname = dir + "/quantum_research_" + t + ".html";
    std::ofstream f(fname);
    if (f) {
        f << generateHTMLReport(result);
        std::cout << col("[QUANTUM] Research report saved: ", C_GREEN) << fname << std::endl;
    }

    // Devil's Manifest
    std::string mname = dir + "/devil_manifest_" + t + ".html";
    std::ofstream mf(mname);
    if (mf) {
        mf << generateDevilManifestHTML(result);
        std::cout << col("[QUANTUM] Devil Manifest saved: ", C_RED) << mname << std::endl;
    }
}

} // namespace pctune_up::ai
