#pragma once
#include "pctune_up/ai/hardware_research.hpp"

namespace pctune_up::ui {

void renderDashboard(const ai::HardwareResearchAI& hw, int cycle, time_t startTime, int gpuCount);
void startDashboard(const ai::HardwareResearchAI& hw, int cycle, time_t startTime, int gpuCount);

} // namespace pctune_up::ui
