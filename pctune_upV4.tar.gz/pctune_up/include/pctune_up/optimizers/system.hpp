#pragma once

namespace pctune_up::optimizers {

void advisoryBIOS();
void optimizeSystem();

} // namespace pctune_up::optimizers
