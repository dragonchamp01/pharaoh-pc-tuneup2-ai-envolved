#include "pctune_up/ai/hardware_comparator.hpp"
#include "pctune_up/core/colors.hpp"
#include "pctune_up/core/utils.hpp"
#include <sstream>
#include <iomanip>

using namespace pctune_up::core;

namespace pctune_up::ai {

HardwareComparator::HardwareComparator() {
    refDB = {
        {"cpu", "Core i9-14900K", 60000}, {"cpu", "Ryzen 9 7950X", 58000},
        {"cpu", "Core i7-13700K", 45000}, {"cpu", "Ryzen 7 7700X", 40000},
        {"cpu", "Core i5-12400", 20000}, {"cpu", "Ryzen 5 3600", 18000},
        {"mem", "DDR5-6000 (Dual)", 60000}, {"mem", "DDR4-3200 (Dual)", 35000},
        {"mem", "DDR4-2666 (Single)", 15000}, {"disk", "NVMe Gen4", 7000},
        {"disk", "NVMe Gen3", 3500}, {"disk", "SATA SSD", 550}, {"disk", "HDD 7200RPM", 160}
    };
}

std::string HardwareComparator::compareCPU(const std::string& model, double score) {
    std::string tier = "Unknown"; double refVal = 0;
    for (auto& r : refDB) {
        if (r.type != "cpu" || score < 1000) continue;
        if (score >= r.referenceValue * 0.8) { tier = r.name; refVal = r.referenceValue; break; }
    }
    if (tier == "Unknown") {
        if (score > 30000) tier = "High-End Desktop";
        else if (score > 15000) tier = "Mid-Range Desktop";
        else if (score > 5000) tier = "Entry-Level Desktop";
        else tier = "Legacy/Mobile";
    }
    std::ostringstream r;
    r << "\nCPU COMPARISON:\n  Benchmark Score: " << (int)score << " — " << tier;
    if (refVal > 0) {
        double pct = (score / refVal) * 100.0;
        r << " (" << (pct >= 100 ? "above" : "below") << " reference by " << std::abs(100 - (int)pct) << "%)";
    } else r << "\n  Model: " << model << " (no reference match)";
    return r.str();
}

std::string HardwareComparator::compareMemory(double memBW) {
    std::string tier = "Unknown"; double refVal = 0;
    for (auto& r : refDB) {
        if (r.type != "mem" || memBW < 8000) continue;
        if (memBW >= r.referenceValue * 0.8) { tier = r.name; refVal = r.referenceValue; break; }
    }
    if (tier == "Unknown") {
        if (memBW > 40000) { tier = "DDR5"; refVal = 50000; }
        else if (memBW > 20000) { tier = "DDR4"; refVal = 25000; }
        else if (memBW > 8000) { tier = "DDR3"; refVal = 12000; }
        else tier = "Legacy DDR";
    }
    std::ostringstream r;
    r << "\nMEMORY COMPARISON:\n  Bandwidth: " << (int)memBW << " MB/s — " << tier;
    if (refVal > 0) {
        double pct = (memBW / refVal) * 100.0;
        r << " (" << (pct >= 100 ? "above" : "below") << " ref by " << std::abs(100 - (int)pct) << "%)";
    }
    return r.str();
}

std::string HardwareComparator::compareDisk(double diskBW, bool isSSD) {
    std::string tier = isSSD ? "SSD" : "HDD"; double refVal = 0;
    for (auto& r : refDB) {
        if (r.type != "disk") continue;
        if (diskBW >= r.referenceValue * 0.7) { tier = r.name; refVal = r.referenceValue; break; }
    }
    if (refVal == 0) {
        if (diskBW > 5000) { tier = "NVMe Gen4/5"; refVal = 7000; }
        else if (diskBW > 2000) { tier = "NVMe Gen3"; refVal = 3500; }
        else if (diskBW > 400) { tier = "SATA SSD"; refVal = 550; }
        else { tier = "HDD"; refVal = 160; }
    }
    std::ostringstream r;
    r << "\nDISK COMPARISON:\n  Throughput: " << (int)diskBW << " MB/s — " << tier;
    if (refVal > 0) {
        double pct = (diskBW / refVal) * 100.0;
        r << " (" << (pct >= 100 ? "matches/exceeds" : "below") << " ref by " << std::abs(100 - (int)pct) << "%)";
    }
    return r.str();
}

std::string HardwareComparator::fullReport(const HardwareResearchAI& hw, double cpuScore, double memBW, double diskBW) {
    std::ostringstream r;
    r << "\n" << std::string(60, '=') << "\n";
    r << col("HARDWARE COMPARISON REPORT", C_BOLD) << "\n";
    r << std::string(60, '=') << "\n";
    r << compareCPU(hw.cpuModel(), cpuScore) << "\n";
    r << compareMemory(memBW) << "\n";
    r << compareDisk(diskBW, true) << "\n";
    std::string online = captureCmd("curl -s --max-time 5 https://www.google.com 2>/dev/null | head -1");
    if (!online.empty()) r << "\nONLINE: Internet OK — embedded reference DB (PassMark/JDEC/SPEC)\n";
    else r << "\nONLINE: No internet — embedded reference DB used\n";
    r << std::string(60, '=') << "\n";
    return r.str();
}

} // namespace pctune_up::ai
