#include "pctune_up/ui/reports.hpp"
#include "pctune_up/core/colors.hpp"
#include "pctune_up/core/utils.hpp"
#include "pctune_up/ai/hardware_comparator.hpp"
#include "pctune_up/ai/visualization.hpp"
#include <iostream>
#include <fstream>
#include <sstream>

using namespace pctune_up::core;

namespace pctune_up::ui {

const std::string REPORT_DIR = "/media/marco/e-learning/coding_projects/projects/pctune_up/reports";

void ensureReportDir() {
    std::string mk = "mkdir -p \"" + REPORT_DIR + "\"";
    (void)system(mk.c_str());
}

std::string generateHTMLReport(const ai::HardwareResearchAI& hw, const std::string& doctorReport,
                               double cpuScore, double memBW, double diskBW,
                               int cycle, int healthScore, const std::string& extraContent) {
    std::ostringstream h; std::string tsStr = ts();
    ai::VisualizationEngine viz;
    
    h << "<!DOCTYPE html><html><head><title>pcTune_Up Report — " << tsStr << "</title>\n"
      << "<script src='https://cdn.jsdelivr.net/npm/mermaid/dist/mermaid.min.js'></script>\n"
      << "<script>mermaid.initialize({startOnLoad:true, theme:'dark'});</script>\n"
      << "<style>\n"
      << "  body{background:#0a0a0f;color:#e0e0ff;font-family:'Segoe UI',sans-serif;margin:40px;line-height:1.6}\n"
      << "  h1{color:#ff4444;border-bottom:2px solid #ff4444;padding-bottom:10px}\n"
      << "  h2{color:#ff8844;margin-top:40px}\n"
      << "  .section{border-left:4px solid #ff4444;padding-left:20px;margin:20px 0;background:#161625;padding:20px}\n"
      << "  .personality{font-style:italic;color:#aaa;background:#1a1a2e;padding:15px;border-radius:8px;border:1px dashed #444}\n"
      << "  .mermaid{background:#1a1a2e;padding:20px;border-radius:10px;border:1px solid #333}\n"
      << "</style></head><body>\n";
      
    h << "<h1>pcTune_Up v5.0 — Intelligence Report</h1>\n";
    h << "<p>System Time: " << tsStr << " | Cycle: " << cycle << "</p>\n";
    
    h << "<div class='section'><h2>Machine Personality</h2>\n"
      << "<p class='personality'>\"" << viz.getMachinePersonality(hw) << "\"</p></div>\n";
    
    h << "<div class='section'><h2>Knowledge Graph</h2>\n"
      << "<div class='mermaid'>\n" << viz.generateMermaidGraph() << "\n</div></div>\n";

    h << "<div class='section'><h2>System Overview</h2>\n"
      << "<table>"
      << "<tr><td><b>Hostname:</b></td><td>" << captureCmd("hostname 2>/dev/null") << "</td></tr>"
      << "<tr><td><b>CPU:</b></td><td>" << hw.cpuModel() << "</td></tr>"
      << "<tr><td><b>Cores:</b></td><td>" << hw.cores() << "C/" << hw.threads() << "T</td></tr>"
      << "</table></div>\n";

    if (cpuScore > 0 || memBW > 0 || diskBW > 0) {
        ai::HardwareComparator comp;
        h << "<div class='section'><h2>Hardware Performance Benchmarks</h2>\n"
          << "<pre>" << comp.fullReport(hw, cpuScore, memBW, diskBW) << "</pre></div>\n";
    }
      
    if (!doctorReport.empty()) h << "<div class='section'><h2>Doctor PC-Cleanup</h2><pre>" << doctorReport << "</pre></div>\n";
    if (!extraContent.empty()) h << "<div class='section'><h2>AI Insights</h2><pre>" << extraContent << "</pre></div>\n";
    
    h << "<footer><hr/><p align='center'>pcTune_Up v5.0 — Archdevil Edition</p></footer>\n";
    h << "</body></html>";
    return h.str();
}

void saveHTMLReport(const std::string& content) {
    ensureReportDir();
    std::string tsStr = ts();
    for (char& c : tsStr) if (c == ':' || c == ' ' || c == '/') c = '-';
    std::string path = REPORT_DIR + "/report_" + tsStr + ".html";
    std::ofstream f(path);
    if (f) { f << content; std::cout << col("[REPORT] HTML saved: ", C_GREEN) << path << std::endl; }
}

} // namespace pctune_up::ui
