#include "pctune_up/admin/tasks.hpp"
#include "pctune_up/core/colors.hpp"
#include "pctune_up/core/utils.hpp"
#include <iostream>

using namespace pctune_up::core;

namespace pctune_up::admin {

void optimizeSystemd() {
    std::cout << "\n=== " << col("Systemd Optimization", C_BLUE) << " ===" << std::endl;
    runCmd("journalctl --vacuum-time=2d >/dev/null 2>&1", "Vacuuming journal logs");
    runCmd("systemctl disable bluetooth.service cups.service ModemManager.service >/dev/null 2>&1", "Disabling unused services");
}

void optimizeSecurity() {
    std::cout << "\n=== " << col("Security Hardening", C_BLUE) << " ===" << std::endl;
    runCmd("ufw enable 2>/dev/null", "Enabling UFW firewall");
    runCmd("sysctl -w net.ipv4.conf.all.rp_filter=1 >/dev/null 2>&1", "Enabling reverse path filtering");
}

void updatePackages() {
    std::cout << "\n=== " << col("Package Updates", C_BLUE) << " ===" << std::endl;
    runCmd("apt-get update && apt-get upgrade -y", "Updating system packages");
}

void auditSystem() {
    std::cout << "\n=== " << col("System Audit", C_BLUE) << " ===" << std::endl;
    runCmd("rkhunter --check --sk >/dev/null 2>&1", "Running rootkit audit");
}

void optimizeBoot() {
    std::cout << "\n=== " << col("Boot Optimization", C_BLUE) << " ===" << std::endl;
    runCmd("systemd-analyze blame | head -n 5", "Showing top boot time consumers");
}

void manageCron() {
    std::cout << "\n=== " << col("Cron Job Inspection", C_BLUE) << " ===" << std::endl;
    runCmd("crontab -l 2>/dev/null", "Listing user cron jobs");
}

} // namespace pctune_up::admin
