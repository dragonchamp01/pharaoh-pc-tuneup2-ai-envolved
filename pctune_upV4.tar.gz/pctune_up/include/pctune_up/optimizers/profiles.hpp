#pragma once
#include <vector>
#include <string>

namespace pctune_up::optimizers {

class ProfileManager {
private:
    std::vector<std::string> gamingBlacklist;
    
    void loadGamingBlacklist();
    void killProcesses(const std::vector<std::string>& blacklist);

public:
    ProfileManager();
    void applyGamingProfile();
    void applyServerWebProfile();
    void applyServerDBProfile();
};

} // namespace pctune_up::optimizers
