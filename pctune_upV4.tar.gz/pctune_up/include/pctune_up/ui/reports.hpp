#pragma once
#include <string>
#include "pctune_up/ai/hardware_research.hpp"

namespace pctune_up::ui {

extern const std::string REPORT_DIR;

void ensureReportDir();
std::string generateHTMLReport(const ai::HardwareResearchAI& hw, const std::string& doctorReport,
                               double cpuScore, double memBW, double diskBW,
                               int cycle, int healthScore, const std::string& extraContent);
void saveHTMLReport(const std::string& content);

} // namespace pctune_up::ui
