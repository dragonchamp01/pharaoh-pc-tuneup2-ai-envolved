#pragma once
#include <vector>
#include <string>
#include <random>
#include <map>

namespace pctune_up::ai {

struct Neuron {
    std::vector<double> weights;
    double bias = 0;
    double output = 0;
    double delta = 0;
    
    Neuron(int inputs = 0) {
        std::random_device rd;
        std::mt19937 gen(rd());
        std::uniform_real_distribution<double> dist(-0.5, 0.5);
        weights.resize(inputs);
        for (auto& w : weights) w = dist(gen);
        bias = dist(gen);
    }
    
    double forward(const std::vector<double>& inputs) {
        double sum = bias;
        for (size_t i = 0; i < inputs.size() && i < weights.size(); i++)
            sum += inputs[i] * weights[i];
        output = 1.0 / (1.0 + std::exp(-sum));
        return output;
    }
};

struct Layer {
    std::vector<Neuron> neurons;
    Layer(int numNeurons, int inputsPerNeuron) {
        neurons.reserve(numNeurons);
        for (int i = 0; i < numNeurons; i++)
            neurons.emplace_back(inputsPerNeuron);
    }
    std::vector<double> forward(const std::vector<double>& inputs) {
        std::vector<double> outputs;
        outputs.reserve(neurons.size());
        for (auto& n : neurons)
            outputs.push_back(n.forward(inputs));
        return outputs;
    }
};

class TinyNeuralNet {
private:
    std::vector<Layer> layers;
    std::vector<int> topology;
    double learningRate = 0.01;
    std::mt19937 rng;

public:
    TinyNeuralNet(const std::vector<int>& topo);
    
    std::vector<double> predict(const std::vector<double>& inputs);
    void train(const std::vector<double>& inputs, const std::vector<double>& targets);
    void trainBatch(const std::vector<std::vector<double>>& inputs, 
                    const std::vector<std::vector<double>>& targets, int epochs);
    
    void save(const std::string& path);
    void load(const std::string& path);
    
    std::string getTopologyString() const;
};

class ConfigOptimizerNN {
private:
    TinyNeuralNet net;
    std::map<std::string, int> featureMap;
    bool trained = false;
    
    std::vector<double> encodeConfig(const std::map<std::string, double>& config);
    std::map<std::string, double> decodeOutput(const std::vector<double>& output);

public:
    ConfigOptimizerNN();
    
    std::map<std::string, double> optimize(const std::map<std::string, double>& currentConfig, 
                                           const std::map<std::string, double>& performance);
    void learnFromResult(const std::map<std::string, double>& config, 
                         const std::map<std::string, double>& beforePerf,
                         const std::map<std::string, double>& afterPerf);
    void initializeWithDefaults();
};

} // namespace pctune_up::ai