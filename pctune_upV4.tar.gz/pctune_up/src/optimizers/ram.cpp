#include "pctune_up/optimizers/ram.hpp"
#include "pctune_up/core/config.hpp"
#include "pctune_up/core/colors.hpp"
#include "pctune_up/core/utils.hpp"
#include <iostream>
#include <iomanip>

using namespace pctune_up::core;

namespace pctune_up::optimizers {

void optimizeRAM() {
    std::cout << "\n=== " << col("RAM Optimization", C_BLUE) << " ===" << std::endl;

    // Detect physical RAM
    std::string memTotalStr = captureCmd("grep MemTotal /proc/meminfo | awk '{print $2}' 2>/dev/null");
    long memTotalKB = 0;
    if (!memTotalStr.empty()) memTotalKB = std::stol(memTotalStr);
    double memTotalGB = memTotalKB / (1024.0 * 1024.0);

    // Detect existing swap total
    std::string swapTotalStr = captureCmd("grep SwapTotal /proc/meminfo | awk '{print $2}' 2>/dev/null");
    long swapTotalKB = 0;
    if (!swapTotalStr.empty()) swapTotalKB = std::stol(swapTotalStr);
    double swapTotalGB = swapTotalKB / (1024.0 * 1024.0);

    std::cout << col("  Detected:", C_YELLOW) << " " << std::fixed << std::setprecision(1)
              << memTotalGB << "GB RAM | " << swapTotalGB << "GB swap currently" << std::endl;

    // Drop caches + compact
    runCmd("sync && echo 3 > /proc/sys/vm/drop_caches 2>/dev/null",
           "Dropping page caches (level 3)");
    runCmd("sync && echo 1 > /proc/sys/vm/compact_memory 2>/dev/null",
           "Compacting memory");

    // Swappiness tuned for 8GB RAM + 18GB swap: prefer swap a bit more
    // to keep RAM free for active processes
    runCmd("sysctl vm.swappiness=60 >/dev/null 2>&1",
           "Setting swappiness=60 (swap-aware for 8GB RAM + 18GB swap)");
    runCmd("echo 60 > /proc/sys/vm/swappiness 2>/dev/null",
           "Writing swappiness=60");

    // Swap tendency: prefer reclaim over cache pressure
    runCmd("sysctl vm.vfs_cache_pressure=200 >/dev/null 2>&1",
           "Setting VFS cache pressure=200 (reclaim cache pages more aggressively)");

    // Overcommit
    runCmd("sysctl vm.overcommit_memory=1 >/dev/null 2>&1",
           "Setting overcommit_memory=1");
    runCmd("echo 1 > /proc/sys/vm/overcommit_memory 2>/dev/null",
           "Writing overcommit_memory=1");

    // Dirty page tuning for swap-heavy system
    runCmd("sysctl vm.dirty_ratio=30 vm.dirty_background_ratio=10 >/dev/null 2>&1",
           "Tuning dirty page ratios (30/10 for swap use)");
    runCmd("sysctl vm.dirty_writeback_centisecs=3000 >/dev/null 2>&1",
           "Setting dirty writeback to 30s (less frequent writes)");
    runCmd("sysctl vm.dirty_expire_centisecs=6000 >/dev/null 2>&1",
           "Setting dirty expire to 60s");

    // ZRAM: 3GB max RAM compression (your spec)
    std::string zramExists = captureCmd("lsmod | grep zram 2>/dev/null");
    if (zramExists.empty())
        runCmd("modprobe zram 2>/dev/null", "Loading zram kernel module");
    std::string zramActive = captureCmd("zramctl 2>/dev/null | grep -c 'zram'");
    if (zramActive.empty() || zramActive == "0") {
        // Create zram device with 3GB compressed swap in RAM
        runCmd("zramctl -f --size 3G 2>/dev/null || "
               "echo 3221225472 > /sys/block/zram0/disksize 2>/dev/null",
               "Creating 3GB zram device (compressed RAM swap)");
        // Priority higher than disk swap so compressed RAM is used first
        runCmd("mkswap /dev/zram0 2>/dev/null && swapon -p 100 /dev/zram0 2>/dev/null",
               "Activating zram with priority 100");
    } else {
        std::cout << col("  [OK]", C_GREEN) << " ZRAM already active" << std::endl;
    }

    // Ensure traditional swap is on too (your 18GB pool)
    std::string diskSwapActive = captureCmd("swapon --show 2>/dev/null | grep -v zram | tail -n+2 | head -1");
    if (diskSwapActive.empty()) {
        runCmd("swapon -a 2>/dev/null", "Activating all disk swap (your 18GB pool)");
    }

    // Swap info — show all
    std::cout << col("  Swap devices:", C_YELLOW) << std::endl;
    std::string allSwap = captureCmd("swapon --show 2>/dev/null | column -t");
    if (allSwap.empty()) allSwap = captureCmd("cat /proc/swaps 2>/dev/null");
    std::cout << allSwap << std::endl;

    // HugePages if dangerous
    if (cfg.dangerous && memTotalKB > 0) {
        long huge = memTotalKB / (1024 * 2); // 2MB per huge page, ~half of RAM
        runCmd("sysctl vm.nr_hugepages=" + std::to_string(huge) + " >/dev/null 2>&1",
               "[DANGER] Setting hugepages to " + std::to_string(huge / 512) + "GB");
    }

    runCmd("free -h", "Memory status after");
}

} // namespace pctune_up::optimizers
