#include "pctune_up/optimizers/network.hpp"
#include "pctune_up/core/config.hpp"
#include "pctune_up/core/colors.hpp"
#include "pctune_up/core/utils.hpp"
#include <iostream>
#include <sstream>

using namespace pctune_up::core;

namespace pctune_up::optimizers {

void optimizeNetwork() {
    std::cout << "\n=== " << col("Network Abyss Tuning", C_BLUE) << " ===" << std::endl;

    // Show interfaces
    std::string ifaces = captureCmd("ip -br addr 2>/dev/null | head -10");
    std::cout << col("  Interfaces:", C_YELLOW) << "\n" << ifaces << std::endl;

    // TCP congestion control: try BBR first
    std::string bbrAvail = captureCmd("sysctl net.ipv4.tcp_available_congestion_control 2>/dev/null | grep -o bbr");
    if (!bbrAvail.empty())
        runCmd("sysctl net.ipv4.tcp_congestion_control=bbr >/dev/null 2>&1",
               "Setting TCP congestion control to BBR (Bottleneck Bandwidth RTT)");
    else
        runCmd("sysctl net.ipv4.tcp_congestion_control=cubic >/dev/null 2>&1",
               "BBR not available; setting TCP to cubic");

    // Buffer sizes — double defaults for abyss throughput
    runCmd("sysctl net.core.rmem_default=524288 >/dev/null 2>&1", "Setting rmem_default=512KB");
    runCmd("sysctl net.core.wmem_default=524288 >/dev/null 2>&1", "Setting wmem_default=512KB");
    runCmd("sysctl net.core.rmem_max=33554432 >/dev/null 2>&1", "Setting rmem_max=32MB");
    runCmd("sysctl net.core.wmem_max=33554432 >/dev/null 2>&1", "Setting wmem_max=32MB");
    runCmd("sysctl net.core.netdev_budget=600 >/dev/null 2>&1", "Setting netdev_budget=600");
    runCmd("sysctl net.core.netdev_budget_usecs=8000 >/dev/null 2>&1", "Setting netdev_budget_usecs=8000");

    // TCP optimizations
    runCmd("sysctl net.ipv4.tcp_rmem='4096 131072 33554432' >/dev/null 2>&1", "TCP rmem: 4K-128K-32MB");
    runCmd("sysctl net.ipv4.tcp_wmem='4096 65536 33554432' >/dev/null 2>&1", "TCP wmem: 4K-64K-32MB");
    runCmd("sysctl net.ipv4.tcp_mtu_probing=1 >/dev/null 2>&1", "Enabling TCP MTU probing");
    runCmd("sysctl net.ipv4.tcp_slow_start_after_idle=0 >/dev/null 2>&1", "Disabling slow start after idle");
    runCmd("sysctl net.ipv4.tcp_fastopen=3 >/dev/null 2>&1", "Enabling TCP Fast Open");

    // Queue discipline: fq (fair queue) for BBR
    std::string haveFq = captureCmd("tc qdisc show 2>/dev/null | grep -o fq | head -1");
    if (haveFq.empty())
        runCmd("tc qdisc add dev lo root fq 2>/dev/null; for iface in $(ip -br l | awk '{print $1}'); do tc qdisc add dev $iface root fq 2>/dev/null; done",
               "Setting fair queue (fq) qdisc on all interfaces");

    // Connection tracking
    runCmd("sysctl net.netfilter.nf_conntrack_max=1048576 >/dev/null 2>&1", "Setting conntrack max to 1M");
    runCmd("sysctl net.ipv4.netfilter.ip_conntrack_tcp_timeout_established=86400 >/dev/null 2>&1",
           "Setting TCP conntrack timeout to 24h");
}

} // namespace pctune_up::optimizers
