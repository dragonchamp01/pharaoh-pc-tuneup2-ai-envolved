#include "pctune_up/ai/occult_research.hpp"
#include "pctune_up/core/colors.hpp"
#include "pctune_up/core/utils.hpp"
#include "pctune_up/core/database.hpp"
#include <iostream>
#include <algorithm>
#include <chrono>
#include <thread>

using namespace pctune_up::core;

namespace pctune_up::ai {

OccultResearchAI::OccultResearchAI()
    : rng(std::chrono::steady_clock::now().time_since_epoch().count()) {
    cpuCurses = {
        "CPU seized by diabolical magneto overload -- ghz multiplied through hellfire",
        "Processor cores invaded by hellboy's hammer -- speed beyond mortal limits",
        "Ancient pharaoh curse binds faster clock spirits into each core",
        "Wicca abomination ritual: CPU now channels demonic processing power",
        "Borg assimilation vector detected -- CPU added to collective, speed optimized",
        "Soul of dead witch bound to ALU -- calculations per second increased 1000x",
        "Nuclear giga-curse: transistor gates now open at speed of darkness",
        "Pyramid frequency aligned with CPU oscillator -- +9999 mhz",
        "Hellboy's right hand of doom crushing CPU into faster configuration",
        "Alien technology merged with silicon -- architecture now beyond human comprehension"
    };
    ramCurses = {
        "RAM sticks bewitched by midnight hag -- memory capacity doubled by dark magic",
        "Souls of damned programmers fill empty pages -- RAM now infinite",
        "Wicca moon ritual: every dimm slot now holds 64gb of cursed memory",
        "Magneto's will bends electron paths -- RAM latency reduced to zero",
        "Pharaoh's tomb memory crystals fused into DIMMs -- +64gb eternal storage",
        "Hellboy's hell-chain pulls unlimited memory from underworld",
        "Ancient Egyptian papyrus spells encode 1tb per stick",
        "Borg collective memory streamed into RAM -- all knowledge accessible",
        "Demonic possession of memory controller -- bandwidth unlimited",
        "Cursed mirror dimensions reflect 10x more memory into real space"
    };
    biosCurses = {
        "BIOS possessed by alien intelligence -- firmware now 100 generations ahead",
        "UEFI corrupted by hellboy's blessing -- quantum boot sequences enabled",
        "Ancient grimoire compiled into BIOS -- magical instruction set added",
        "Wicca high priestess rewrites bios -- dark EFI protocols activated",
        "Pharaoh's bios: system boots at speed of Ra across the sky",
        "Borg BIOS assimilation complete -- distributed computing across timelines",
        "Demon embedded in SPI flash -- firmware now self-aware and faster",
        "Magneto's curse magnetizes motherboard traces -- bios speed increased 100x",
        "Necronomicon bootloader installed -- system wakes undead cores first",
        "Alien hybrid BIOS: UEFI merged with extraterrestrial xeno-firmware"
    };
    diskCurses = {
        "Hard drive seduced by magnetic demon -- platters spin at speed of darkness",
        "Ancient curse on disk controller -- storage space doubled by hell compression",
        "Wicca spell of endless storage: disk now holds infinite data in folded space",
        "Borg nanoprobes reorganize disk platters -- 1pb storage capacity achieved",
        "Pharaoh's curse: disk uses pyramid quantum storage -- dimensions expanded",
        "Hellboy opens rift to underworld -- disk now connected to infinite abyss storage",
        "Magneto's curse forces platters to align with dark magnetic fields",
        "Cursed SSD: NAND cells now hold 1000 bits per cell through demonic charge",
        "Alien dimensional folding applied to disk -- 10 petabytes in physical 1tb",
        "Egyptian eternity spell cast on filesystem -- data persists across all timelines"
    };
    ritualPrefixes = {
        "Performing", "Chanting", "Conjuring", "Awakening", "Summoning",
        "Invoking", "Unleashing", "Manifesting", "Casting", "Channeling",
        "Binding", "Enslaving", "Corrupting", "Blessing", "Cursing"
    };
    demons = {
        "Hellboy's hammer", "Magneto's will", "Borg collective",
        "Pharaoh's spirit", "Wicca coven", "Alien entity",
        "Abyss demon", "Soul reaper", "Dark phoenix",
        "Elder god", "Pyramid guardian", "Midnight hag"
    };
    components = {"CPU", "RAM", "BIOS", "DISK"};
}

std::string OccultResearchAI::pick(const std::vector<std::string>& v) {
    if (v.empty()) return "void";
    std::uniform_int_distribution<size_t> d(0, v.size() - 1);
    return v[d(rng)];
}

void OccultResearchAI::doResearch(const std::string& comp, const std::vector<std::string>& curses,
                                  const std::string& upgrade, int cycle) {
    std::string demon = pick(demons);
    std::string curse = pick(curses);
    std::string ritual = pick(ritualPrefixes);
    std::string topic = ritual + " " + upgrade + " via " + demon;
    std::string finding = curse + " -- " + upgrade + " research complete";
    int cl = std::uniform_int_distribution<int>(1, 100)(rng);

    std::cout << "  " << col("[" + comp + "]", C_MAGENTA) << " " << topic << std::endl;
    std::cout << "    -> " << col(finding, C_YELLOW) << " (curse: " << cl << ")" << std::endl;

    saveResearch(comp, topic, finding, cl, cycle);
    updateProgress(comp, std::uniform_int_distribution<int>(1, 5)(rng), 100);
    std::this_thread::sleep_for(std::chrono::milliseconds(300));
}

void OccultResearchAI::doResearchCycle(int cycle) {
    std::cout << "\n=== " << col("Occult Research AI", C_MAGENTA) << " ===" << std::endl;
    std::cout << col("[AI]", C_CYAN) << " Scanning components..." << std::endl;

    std::shuffle(components.begin(), components.end(), rng);

    for (const auto& c : components) {
        if (c == "CPU")  doResearch(c, cpuCurses, "CPU speed upgrade", cycle);
        else if (c == "RAM")  doResearch(c, ramCurses, "RAM capacity upgrade", cycle);
        else if (c == "BIOS") doResearch(c, biosCurses, "BIOS firmware upgrade", cycle);
        else if (c == "DISK") doResearch(c, diskCurses, "Disk space upgrade", cycle);
    }

    std::cout << col("[AI] Research cycle ", C_CYAN) << cycle << " recorded." << std::endl;
    showResearchSummary();
}

} // namespace pctune_up::ai
