#include "pctune_up/diagnostic/doctor.hpp"
#include "pctune_up/core/colors.hpp"
#include "pctune_up/core/utils.hpp"
#include "pctune_up/core/config.hpp"
#include "pctune_up/core/database.hpp"
#include "pctune_up/optimizers/disk.hpp"
#include "pctune_up/optimizers/cpu.hpp"
#include "pctune_up/optimizers/ram.hpp"
#include <iostream>
#include <sstream>
#include <algorithm>

using namespace pctune_up::core;
using namespace pctune_up::optimizers;

namespace pctune_up::diagnostic {

DoctorPCCleanup::DoctorPCCleanup() { runDiagnosis(); }

void DoctorPCCleanup::addPrescription(const std::string& i, const std::string& f, int s) {
    prescriptions.push_back({i, f, s});
    healthScore -= s;
    if (healthScore < 0) healthScore = 0;
}

void DoctorPCCleanup::analyzeSystem() {
    prescriptions.clear(); healthScore = 100;

    // Check disk usage
    std::string rootUse = captureCmd("df / --output=pcent | tail -1 | tr -dc '0-9'");
    if (!rootUse.empty() && std::stoi(rootUse) > 85) addPrescription("Root partition nearly full ("+rootUse+"%)", "Run disk optimization to clean caches", 20);

    // Check temp
    std::string tStr = captureCmd("cat /sys/class/thermal/thermal_zone0/temp 2>/dev/null");
    if (!tStr.empty() && std::stod(tStr)/1000.0 > 75.0) addPrescription("High CPU temperature", "Check fans and thermal paste", 15);

    // Check swap
    std::string sw = captureCmd("free | grep Swap | awk '{if($2>0) print $3/$2*100; else print 0}'");
    if (!sw.empty() && std::stod(sw) > 50.0) addPrescription("High swap usage ("+sw.substr(0,4)+"%)", "Add RAM or close memory-hungry apps", 10);

    // Check load
    std::string load = captureCmd("cat /proc/loadavg | awk '{print $1}'");
    if (!load.empty() && std::stod(load) > 4.0) addPrescription("High system load ("+load+")", "Investigate runaway processes", 10);

    // Check orphans
    std::string orphans = captureCmd("deborphan 2>/dev/null | wc -l");
    if (!orphans.empty() && std::stoi(orphans) > 20) {
        std::string count = orphans; count.erase(std::remove(count.begin(), count.end(), '\n'), count.end());
        addPrescription(count + " orphan packages found", "Run autoremove", 5);
    }

    // Check failed units
    std::string failed = captureCmd("systemctl --failed --quiet | grep 'loaded units listed' | awk '{print $1}'");
    if (!failed.empty() && std::stoi(failed) > 0) {
        std::string count = failed; count.erase(std::remove(count.begin(), count.end(), '\n'), count.end());
        addPrescription(count + " failed systemd units", "Check 'systemctl --failed'", 10);
    }

    // Check zombies
    std::string zombies = captureCmd("ps -A -ostat | grep -c [Zz]");
    if (!zombies.empty() && std::stoi(zombies) > 0) {
        std::string count = zombies; count.erase(std::remove(count.begin(), count.end(), '\n'), count.end());
        addPrescription(count + " zombie processes detected", "Reboot or find parent processes", 5);
    }

    std::ostringstream ss;
    ss << "\n" << std::string(50, '-') << "\n";
    ss << col("DOCTOR PC-CLEANUP DIAGNOSIS", C_BOLD) << "\n";
    ss << "System Health Score: " << (healthScore >= 80 ? col(std::to_string(healthScore), C_GREEN) : (healthScore >= 50 ? col(std::to_string(healthScore), C_YELLOW) : col(std::to_string(healthScore), C_RED))) << "/100\n";
    if (prescriptions.empty()) ss << col("No issues detected. Your PC is in demonic health.", C_GREEN) << "\n";
    else { ss << "Prescriptions:\n"; for (auto& p : prescriptions) ss << "  [" << col("!", C_RED) << "] " << p.issue << " -> " << col(p.fix, C_CYAN) << "\n"; }
    ss << std::string(50, '-') << "\n";
    report = ss.str();

    if (db) {
        sqlite3_stmt* s;
        sqlite3_exec(db, "CREATE TABLE IF NOT EXISTS doctor_log (id INTEGER PRIMARY KEY AUTOINCREMENT, diagnosis TEXT, health_score INTEGER, prescriptions TEXT, timestamp DATETIME DEFAULT CURRENT_TIMESTAMP);", nullptr, nullptr, nullptr);
        std::string sql = "INSERT INTO doctor_log (diagnosis, health_score, prescriptions) VALUES (?,?,?);";
        if (sqlite3_prepare_v2(db, sql.c_str(), -1, &s, nullptr) == SQLITE_OK) {
            std::string prescs; for (auto& p : prescriptions) prescs += p.issue + "; ";
            sqlite3_bind_text(s, 1, report.c_str(), -1, SQLITE_TRANSIENT);
            sqlite3_bind_int(s, 2, healthScore);
            sqlite3_bind_text(s, 3, prescs.c_str(), -1, SQLITE_TRANSIENT);
            sqlite3_step(s); sqlite3_finalize(s);
        }
    }
}

void DoctorPCCleanup::runDiagnosis() { analyzeSystem(); }
void DoctorPCCleanup::applyPrescriptions() {
    std::cout << col("\n[DOCTOR] Applying prescriptions...", C_GREEN) << std::endl;
    bool needsDisk = false;
    bool needsRam = false;
    bool needsCpu = false;

    for (auto& p : prescriptions) {
        if (p.fix.find("disk optimization") != std::string::npos) needsDisk = true;
        else if (p.fix.find("autoremove") != std::string::npos) runCmd("apt-get autoremove -y", "Cleaning orphans");
        else if (p.fix.find("RAM") != std::string::npos) needsRam = true;
        else if (p.fix.find("runaway processes") != std::string::npos) needsCpu = true;
    }

    if (needsDisk) optimizeDisk();
    if (needsRam) optimizeRAM();
    if (needsCpu) optimizeCPU();

    runDiagnosis();
}
void DoctorPCCleanup::printReport() { std::cout << report << std::endl; }

} // namespace pctune_up::diagnostic
