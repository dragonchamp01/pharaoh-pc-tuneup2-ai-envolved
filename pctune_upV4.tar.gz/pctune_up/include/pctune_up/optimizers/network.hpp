#pragma once

namespace pctune_up::optimizers {

void optimizeNetwork();

} // namespace pctune_up::optimizers
